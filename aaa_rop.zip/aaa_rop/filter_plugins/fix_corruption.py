#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Custom Ansible filters to fix template corruption issues.
"""

import re
import json
from typing import Any, Tuple, List, Dict


def fix_corruption(value):
    """
    Fix the systematic corruption of /dev/null to /devull
    that occurs during complex Jinja2 template processing.
    
    This filter applies multiple correction patterns to handle
    various forms of the corruption.
    """
    if not isinstance(value, str):
        return value
    
    # Primary fix: /devull -> /dev/null
    result = value.replace('devull', '/dev/null')
    
    return result

def fix_devnull_corruption(value):
    """
    Fix the systematic corruption of /dev/null to /devull
    that occurs during complex Jinja2 template processing.
    
    This filter applies multiple correction patterns to handle
    various forms of the corruption.
    """
    if not isinstance(value, str):
        return value
    
    # Primary fix: /devull -> /dev/null
    result = re.sub(r'/devull\b', '/dev/null', value)
    
    # Additional safety fixes for variations
    result = re.sub(r'/dev/ull\b', '/dev/null', result)
    result = re.sub(r'/deull\b', '/dev/null', result)
    result = re.sub(r'/devnll\b', '/dev/null', result)
    
    return result


def _deep_sanitize(obj: Any) -> Tuple[Any, int]:
    """Recursively sanitize any strings inside lists/dicts/tuples/sets.

    Returns (sanitized_object, replacements_count).
    """
    total = 0
    if isinstance(obj, str):
        fixed = fix_corruption(obj)
        if fixed != obj:
            total += 1
        return fixed, total
    if isinstance(obj, list):
        new_list = []
        for item in obj:
            san, cnt = _deep_sanitize(item)
            total += cnt
            new_list.append(san)
        return new_list, total
    if isinstance(obj, tuple):
        new_items = []
        for item in obj:
            san, cnt = _deep_sanitize(item)
            total += cnt
            new_items.append(san)
        return tuple(new_items), total
    if isinstance(obj, set):
        new_set = set()
        for item in obj:
            san, cnt = _deep_sanitize(item)
            total += cnt
            new_set.add(san)
        return new_set, total
    if isinstance(obj, dict):
        new_dict = {}
        for k, v in obj.items():
            san_v, cnt = _deep_sanitize(v)
            total += cnt
            new_dict[k] = san_v
        return new_dict, total
    return obj, 0


def deep_sanitize(value):
    """Public filter: deeply sanitize structure and attach metadata as dict.

    If value is a collection, returns the sanitized value. For convenience in
    playbooks wanting counts, a companion filter deep_sanitize_info(value)
    can be used to get a dict with both sanitized object and count.
    """
    sanitized, _ = _deep_sanitize(value)
    return sanitized


def deep_sanitize_info(value):
    sanitized, count = _deep_sanitize(value)
    return {"sanitized": sanitized, "replacements": count}


def parse_health_results(results: Any) -> List[Dict[str, Any]]:
    """Parse Ansible shell results for health wrapper JSON lines.

    Each element in results is expected to be a dict with at minimum keys:
      - item
      - rc
      - stdout
      - stderr
      - stdout_lines (optional list)

    We locate the last line beginning with 'JSON: ' and parse the JSON payload.
    If absent or invalid, json field is an empty dict.
    """
    parsed: List[Dict[str, Any]] = []
    if not isinstance(results, list):
        return parsed
    for r in results:
        if not isinstance(r, dict):
            continue
        stdout_lines = r.get('stdout_lines') or []
        json_obj: Dict[str, Any] = {}
        if isinstance(stdout_lines, list):
            for line in reversed(stdout_lines):
                if isinstance(line, str) and line.startswith('JSON: '):
                    payload = line[6:]
                    try:
                        json_obj = json.loads(payload)
                    except Exception:
                        json_obj = {}
                    break
        parsed.append({
            'item': r.get('item'),
            'rc': r.get('rc'),
            'json': json_obj,
            'stdout': (r.get('stdout') or '').strip(),
            'stderr': (r.get('stderr') or '').strip(),
        })
    return parsed


def sanitize_commands(commands_list):
    """
    Sanitize a list of commands, fixing any /dev/null corruption.
    """
    if not isinstance(commands_list, list):
        return []
    return [fix_devnull_corruption(cmd) for cmd in commands_list]


class FilterModule(object):
    """Custom filters."""
    def filters(self):
        """Return a dict of filters."""
        return {
            'fix_corruption': fix_corruption,
            'fix_devnull': fix_devnull_corruption,
            'deep_sanitize': deep_sanitize,
            'deep_sanitize_info': deep_sanitize_info,
            'parse_health_results': parse_health_results,
            'sanitize_commands': sanitize_commands,
        }