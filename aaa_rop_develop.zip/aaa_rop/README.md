# Service Deployment Playbook

## 📌 Purpose

This Ansible playbook automates the **deployment, reinstallation, uninstallation, and health-check** of services defined in an environment-specific `deploy_services.yml` catalogue.

It supports:
- Filtering deployments by **components** (services) or **tags** (inventory groups)
- Resolving service **dependencies** automatically
- Running installations in **parallel** or **ordered** mode depending on dependencies
- Conditional reinstallation of components (`FORCE` mode)
- Automated artifact download and installation
- Health checks after deployment
- Aggregated per-host deployment results

---

## ⚙️ Supported Parameters

These variables can be passed as **extra-vars** (`-e`) at runtime.

| Parameter     | Type     | Description                                                                                          | Example |
|---------------|----------|------------------------------------------------------------------------------------------------------|---------|
| `TAG`         | string   | Comma-separated list of inventory groups to limit deployment to. **Mutually exclusive** with `COMPONENT`. | `-e TAG=prod,web` |
| `COMPONENT`   | string   | Comma-separated list of service names from the catalogue to deploy. **Mutually exclusive** with `TAG`. Resolves dependencies automatically. | `-e COMPONENT=rop-edge-service,rop-worker-service` |
| `UNINSTALL`   | bool     | If `true`, skips all install plays and removes matching services from target hosts.                  | `-e UNINSTALL=true` |
| `FORCE`       | bool     | If `true`, forces reinstall even if versions match. When combined with `COMPONENT`, triggers the **Re-install requested COMPONENTS** play. | `-e FORCE=true COMPONENT=rop-api-service` |
| `CONTAINER`   | string   | Comma-separated list of container (package) names to limit installation to within a component.       | `-e CONTAINER=ICEropworker,ICErop_edgeservice` |
| `DISABLEREPO` | string   | Yum/DNF repo patterns to disable during install.                                                      | `-e DISABLEREPO=puppet*,pc_repo*` |
| `ENABLEREPO`  | string   | Yum/DNF repo patterns to enable during install.                                                       | `-e ENABLEREPO=rm-shared` |
| `STOP_AFTER_DEBUG` | bool | If `true`, exits after showing resolved services and hosts (debug mode).                             | `-e STOP_AFTER_DEBUG=true` |

---

## 🛠 How It Works

1. **Catalogue & Options Load (localhost)**
   - Reads `deploy_services.yml` to get the full service list (`all_services`)
   - Loads `vars/vars.yml` into `options`
   - Optionally filters services by `COMPONENT` or `TAG`
   - Resolves full dependency chains if `COMPONENT` is used
   - Validates component/tag names

2. **Dynamic Host List Build**
   - Derives `dynamic_hosts` inventory group from `serverFilters` in the selected services
   - If `TAG` is specified, intersects host list with matching inventory groups

3. **Facts Propagation**
   - Pushes `all_services`, `options`, and helper lists (`parallel_services`, `ordered_services`, `svc_by_name`, `dep_map`) to target hosts

4. **Execution Plays**
   - **Uninstall Mode** (`UNINSTALL=true`): Removes matching services from `dynamic_hosts`
   - **Download Artifacts**: Parallel download of required packages to target hosts
   - **Reinstall Mode** (`FORCE=true` + `COMPONENT`): Reinstalls specified components and dependencies
   - **Parallel Install**: Deploy services without dependencies in parallel
   - **Ordered Install**: Deploy dependent services one-by-one per host
   - **Post-deploy Health Checks**: Runs service start and health verification

5. **Summary Aggregation (localhost)**
   - Collects `install`, `start`, and `health` results from all hosts
   - Displays a consolidated per-host deployment summary
   - Fails the playbook if any artifacts or services fail

---

## 🚀 Example Usage

**Deploy all services in environment**
```bash
ansible-playbook playbook.yml -e env_path=envs/prod
