#!/usr/bin/env bash
# scan-library-chunk.sh — called by library-recurring-scan.yml
# Scans all packages in one matrix chunk and writes chunk-results/*.props.json
#
# Required environment variables (set by the workflow step env: block):
#   AQUA_TOKEN                — Aqua scanner token
#   ARTIF_USER                — Artifactory username (BASE_THIRDPARTY_USER)
#   ARTIF_PASS                — Artifactory password (BASE_THIRDPARTY)
#   CHUNK_ITEMS               — JSON array of package objects (from matrix)
#   ARTIFACTORY_URL           — e.g. https://artifbuild.intcx.net/artifactory
#   AQUA_HOST                 — e.g. https://aquasec.intcx.net
#   RECORE_AQUASEC_API_USER   — Aqua API username (for suppression check)
#   RECORE_AQUASEC_API_PASS   — Aqua API password
#   GITHUB_ACTOR              — set automatically by GitHub Actions
#   GITHUB_RUN_ID             — set automatically by GitHub Actions

set -e
mkdir -p chunk-results

echo "$CHUNK_ITEMS" | jq -c '.[]' | while IFS= read -r item; do
  name=$(echo "$item"         | jq -r '.name')
  version=$(echo "$item"      | jq -r '.version')
  artif_ng=$(echo "$item"     | jq -r '.artif_ng')
  vendor=$(echo "$item"       | jq -r '.vendor // "npm"')
  catalog_file=$(echo "$item" | jq -r '.catalog_file')
  status=$(echo "$item"       | jq -r '.status // "active"')
  SAFE="${name//\//_}-${version}"

  echo "=== [$vendor:$name@$version] Starting ===" >&2

  # Scan result state — set by each vendor-specific block below
  scan_ok=false
  scan_file="chunk-results/${SAFE}.scan.json"
  img_tag=""
  security_report=""
  artif_file_paths=()   # Artifactory artifact paths to sync metadata on

  # ════════════════════════════════════════════════════════════════
  # npm — single .tgz download → docker import → Aqua scan
  # ════════════════════════════════════════════════════════════════
  if [ "$vendor" = "npm" ]; then

    pkg_basename=$(basename "$name")
    tarball_filename="${pkg_basename}-${version}.tgz"
    tarball_url="${artif_ng}/-/${tarball_filename}"

    http_code=$(curl -s -o /dev/null -w '%{http_code}' \
      -u "${ARTIF_USER}:${ARTIF_PASS}" -I "$tarball_url" 2>/dev/null || echo "000")
    if [ "$http_code" != "200" ]; then
      echo "[WARN] $name@$version not found in Artifactory (HTTP $http_code); skipping" >&2
      continue
    fi

    rm -f "${tarball_filename}"
    curl -fsSL -u "${ARTIF_USER}:${ARTIF_PASS}" -o "${tarball_filename}" "$tarball_url"
    if [ ! -s "${tarball_filename}" ]; then
      echo "[WARN] Downloaded tarball is empty; skipping" >&2
      continue
    fi

    _pkg_name=$(echo "$name" | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9-')
    img_tag="npm-scan-${_pkg_name}:${version}"
    docker rmi "$img_tag" 2>/dev/null || true

    if ! docker import "${tarball_filename}" "$img_tag"; then
      echo "[ERROR] docker import failed for $name@$version; skipping" >&2
      rm -f "${tarball_filename}"
      continue
    fi
    rm -f "${tarball_filename}"

    for attempt in 1 2 3 4 5; do
      set +e
      ./scannercli --verbose-errors --no-verify scan \
        --local "$img_tag" --dockerless \
        --host "${AQUA_HOST}" --token "$AQUA_TOKEN" \
        --jsonfile "$scan_file" --verbose --full-output
      rc=$?
      set -e
      case $rc in
        0|4) scan_ok=true; break ;;
        3)   sleep 10 ;;
        *)   sleep 5 ;;
      esac
    done
    docker rmi "$img_tag" 2>/dev/null || true

    if [ "$scan_ok" = true ] && [ -s "$scan_file" ]; then
      tmp=$(mktemp)
      jq '
        if has("vulnerability_summary") and (has("security")|not)
        then .security={vulnerability_summary:.vulnerability_summary} | del(.vulnerability_summary)
        else . end
        | if (.security|type)!="object" then .security={} else . end
        | (.security.vulnerability_summary //= {})
        | .security.vulnerability_summary.total =
            ((.security.vulnerability_summary.critical // 0)
            +(.security.vulnerability_summary.high     // 0)
            +(.security.vulnerability_summary.medium   // 0)
            +(.security.vulnerability_summary.low      // 0))
        | .security.policy_gate =
            (if (.security.vulnerability_summary.critical // 0) > 0 then "fail" else "pass" end)
      ' "$scan_file" > "$tmp" && mv "$tmp" "$scan_file"

      # Record tarball path for Artifactory metadata sync
      _npm_art_path="${artif_ng#${ARTIFACTORY_URL}/}"
      artif_file_paths=("${_npm_art_path}/-/${tarball_filename}")
    fi

  # ════════════════════════════════════════════════════════════════
  # pypi — mirrors pypi-library-workflow exactly:
  #   • list ALL .whl + .tar.gz files for this version from Artifactory
  #   • .whl: unzip → repack under /usr/local/lib/python3/dist-packages/
  #     so Aqua can detect dist-info and find Python package metadata
  #   • scan each file as a separate Docker image
  #   • critical = count of FILES with ≥1 critical CVE  (matches original)
  #   • high / medium / low = summed across all files    (matches original)
  # ════════════════════════════════════════════════════════════════
  elif [ "$vendor" = "pypi" ]; then

    # List all files in the package directory via Artifactory storage API
    art_path="${artif_ng#${ARTIFACTORY_URL}/}"
    listing=$(curl -sf -u "${ARTIF_USER}:${ARTIF_PASS}" \
      "${ARTIFACTORY_URL}/api/storage/${art_path}?list" 2>/dev/null || echo "{}")

    # Select files whose name contains "-{version}." or "-{version}-"
    # and ends with .whl or .tar.gz
    mapfile -t version_files < <(echo "$listing" | jq -r \
      --arg ver "$version" \
      '.files[]? | .uri[1:] |
       select(
         (contains("-" + $ver + ".") or contains("-" + $ver + "-")) and
         (endswith(".whl") or endswith(".tar.gz"))
       )' 2>/dev/null || true)

    if [ ${#version_files[@]} -eq 0 ]; then
      echo "[WARN] No files found for pypi:$name@$version in Artifactory; skipping" >&2
      continue
    fi
    echo "[PYPI] Found ${#version_files[@]} file(s) for $name@$version" >&2

    # Per-file accumulators (matching original pypi-library-workflow logic)
    pypi_critical_files=0   # count of files with ≥1 critical CVE
    pypi_malware_files=0    # count of files with ≥1 malware hit
    pypi_total_high=0       # sum of high CVEs across all files
    pypi_total_medium=0     # sum of medium CVEs across all files
    pypi_total_low=0        # sum of low CVEs across all files
    pypi_errors=0
    pypi_any_ok=false
    first_img_tag=""
    _best_score=0           # tracks the most significant file for security_report URL

    for file_uri in "${version_files[@]}"; do
      [ -n "$file_uri" ] || continue
      file_url="${artif_ng}/${file_uri}"
      file_basename=$(basename "$file_uri")
      safe_file=$(echo "$file_basename" | sed 's/[^a-zA-Z0-9._-]/_/g')
      # Detect .tar.gz as a unit (simple ##*. gives "gz", not "tar.gz")
      if [[ "$file_basename" == *.tar.gz ]]; then ext="tar.gz"; else ext="${file_basename##*.}"; fi

      echo "[PYPI] Downloading $file_basename ..." >&2
      rm -f "$file_basename"
      if ! curl -fsSL -u "${ARTIF_USER}:${ARTIF_PASS}" \
             -o "$file_basename" "$file_url" || [ ! -s "$file_basename" ]; then
        echo "[WARN] Download failed for $file_basename" >&2
        rm -f "$file_basename"
        pypi_errors=$((pypi_errors + 1))
        continue
      fi

      # Derive img_tag from filename (same logic as pypi-library-workflow)
      if [ "$ext" = "whl" ]; then
        _base="${file_basename%.whl}"
        _pver=$(echo "$_base" | cut -d'-' -f2)
        _pnm=$(echo "$_base"  | cut -d'-' -f1 | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9-')
      else
        _base="${file_basename%.tar.gz}"
        _pver="${_base##*-}"
        _pnm=$(echo "${_base%-*}" | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9-')
      fi
      file_img_tag="pypi-scan-${_pnm}:${_pver}"

      # Both .whl and .tar.gz must be repacked as a filesystem tar under
      # /usr/local/lib/python3/dist-packages/ so Aqua detects dist-info/METADATA.
      # .whl is a zip; .tar.gz is a compressed tar — extraction differs, repack is the same.
      import_src="$file_basename"
      tmp_tar=""
      if [ "$ext" = "whl" ]; then
        tmp_tar="/tmp/${safe_file%.whl}.tar"
        tmp_ext="/tmp/whl_extract_${safe_file}"
        tmp_wrp="/tmp/whl_wrap_${safe_file}"
        mkdir -p "$tmp_ext" "${tmp_wrp}/usr/local/lib/python3/dist-packages"
        if ! python3 -m zipfile -e "$file_basename" "$tmp_ext" 2>/dev/null; then
          echo "[WARN] Failed to extract $file_basename; skipping" >&2
          rm -rf "$tmp_ext" "$tmp_wrp"
          rm -f "$file_basename"
          pypi_errors=$((pypi_errors + 1))
          continue
        fi
        cp -r "${tmp_ext}/." "${tmp_wrp}/usr/local/lib/python3/dist-packages/"
        tar -cf "$tmp_tar" -C "$tmp_wrp" .
        import_src="$tmp_tar"
        rm -rf "$tmp_ext" "$tmp_wrp"
      elif [ "$ext" = "tar.gz" ]; then
        tmp_tar="/tmp/${safe_file%.tar.gz}.tar"
        tmp_ext="/tmp/tgz_extract_${safe_file}"
        tmp_wrp="/tmp/tgz_wrap_${safe_file}"
        mkdir -p "$tmp_ext" "${tmp_wrp}/usr/local/lib/python3/dist-packages"
        if ! tar -xzf "$file_basename" -C "$tmp_ext" 2>/dev/null; then
          echo "[WARN] Failed to extract $file_basename; skipping" >&2
          rm -rf "$tmp_ext" "$tmp_wrp"
          rm -f "$file_basename"
          pypi_errors=$((pypi_errors + 1))
          continue
        fi
        cp -r "${tmp_ext}/." "${tmp_wrp}/usr/local/lib/python3/dist-packages/"
        tar -cf "$tmp_tar" -C "$tmp_wrp" .
        import_src="$tmp_tar"
        rm -rf "$tmp_ext" "$tmp_wrp"
      fi
      rm -f "$file_basename"

      docker rmi "$file_img_tag" 2>/dev/null || true
      if ! docker import "$import_src" "$file_img_tag" 2>/dev/null; then
        echo "[WARN] docker import failed for $file_basename; skipping" >&2
        [ -n "$tmp_tar" ] && rm -f "$tmp_tar"
        pypi_errors=$((pypi_errors + 1))
        continue
      fi
      [ -n "$tmp_tar" ] && rm -f "$tmp_tar"

      # Aqua scan for this individual file
      file_scan="chunk-results/${SAFE}-${safe_file}.scan.json"
      file_ok=false
      for attempt in 1 2 3 4 5; do
        set +e
        ./scannercli --verbose-errors --no-verify scan \
          --local "$file_img_tag" --dockerless \
          --host "${AQUA_HOST}" --token "$AQUA_TOKEN" \
          --jsonfile "$file_scan" --verbose --full-output
        rc=$?
        set -e
        case $rc in
          0|4) file_ok=true; break ;;
          3)   sleep 10 ;;
          *)   sleep 5 ;;
        esac
      done
      docker rmi "$file_img_tag" 2>/dev/null || true

      if [ "$file_ok" = true ] && [ -s "$file_scan" ]; then
        pypi_any_ok=true

        CRIT=$(jq -r '(.security.vulnerability_summary // .vulnerability_summary).critical // 0' "$file_scan" 2>/dev/null || echo 0)
        HIGH=$(jq -r '(.security.vulnerability_summary // .vulnerability_summary).high     // 0' "$file_scan" 2>/dev/null || echo 0)
        MED=$(jq -r  '(.security.vulnerability_summary // .vulnerability_summary).medium   // 0' "$file_scan" 2>/dev/null || echo 0)
        LOW=$(jq -r  '(.security.vulnerability_summary // .vulnerability_summary).low      // 0' "$file_scan" 2>/dev/null || echo 0)
        MAL=$(jq -r  '.malware // [] | length'                                                   "$file_scan" 2>/dev/null || echo 0)

        # critical/malware: count files, not CVEs  (matches original workflow)
        [ "$CRIT" -gt 0 ] && pypi_critical_files=$((pypi_critical_files + 1))
        [ "$MAL"  -gt 0 ] && pypi_malware_files=$((pypi_malware_files + 1))
        pypi_total_high=$((pypi_total_high     + HIGH))
        pypi_total_medium=$((pypi_total_medium + MED))
        pypi_total_low=$((pypi_total_low       + LOW))

        echo "[PYPI] $file_basename → critical_in_file=$CRIT high=$HIGH medium=$MED low=$LOW" >&2

        # Use the security_report URL from the file with the most significant findings
        # (highest critical first, then high) so the link reflects actual vulnerabilities.
        _file_score=$(( CRIT * 10000 + HIGH ))
        if [ -z "$first_img_tag" ] || [ "$_file_score" -gt "${_best_score:-0}" ]; then
          _best_score="$_file_score"
          first_img_tag="$file_img_tag"
          _FIN=$(echo "$file_img_tag" | awk -F: '{print $1}' | sed 's/\//%2F/g')
          _FIT=$(echo "$file_img_tag" | awk -F: '{print $2}')
          security_report="${AQUA_HOST}/#/images/Ad%20Hoc%20Scans/${_FIN}:${_FIT}"
          _FD=$(jq -r '.digest // .image_digest // .image.details.digest // empty' \
                "$file_scan" 2>/dev/null || true)
          if [ -n "$_FD" ]; then
            _EFD=$(DIGEST="$_FD" python3 -c \
              'import os,urllib.parse; print(urllib.parse.quote(os.environ["DIGEST"],""))')
            security_report="${security_report}?digest=${_EFD}"
          fi
        fi
        rm -f "$file_scan"
      else
        echo "[WARN] Scan failed for $file_basename" >&2
        rm -f "$file_scan" 2>/dev/null || true
        pypi_errors=$((pypi_errors + 1))
      fi
    done  # end per-file loop

    if [ "$pypi_any_ok" = false ]; then
      echo "[ERROR] All file scans failed for pypi:$name@$version; recording error" >&2
      jq -n \
        --arg name         "$name" \
        --arg version      "$version" \
        --arg catalog_file "$catalog_file" \
        --arg vendor       "$vendor" \
        '{name:$name,version:$version,status:"inactive",
          catalog_file:$catalog_file,vendor:$vendor,
          scanned_date:(now|strftime("%Y-%m-%dT%H:%M:%SZ")),
          security:{policy_gate:"error",is_suppressed:false,suppression_count:0,
            vulnerability_summary:{critical:0,high:0,medium:0,low:0}}}' \
        > "chunk-results/${SAFE}.props.json"
      continue
    fi

    # Build synthetic scan_file from accumulated per-file totals
    jq -n \
      --argjson crit "$pypi_critical_files" \
      --argjson high "$pypi_total_high" \
      --argjson med  "$pypi_total_medium" \
      --argjson low  "$pypi_total_low" \
      --argjson mal  "$pypi_malware_files" \
      '{security:{
          vulnerability_summary:{
            critical:$crit, high:$high, medium:$med, low:$low, malware:$mal,
            total:($crit + $high + $med + $low)
          },
          policy_gate: (if ($crit > 0 or $mal > 0) then "fail" else "pass" end)
        }}' > "$scan_file"

    scan_ok=true
    img_tag="$first_img_tag"

    # Record per-file paths for Artifactory metadata sync
    artif_file_paths=()
    for _furi in "${version_files[@]}"; do
      [ -n "$_furi" ] && artif_file_paths+=("${art_path}/${_furi}")
    done

  else
    echo "[WARN] Unknown vendor '$vendor' for $name@$version; skipping" >&2
    continue
  fi

  # ── Shared: error case ─────────────────────────────────────────
  if [ "$scan_ok" = false ] || [ ! -s "$scan_file" ]; then
    echo "[ERROR] Scan failed for $name@$version; recording error result" >&2
    jq -n \
      --arg name         "$name" \
      --arg version      "$version" \
      --arg catalog_file "$catalog_file" \
      --arg vendor       "$vendor" \
      '{name:$name, version:$version, status:"inactive",
        catalog_file:$catalog_file, vendor:$vendor,
        scanned_date:(now|strftime("%Y-%m-%dT%H:%M:%SZ")),
        security:{policy_gate:"error",is_suppressed:false,suppression_count:0,
          vulnerability_summary:{critical:0,high:0,medium:0,low:0}}}' \
      > "chunk-results/${SAFE}.props.json"
    continue
  fi

  # ── Shared: Aqua console URL (npm builds here; pypi already set per-file)
  if [ -z "$security_report" ]; then
    IMAGE_NAME=$(echo "$img_tag" | awk -F: '{print $1}' | sed 's/\//%2F/g')
    IMAGE_TAG=$(echo "$img_tag"  | awk -F: '{print $2}')
    security_report="${AQUA_HOST}/#/images/Ad%20Hoc%20Scans/${IMAGE_NAME}:${IMAGE_TAG}"
    DIGEST=$(jq -r '.digest // .image_digest // .image.details.digest // empty' \
             "$scan_file" 2>/dev/null || true)
    if [ -n "$DIGEST" ]; then
      ENC_DIGEST=$(DIGEST="$DIGEST" python3 -c \
        'import os,urllib.parse; print(urllib.parse.quote(os.environ["DIGEST"],""))')
      security_report="${security_report}?digest=${ENC_DIGEST}"
    fi
  fi

  # ── Shared: Aqua authentication (for suppression check) ────────
  auth_resp=$(curl -s -k \
    -H "Content-Type: application/json" \
    -X POST \
    --data "{\"id\":\"${RECORE_AQUASEC_API_USER}\",\"password\":\"${RECORE_AQUASEC_API_PASS}\"}" \
    "${AQUA_HOST}/api/v1/login")
  aqua_token=$(echo "$auth_resp" | jq -r '.token // empty' 2>/dev/null)
  if [ -z "$aqua_token" ] || [ "$aqua_token" = "null" ]; then
    echo "[WARN] Aqua auth failed; using AQUA_TOKEN fallback" >&2
    aqua_token="${AQUA_TOKEN:-}"
  fi

  # ── Shared: suppression check ──────────────────────────────────
  is_suppressed="false"
  suppression_count=0
  suppression_details="[]"

  if [ -n "$aqua_token" ]; then
    sup_resp=$(curl -s -k \
      -H "Accept: application/json" \
      -H "Authorization: Bearer $aqua_token" \
      "${AQUA_HOST}/api/v2/risks/acknowledge?page=1&page_size=50000")

    _search_basename=$(basename "$name")
    for search_fmt in "${img_tag}" "${_search_basename}:${version}" "${name}:${version}"; do
      sup_match=$(echo "$sup_resp" | jq -c \
        --arg s "$search_fmt" '
        [.result[]? | select(.registry=="Ad Hoc Scans") | select(.image==$s) |
          {issue_name,image,comment,author,date,expiration_days,days_until_expiration}]
      ' 2>/dev/null || echo "[]")
      suppression_count=$(echo "$sup_match" | jq 'length')
      if [ "$suppression_count" -gt 0 ]; then
        is_suppressed="true"
        suppression_details="$sup_match"
        echo "[DEBUG] Found $suppression_count suppression(s) for format '$search_fmt'" >&2
        break
      fi
    done
  fi

  # ── Shared: policy gate + status resolution ────────────────────
  gate=$(jq -r '.security.policy_gate // "pass"' "$scan_file")
  crit_count=$(jq -r '.security.vulnerability_summary.critical // 0' "$scan_file")
  has_expired="false"
  if [ "$is_suppressed" = "true" ]; then
    has_expired=$(echo "$suppression_details" | jq '
      map(select(.days_until_expiration != null and .days_until_expiration != "N/A"))
      | map(.days_until_expiration | tonumber) | map(select(. <= 0)) | length > 0
    ' 2>/dev/null || echo "false")
  fi

  final_gate="$gate"
  if [ "$is_suppressed" = "true" ]; then
    if [ "$has_expired" = "true" ]; then
      final_gate="fail"; final_status="inactive"
      echo "[INFO] Suppression expired for $name@$version → gate=fail status=inactive" >&2
    else
      final_gate="pass"; final_status="suppressed"
      echo "[INFO] Active suppression for $name@$version → gate=pass status=suppressed" >&2
    fi
  elif [ "$gate" = "pass" ]; then
    final_status="active"
  else
    # gate = fail or error
    final_status="inactive"
    echo "[INFO] Gate=${gate} (no suppression) for $name@$version → status=inactive" >&2
  fi

  if [ "$final_gate" = "fail" ] && [ "$crit_count" -gt 0 ]; then
    echo "::warning title=Critical CVEs::$name@$version — $crit_count file(s) with critical CVEs (suppressed: $is_suppressed)"
  fi

  # ── Delete vulnerable artifacts from Artifactory ──────────────
  # If gate failed (no active suppression), remove the artifact files so
  # they are not consumable by downstream teams until the issue is resolved.
  # Track whether any file was actually deleted to set status=deleted vs inactive.
  artifact_deleted=false
  deleted_at=""
  if [ "$final_gate" = "fail" ] && [ ${#artif_file_paths[@]} -gt 0 ]; then
    echo "[ARTIF] Gate=fail for $name@$version — deleting ${#artif_file_paths[@]} artifact file(s) from Artifactory" >&2
    for _apath in "${artif_file_paths[@]}"; do
      [ -n "$_apath" ] || continue
      echo "[ARTIF] Deleting ${_apath}" >&2
      _del_http=$(curl -s -o /tmp/artif_del.out -w '%{http_code}' \
        -u "${ARTIF_USER}:${ARTIF_PASS}" \
        -X DELETE \
        "${ARTIFACTORY_URL}/${_apath}" || echo "000")
      if [ "$_del_http" = "200" ] || [ "$_del_http" = "204" ]; then
        echo "[OK] Deleted vulnerable artifact ${_apath} (HTTP ${_del_http})" >&2
        artifact_deleted=true
        [ -z "$deleted_at" ] && deleted_at=$(date -u +%Y-%m-%dT%H:%M:%SZ)
      elif [ "$_del_http" = "404" ]; then
        echo "[INFO] Artifact ${_apath} already absent (HTTP 404); nothing to delete" >&2
      else
        echo "[WARN] Failed to delete ${_apath} (HTTP ${_del_http})" >&2
        cat /tmp/artif_del.out >&2 || true
      fi
    done
    if [ "$artifact_deleted" = "true" ]; then
      final_status="deleted"
      echo "[INFO] $name@$version removed from Artifactory → status=deleted deleted_at=$deleted_at" >&2
    fi
  fi

  # ── Shared: write props JSON ───────────────────────────────────
  scanned_date=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  security_obj=$(jq -c '.security // {}' "$scan_file")
  security_obj=$(echo "$security_obj" | jq \
    --arg gate       "$final_gate" \
    --arg report     "$security_report" \
    --arg is_sup     "$is_suppressed" \
    --arg sup_cnt    "$suppression_count" \
    --arg deleted_at "$deleted_at" \
    --argjson sup_det "$suppression_details" \
    '.policy_gate          = $gate |
     .security_report      = $report |
     .is_suppressed        = ($is_sup == "true") |
     .suppression_count    = ($sup_cnt | tonumber) |
     .suppression_details  = $sup_det |
     if ($deleted_at | length) > 0 then .deleted_at = $deleted_at else . end')

  jq -n \
    --arg name         "$name" \
    --arg version      "$version" \
    --arg status       "$final_status" \
    --arg scanned_date "$scanned_date" \
    --arg catalog_file "$catalog_file" \
    --arg vendor       "$vendor" \
    --argjson security "$security_obj" \
    '{name:$name, version:$version, status:$status,
      scanned_date:$scanned_date, catalog_file:$catalog_file, vendor:$vendor,
      security:$security}' \
    > "chunk-results/${SAFE}.props.json"

  echo "[OK] Written props for $name@$version (gate=$final_gate status=$final_status)" >&2

  # ── Shared: sync Artifactory artifact metadata ─────────────────
  # Skip metadata sync when gate failed — artifact files were deleted above;
  # PUT /api/storage on a deleted path would return 404 noise.
  if [ "$final_gate" = "fail" ]; then
    echo "[ARTIF] Skipping metadata sync for $name@$version (gate=fail, artifacts deleted)" >&2
  elif [ ${#artif_file_paths[@]} -gt 0 ]; then
    _encode() { python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$1" 2>/dev/null || printf '%s' "$1"; }
    _ts_enc=$(_encode "$scanned_date")
    _actor_enc=$(_encode "${GITHUB_ACTOR}")
    _report_enc=$(_encode "$security_report")
    _crit=$(echo "$security_obj" | jq -r '.vulnerability_summary.critical // 0')
    _high=$(echo "$security_obj" | jq -r '.vulnerability_summary.high     // 0')
    _med=$(echo  "$security_obj" | jq -r '.vulnerability_summary.medium   // 0')
    _low=$(echo  "$security_obj" | jq -r '.vulnerability_summary.low      // 0')
    _mal=$(echo  "$security_obj" | jq -r '.vulnerability_summary.malware  // 0')
    _scan_props="scanned_date=${_ts_enc};policy_gate=${final_gate}"
    _scan_props="${_scan_props};security.critical=${_crit};security.high=${_high};security.medium=${_med};security.low=${_low};security.malware=${_mal}"
    _scan_props="${_scan_props};security_report=${_report_enc}"
    _scan_props="${_scan_props};mirror.workflow_run=${GITHUB_RUN_ID};mirror.actor=${_actor_enc}"

    for _apath in "${artif_file_paths[@]}"; do
      [ -n "$_apath" ] || continue
      echo "[ARTIF] Syncing properties on ${_apath}" >&2

      for attempt in 1 2 3; do
        _http=$(curl -s -o /tmp/artif_props.out -w '%{http_code}' \
          -u "${ARTIF_USER}:${ARTIF_PASS}" \
          -X PUT \
          "${ARTIFACTORY_URL}/api/storage/${_apath}?properties=${_scan_props}" \
          || echo "000")
        if [ "$_http" = "200" ] || [ "$_http" = "204" ]; then
          echo "[OK] Artifactory props synced (HTTP ${_http}, attempt ${attempt})" >&2; break
        fi
        echo "[WARN] Artifactory props update attempt ${attempt} failed (HTTP ${_http})" >&2
        cat /tmp/artif_props.out >&2 || true
        [ $attempt -eq 3 ] \
          && echo "[WARN] Non-fatal: failed to sync Artifactory props for ${_apath}" >&2 \
          || sleep 4
      done
    done
  fi

done  # end while loop over chunk items

docker image prune -f 2>/dev/null || true
