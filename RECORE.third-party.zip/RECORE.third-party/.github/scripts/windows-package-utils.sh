#!/bin/bash
# Windows package utilities for OpenJDK workflow
# Handles: download, extract, hash, verify MSI/ZIP packages

set -euo pipefail

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Logging functions
log_info() {
  echo -e "${GREEN}[INFO]${NC} $*"
}

log_warn() {
  echo -e "${YELLOW}[WARN]${NC} $*"
}

log_error() {
  echo -e "${RED}[ERROR]${NC} $*" >&2
}

# Download package from URL with retries
download_package() {
  local url="$1"
  local output_file="$2"
  local max_retries=3
  local retry_delay=5

  log_info "Downloading package from: $url"

  for attempt in $(seq 1 $max_retries); do
    if curl -f -L --progress-bar "$url" -o "$output_file" 2>/dev/null; then
      log_info "Download successful"
      return 0
    fi

    if [ $attempt -lt $max_retries ]; then
      log_warn "Download attempt $attempt failed, retrying in ${retry_delay}s..."
      sleep $retry_delay
    fi
  done

  log_error "Failed to download after $max_retries attempts"
  return 1
}

# Calculate SHA256 hash of file
calculate_hash() {
  local file="$1"

  if [ ! -f "$file" ]; then
    log_error "File not found: $file"
    return 1
  fi

  log_info "Calculating SHA256 hash..."
  sha256sum "$file" | awk '{print $1}'
}

# Extract MSI contents (Windows Installer format)
extract_msi() {
  local msi_file="$1"
  local extract_dir="$2"

  log_info "Extracting MSI: $msi_file to $extract_dir"

  mkdir -p "$extract_dir"

  # Use lessmsi if available, otherwise use 7zip or unzip
  if command -v lessmsi &> /dev/null; then
    lessmsi x "$msi_file" "$extract_dir/" >/dev/null 2>&1
    log_info "Extracted with lessmsi"
  elif command -v 7z &> /dev/null; then
    7z x "$msi_file" -o"$extract_dir" >/dev/null 2>&1
    log_info "Extracted with 7zip"
  else
    log_warn "MSI extraction tools not available, extracting as ZIP..."
    unzip -q "$msi_file" -d "$extract_dir" || true
  fi

  # Verify extraction
  if [ -z "$(ls -A "$extract_dir")" ]; then
    log_error "Failed to extract MSI contents"
    return 1
  fi

  log_info "MSI extracted successfully, $(find "$extract_dir" -type f | wc -l) files found"
  return 0
}

# Extract ZIP file
extract_zip() {
  local zip_file="$1"
  local extract_dir="$2"

  log_info "Extracting ZIP: $zip_file to $extract_dir"

  mkdir -p "$extract_dir"
  unzip -q "$zip_file" -d "$extract_dir"

  if [ -z "$(ls -A "$extract_dir")" ]; then
    log_error "Failed to extract ZIP contents"
    return 1
  fi

  log_info "ZIP extracted successfully, $(find "$extract_dir" -type f | wc -l) files found"
  return 0
}

# Get package metadata (size, modification date, etc.)
get_package_metadata() {
  local file="$1"

  if [ ! -f "$file" ]; then
    log_error "File not found: $file"
    return 1
  fi

  local size=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null)
  local mtime=$(stat -f%Sm -t%Y-%m-%dT%H:%M:%SZ "$file" 2>/dev/null || stat -c%y "$file" 2>/dev/null | cut -d' ' -f1,2)

  echo "size=$size"
  echo "created_date=$mtime"
}

# Verify file integrity (checksum comparison)
verify_checksum() {
  local file="$1"
  local expected_hash="$2"

  if [ -z "$expected_hash" ]; then
    log_warn "No expected hash provided, skipping verification"
    return 0
  fi

  log_info "Verifying checksum..."
  local calculated_hash=$(calculate_hash "$file")

  if [ "$calculated_hash" = "$expected_hash" ]; then
    log_info "Checksum verified: $calculated_hash"
    return 0
  else
    log_error "Checksum mismatch!"
    log_error "Expected: $expected_hash"
    log_error "Calculated: $calculated_hash"
    return 1
  fi
}

# List Java versions available from jdk.java.net/archive
list_openjdk_versions() {
  local base_url="https://jdk.java.net/archive/"

  log_info "Querying OpenJDK versions from $base_url"

  # This is a simple scraper - in production might need more robust parsing
  curl -s "$base_url" | grep -oP 'jdk-\K[0-9.]+' | sort -V -r | head -20
}

# Main function
main() {
  local command="${1:-}"

  case "$command" in
    download)
      download_package "$2" "$3"
      ;;
    hash)
      calculate_hash "$2"
      ;;
    extract-msi)
      extract_msi "$2" "$3"
      ;;
    extract-zip)
      extract_zip "$2" "$3"
      ;;
    metadata)
      get_package_metadata "$2"
      ;;
    verify)
      verify_checksum "$2" "$3"
      ;;
    list-versions)
      list_openjdk_versions
      ;;
    *)
      log_error "Unknown command: $command"
      echo "Usage: $0 <command> [args...]"
      echo ""
      echo "Commands:"
      echo "  download <url> <output>           Download package from URL"
      echo "  hash <file>                       Calculate SHA256 hash"
      echo "  extract-msi <msi> <output-dir>   Extract MSI contents"
      echo "  extract-zip <zip> <output-dir>   Extract ZIP contents"
      echo "  metadata <file>                   Get file metadata"
      echo "  verify <file> <expected-hash>    Verify file checksum"
      echo "  list-versions                    List available OpenJDK versions"
      return 1
      ;;
  esac
}

main "$@"
