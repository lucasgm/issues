#!/usr/bin/env python3
"""
Script to clean up the final .nuspec file by removing empty elements and formatting properly.
"""

import sys
import xml.etree.ElementTree as ET
from xml.dom import minidom
import re

# Optional elements that should be removed if empty
OPTIONAL_ELEMENTS = {
    'title', 'owners', 'copyright', 'licenseUrl', 'projectUrl', 'iconUrl', 
    'tags', 'releaseNotes', 'packageTypes', 'developmentDependency'
}

# Elements that should be removed if they have default values
DEFAULT_VALUES = {
    'requireLicenseAcceptance': 'false',
    'developmentDependency': 'false',
    'packageType': 'Dependency'
}

def clean_nuspec_file(nuspec_file):
    """
    Clean up the .nuspec file by removing empty elements and fixing formatting.
    
    Args:
        nuspec_file: Path to the .nuspec file to clean
    """
    try:
        # First, read and clean the raw content to fix structural issues
        with open(nuspec_file, 'r', encoding='utf-8') as file_handle:
            content = file_handle.read()
        
        # Fix duplicate dependencies tags and other structural issues
        content = re.sub(r'</dependencies>\s*</dependencies>', '</dependencies>', content)
        content = re.sub(r'<dependencies>\s*<dependencies>', '<dependencies>', content)
        
        # Remove excessive whitespace between tags
        content = re.sub(r'>\s*\n\s*\n\s*\n\s*<', '>\n    <', content)
        content = re.sub(r'>\s*\n\s*\n\s*</', '>\n  </', content)
        
        # Parse the cleaned XML
        root = ET.fromstring(content)
        
        # Define namespace
        xml_namespace = {'': 'http://schemas.microsoft.com/packaging/2013/05/nuspec.xsd'}
        
        # Find metadata element and clean it up
        metadata = root.find('.//metadata', xml_namespace)
        if metadata is not None:
            # Remove empty optional elements
            for elem in list(metadata):
                tag_name = elem.tag.split('}')[-1] if '}' in elem.tag else elem.tag
                
                # Remove if element is empty or whitespace-only
                if elem.text is None or elem.text.strip() == '':
                    if tag_name in OPTIONAL_ELEMENTS:
                        metadata.remove(elem)
                        continue
                
                # Remove if element has default value
                if tag_name in DEFAULT_VALUES and elem.text and elem.text.strip() == DEFAULT_VALUES[tag_name]:
                    metadata.remove(elem)
                    continue
                
                # Remove packageTypes if it contains default Dependency type
                if tag_name == 'packageTypes':
                    package_type = elem.find('.//packageType', xml_namespace)
                    if package_type is not None and package_type.get('name') == 'Dependency':
                        metadata.remove(elem)
                        continue
        
        # Register namespace to avoid ns0 prefixes
        ET.register_namespace('', 'http://schemas.microsoft.com/packaging/2013/05/nuspec.xsd')
        
        # Convert to string with proper formatting
        rough_string = ET.tostring(root, encoding='unicode')
        
        # Ensure proper package structure
        if not rough_string.startswith('<package'):
            rough_string = f'<package xmlns="http://schemas.microsoft.com/packaging/2013/05/nuspec.xsd">{rough_string}</package>'
        
        # Parse with minidom for proper formatting
        reparsed = minidom.parseString(rough_string)
        pretty_xml = reparsed.toprettyxml(indent="  ", encoding=None)
        
        # Clean up the formatted XML
        lines = pretty_xml.split('\n')
        cleaned_lines = []
        
        for line in lines:
            stripped = line.strip()
            # Skip empty lines and XML declaration (we'll add our own)
            if stripped and not stripped.startswith('<?xml'):
                # Clean up any remaining namespace prefixes
                line = re.sub(r'<ns0:', '<', line)
                line = re.sub(r'</ns0:', '</', line)
                cleaned_lines.append(line)
        
        # Build final clean XML
        final_xml = '<?xml version="1.0" encoding="utf-8"?>\n' + '\n'.join(cleaned_lines)
        
        # Final cleanup for consistent formatting
        final_xml = re.sub(r'\n\s*\n\s*\n+', '\n\n', final_xml)  # Remove excessive blank lines
        final_xml = re.sub(r'(\n\s*<[^/][^>]*>\s*)\n+(\s*<)', r'\1\n\2', final_xml)  # Single line between tags
        
        # Write back the cleaned content
        with open(nuspec_file, 'w', encoding='utf-8') as file_handle:
            file_handle.write(final_xml)
            
        print(f"Cleaned up .nuspec file: {nuspec_file}")
        
    except Exception as e:
        print(f"Error cleaning .nuspec file: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python clean_nuspec.py <nuspec_file>")
        sys.exit(1)
    
    nuspec_file = sys.argv[1]
    clean_nuspec_file(nuspec_file)
