#!/usr/bin/env python3
"""
Parse GitHub Actions input and create YAML configuration files.
This script handles sources and dependencies inputs safely without shell parsing issues.
"""

import sys
import os
import argparse

def parse_sources(input_content, output_file):
    """Parse sources input and create sources.yaml file."""
    try:
        with open(output_file, 'w', encoding='utf-8') as sources_file_handle:
            sources_file_handle.write("sources:\n")
            if input_content.strip():
                lines_written = 0
                for line in input_content.split('\n'):
                    if line.strip():
                        sources_file_handle.write(f"  {line}\n")
                        lines_written += 1
                print(f"[SUCCESS] Created {output_file} with {lines_written} source entries")
            else:
                print(f"[SUCCESS] Created {output_file} with empty sources configuration")
    except Exception as e:
        print(f"[ERROR] Error creating {output_file}: {e}")
        sys.exit(1)

def parse_dependencies(input_content, output_file):
    """Parse dependencies input and create dependencies.yaml file."""
    try:
        with open(output_file, 'w', encoding='utf-8') as deps_file_handle:
            if input_content.strip():
                deps_file_handle.write("dependencies:\n")
                lines_written = 0
                for line in input_content.split('\n'):
                    if line.strip():
                        deps_file_handle.write(f"  {line}\n")
                        lines_written += 1
                print(f"[SUCCESS] Created {output_file} with {lines_written} dependency entries")
            else:
                deps_file_handle.write("dependencies: []\n")
                print(f"[SUCCESS] Created {output_file} with empty dependencies configuration")
    except Exception as e:
        print(f"[ERROR] Error creating {output_file}: {e}")
        sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description='Parse GitHub Actions inputs to YAML files')
    parser.add_argument('type', choices=['sources', 'dependencies'], 
                       help='Type of configuration to parse')
    parser.add_argument('output_file', help='Output YAML file path')
    parser.add_argument('--input', help='Input content (if not provided, reads from stdin)')
    
    args = parser.parse_args()
    
    try:
        # Get input content
        if args.input:
            input_content = args.input
        else:
            input_content = sys.stdin.read()
        
        # Parse based on type
        if args.type == 'sources':
            parse_sources(input_content, args.output_file)
        elif args.type == 'dependencies':
            parse_dependencies(input_content, args.output_file)
        
        print(f"[SUCCESS] Successfully processed {args.type} configuration")
        
    except KeyboardInterrupt:
        print("\n[ERROR] Operation cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"[ERROR] Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
