#!/usr/bin/env python3
"""
Script to safely insert XML content into nuspec files.
This script handles the insertion of dependencies and content files without shell parsing issues.
"""

import sys
import os

def insert_xml_content(nuspec_file, content_file, placeholder):
    """
    Insert XML content from content_file into nuspec_file at the placeholder location.
    
    Args:
        nuspec_file: Path to the .nuspec file
        content_file: Path to the XML content file to insert
        placeholder: Placeholder string to replace (e.g., "#{dependencies}#")
    """
    try:
        # Read the nuspec file
        with open(nuspec_file, 'r', encoding='utf-8') as nuspec_file_handle:
            nuspec_content = nuspec_file_handle.read()
        
        # Check if content file exists and read it
        if os.path.exists(content_file):
            with open(content_file, 'r', encoding='utf-8') as content_file_handle:
                xml_content = content_file_handle.read().strip()
            
            # Replace the placeholder with the XML content
            updated_content = nuspec_content.replace(placeholder, xml_content)
            print(f"[SUCCESS] Inserted content from {content_file} into {nuspec_file}")
        else:
            # Just remove the placeholder if no content file exists
            updated_content = nuspec_content.replace(placeholder, "")
            print(f"[INFO] No content file {content_file} found, removed placeholder")
        
        # Write the updated content back to the nuspec file
        with open(nuspec_file, 'w', encoding='utf-8') as output_file_handle:
            output_file_handle.write(updated_content)
            
    except Exception as e:
        print(f"[ERROR] Error processing {nuspec_file}: {e}")
        sys.exit(1)

def main():
    if len(sys.argv) != 4:
        print("Usage: python insert_xml_content.py <nuspec_file> <content_file> <placeholder>")
        sys.exit(1)
    
    nuspec_file = sys.argv[1]
    content_file = sys.argv[2]
    placeholder = sys.argv[3]
    
    insert_xml_content(nuspec_file, content_file, placeholder)

if __name__ == "__main__":
    main()
