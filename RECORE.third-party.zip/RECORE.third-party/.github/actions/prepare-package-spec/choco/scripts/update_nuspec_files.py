#!/usr/bin/env python3
"""
NuSpec Files Pre-Staging
Pre-stages all source files into a clean chocoStaging directory with exact target structure.

The .nuspec template uses: <file src="./**/*" target=""/> 
This works because nuget pack runs from within the chocoStaging directory.
"""

import sys
import os
import yaml
import glob
import fnmatch
import shutil

def should_include_file(filename, include_patterns, exclude_patterns):
    """
    Determine if a file should be included based on include/exclude patterns
    
    Logic:
    - If include patterns are specified: ONLY include files matching those patterns
    - If exclude patterns are specified: Include all files EXCEPT those matching exclude patterns
    - Include patterns take precedence over exclude patterns
    
    Args:
        filename: Name of the file to check
        include_patterns: Semicolon-separated include patterns (if specified, ONLY these files are included)
        exclude_patterns: Semicolon-separated exclude patterns (these files are excluded from all others)
        
    Returns:
        bool: True if file should be included
    """
    # Parse patterns
    includes = [p.strip() for p in include_patterns.split(';') if p.strip()] if include_patterns else []
    excludes = [p.strip() for p in exclude_patterns.split(';') if p.strip()] if exclude_patterns else []
    
    # If include patterns are specified, ONLY include files matching those patterns
    if includes:
        for pattern in includes:
            if fnmatch.fnmatch(filename, pattern):
                # Even if it matches include, check if it's explicitly excluded
                for exclude_pattern in excludes:
                    if fnmatch.fnmatch(filename, exclude_pattern):
                        return False
                return True
        # File doesn't match any include pattern
        return False
    
    # No include patterns specified, so include everything EXCEPT excluded files
    if excludes:
        for pattern in excludes:
            if fnmatch.fnmatch(filename, pattern):
                return False
    
    # No include patterns, and either no exclude patterns or file doesn't match exclude patterns
    return True

def stage_source_files(sources_config, staging_dir, use_absolute_paths=False):
    """
    Pre-stage all source files into a clean staging directory with the exact target structure.
    
    Args:
        sources_config: List of source configurations from YAML
        staging_dir: Path to staging directory (will be created/cleaned)
        use_absolute_paths: Whether to use absolute paths in final .nuspec
        
    Returns:
        int: Number of files staged
    """
    print(f"Pre-staging files to: {staging_dir}")
    
    # Clean and create staging directory
    if os.path.exists(staging_dir):
        print(f"  Cleaning existing staging directory...")
        shutil.rmtree(staging_dir)
    os.makedirs(staging_dir)
    
    files_staged = 0
    
    for source in sources_config:
        source_path = source.get('path', '').strip()
        target_path = source.get('target', '').strip()
        exclude_patterns = source.get('exclude', '')
        include_patterns = source.get('include', '')
        
        if not source_path or not target_path:
            print(f"Warning: Source missing path or target: {source}")
            continue
            
        print(f"Processing source: {source_path} -> {target_path}")
        
        # Handle glob patterns
        if '*' in source_path or '?' in source_path:
            print(f"  Glob pattern detected - expanding files")
            matched_files = glob.glob(source_path, recursive=True)
            
            for matched_file in matched_files:
                if os.path.isfile(matched_file):
                    filename = os.path.basename(matched_file)
                    if should_include_file(filename, include_patterns, exclude_patterns):
                        files_staged += stage_individual_file(matched_file, target_path, staging_dir, source_path)
                        
        elif os.path.isdir(source_path):
            print(f"  Directory source - staging all matching files")
            
            for root, dirs, files in os.walk(source_path):
                for file in files:
                    if should_include_file(file, include_patterns, exclude_patterns):
                        src_file = os.path.join(root, file)
                        files_staged += stage_individual_file(src_file, target_path, staging_dir, source_path)
                        
        elif os.path.isfile(source_path):
            print(f"  Single file source")
            filename = os.path.basename(source_path)
            if should_include_file(filename, include_patterns, exclude_patterns):
                files_staged += stage_individual_file(source_path, target_path, staging_dir, os.path.dirname(source_path))
        else:
            print(f"  Warning: Source path not found: {source_path}")
    
    print(f"SUCCESS: Staged {files_staged} files to staging directory")
    return files_staged


def stage_individual_file(src_file, target_path, staging_dir, source_base_path):
    """
    Stage a single file to the staging directory with proper target structure.
    
    Args:
        src_file: Full path to source file
        target_path: Target path specification from config
        staging_dir: Base staging directory
        source_base_path: Base path to calculate relative paths from
        
    Returns:
        int: 1 if file was staged, 0 if skipped
    """
    try:
        # Calculate relative path from source base (preserve directory structure)
        rel_path = os.path.relpath(src_file, source_base_path)

        # Build target path in staging directory preserving subdirectories
        if target_path in ['.', './']:
            # Place file under staging with its relative path
            target_rel = rel_path
        else:
            # Place file under specified target directory, preserving relative structure
            target_rel = os.path.join(target_path, rel_path)

        target_file = os.path.join(staging_dir, target_rel)

        # Ensure target directory exists
        target_dir = os.path.dirname(target_file)
        os.makedirs(target_dir, exist_ok=True)

        # Copy file to staging
        shutil.copy2(src_file, target_file)
        print(f"  Staged: {src_file} -> {os.path.relpath(target_file, staging_dir)}")
        return 1
        
    except Exception as e:
        print(f"  Error staging file {src_file}: {e}")
        return 0


def get_wildcard_pattern(source_path, target_path, include_patterns, exclude_patterns, use_absolute_paths):
    """
    Generate NuGet wildcard pattern configuration for a directory source.
    
    Returns tuple of (file_entry_dict, info_message)
    """
    # Normalize paths and handle directory flattening
    abs_source_path = source_path
    if use_absolute_paths and not os.path.isabs(source_path):
        abs_source_path = os.path.abspath(source_path)
    
    # For directory sources, we want to flatten contents into target
    # So we modify the pattern to go inside the directory
    source_pattern = abs_source_path.replace('\\', '/')
    
    # Check if this is a directory source that should be flattened
    if os.path.isdir(abs_source_path):
        # For directory: use parent/directory-name/pattern to avoid preserving directory name
        source_pattern = source_pattern.rstrip('/') + '/'
    else:
        # For file patterns, keep as-is
        if not source_pattern.endswith('/'):
            source_pattern += '/'
    
    # Build the wildcard pattern
    includes = [p.strip() for p in include_patterns.split(';') if p.strip()] if include_patterns else []
    
    if len(includes) == 1:
        # Single include pattern - incorporate into source pattern
        pattern = includes[0]
        if pattern.startswith('*.'):
            # Extension pattern: *.dll -> /**/*.dll
            source_pattern += f"**/{pattern}"
        else:
            # Other pattern
            source_pattern += f"**/{pattern}"
    else:
        # No include patterns or multiple (shouldn't reach here, but fallback)
        source_pattern += "**/*"
    
    # Handle target path
    target_pattern = target_path.rstrip('/').rstrip('\\')
    if target_pattern and target_pattern not in ['.', './']:
        target_pattern = target_pattern.replace('\\', '/') + '/'
    else:
        target_pattern = ""  # Root directory
    
    # Handle exclude patterns
    file_entry = {'src': source_pattern, 'target': target_pattern}
    
    if exclude_patterns:
        excludes = [p.strip() for p in exclude_patterns.split(';') if p.strip()]
        nuget_patterns = []
        for pattern in excludes:
            if pattern.startswith('*.'):
                nuget_patterns.append(f"**/{pattern}")
            elif '*' not in pattern and '?' not in pattern:
                nuget_patterns.append(f"**/{pattern}")
            else:
                if not pattern.startswith('**'):
                    nuget_patterns.append(f"**/{pattern}")
                else:
                    nuget_patterns.append(pattern)
        
        if nuget_patterns:
            file_entry['exclude'] = ';'.join(nuget_patterns)
    
    info_msg = f"Using NuGet wildcard: {source_pattern} -> {target_pattern or 'root'}"
    if file_entry.get('exclude'):
        info_msg += f" (excluding: {file_entry['exclude']})"
    
    return file_entry, info_msg

def update_nuspec_files(sources_yaml_path, nuspec_path, use_absolute_paths=False):
    """
    Pre-stage all source files based on sources configuration.
    Creates nupkgStaging directory with exact target structure.
    
    NOTE: The .nuspec file should already contain the hardcoded entry:
        Creates chocoStaging directory with exact target structure.
    
    Usage pattern:
    <file src="chocoStaging/**/*" target=""/>
    
    Args:
        sources_yaml_path: Path to sources YAML configuration file
        nuspec_path: Path to .nuspec file (used to determine staging location)
        use_absolute_paths: Whether to use absolute paths (for staging, usually relative)
    """
    print(f"Processing staging workflow")
    print(f"  Sources config: {sources_yaml_path}")  
    print(f"  NuSpec file: {nuspec_path}")
    
    if not os.path.exists(sources_yaml_path):
        print(f"Sources file not found: {sources_yaml_path}")
        return
    
    if not os.path.exists(nuspec_path):
        print(f"NuSpec file not found: {nuspec_path}")
        return
    
    # Load sources configuration
    with open(sources_yaml_path, 'r') as yaml_file_handle:
        config = yaml.safe_load(yaml_file_handle)
    
    if config is None:
        print("Failed to load YAML configuration")
        return
        
    sources = config.get('sources', [])
    if not sources:
        print("No sources found in configuration")
        return
    
    # Set up staging directory (relative to nuspec location)
    nuspec_dir = os.path.dirname(nuspec_path)
    staging_dir = os.path.join(nuspec_dir, 'chocoStaging')
    print(f"Pre-staging files to: {staging_dir}")
    
    # Stage all source files
    files_staged = stage_source_files(sources, staging_dir, use_absolute_paths)
    
    if files_staged == 0:
        print("WARNING: No files were staged - check your source configurations")
        return
    
    # Show final staging structure
    print(f"\n=== Final Staging Structure ({files_staged} files) ===")
    if os.path.exists(staging_dir):
        for root, dirs, files in os.walk(staging_dir):
            level = root.replace(staging_dir, '').count(os.sep)
            indent = ' ' * 2 * level
            rel_dir = os.path.relpath(root, staging_dir) if root != staging_dir else '.'
            print(f"{indent}{rel_dir}/")
            subindent = ' ' * 2 * (level + 1)
            for file in files:
                file_path = os.path.join(root, file)
                file_size = os.path.getsize(file_path)
                size_str = f"({file_size:,} bytes)" if file_size < 1024*1024 else f"({file_size/(1024*1024):.1f} MB)"
                print(f"{subindent}{file} {size_str}")
    
    print(f"SUCCESS: Files staged successfully - {files_staged} files ready for packaging")
    print("NOTE: .nuspec uses token replacement: <file src=\"#{workspace}#/choco-build/chocoStaging/**/*\" target=\"\"/>")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python3 update_nuspec_files.py <sources.yaml> <package.nuspec> [--absolute-paths]")
        print("Pre-stages all files to chocoStaging/ directory for packaging.")
        print("Template uses token replacement: <file src=\"#{workspace}#/choco-build/chocoStaging/**/*\" target=\"\"/>")
        print("--absolute-paths: Use absolute paths instead of relative (optional)")
        sys.exit(1)
    
    sources_yaml = sys.argv[1]
    nuspec_file = sys.argv[2]
    # Default to relative paths for staging approach
    use_absolute_paths = '--absolute-paths' in sys.argv
    
    update_nuspec_files(sources_yaml, nuspec_file, use_absolute_paths)
