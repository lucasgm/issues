#!/usr/bin/env python3
"""
Script to process dependencies for NuGet package .nuspec file.
This script takes the dependencies YAML configuration and converts it to XML format
suitable for inclusion in a .nuspec file.

Developer-friendly version format (recommended):
  - ">=1.0.0" -> Minimum version 1.0.0 or higher
  - ">1.0.0"  -> Greater than 1.0.0 (excludes 1.0.0)  
  - "<2.0.0"  -> Less than 2.0.0
  - "<=2.0.0" -> Less than or equal to 2.0.0
  - "1.2.3"   -> Exactly version 1.2.3 (no higher/lower)
  - ""        -> Any version (no constraint)

Advanced NuGet format (also supported):
  - "[1.0.0]"      -> Exactly 1.0.0
  - "[1.0.0,)"     -> >= 1.0.0
  - "(,2.0.0)"     -> < 2.0.0
  - "[1.0.0,2.0.0)" -> >= 1.0.0 and < 2.0.0

Example YAML input:
  dependencies:
    - id: "chocolatey-ice.extension"    # No version = any version
    - id: "MinimumPackage"
      version: ">=1.5.0"                # Minimum version
    - id: "ExactPackage" 
      version: "2.1.0"                  # Exactly this version
"""

import os
import yaml
import sys
import xml.etree.ElementTree as ET
from xml.dom import minidom
import re

def convert_rpm_version_to_nuget(version_spec):
    """
    Convert developer-friendly version specifications to NuGet version range format.
    
    Developer-friendly format:
        ">=1.0.0" -> "[1.0.0,)" (minimum version 1.0.0)
        ">1.0.0"  -> "(1.0.0,)" (greater than 1.0.0)
        "<2.0.0"  -> "(,2.0.0)" (less than 2.0.0)
        "<=2.0.0" -> "(,2.0.0]" (less than or equal to 2.0.0)
        "1.2.3"   -> "[1.2.3]"  (exactly version 1.2.3)
        ""        -> ""         (no version constraint)
    
    Legacy support:
        "= 1.0.0" -> "[1.0.0]"  (exactly version 1.0.0)
        "[1.0.0,)" -> "[1.0.0,)" (pass through NuGet format)
    """
    if not version_spec or not version_spec.strip():
        return ""
    
    version_spec = version_spec.strip()
    
    # If it's already in NuGet format (contains brackets/parentheses), return as-is
    if any(char in version_spec for char in ['[', ']', '(', ')']):
        return version_spec
    
    # Match operator-based version specifications
    operator_pattern = r'^(>=|<=|>|<|=)\s*(.+)$'
    match = re.match(operator_pattern, version_spec)
    
    if match:
        operator, version = match.groups()
        version = version.strip()
        
        if operator == '>=':
            return f"[{version},)"
        elif operator == '=':
            return f"[{version}]"
        elif operator == '>':
            return f"({version},)"
        elif operator == '<':
            return f"(,{version})"
        elif operator == '<=':
            return f"(,{version}]"
    
    # If no operator specified, treat as EXACT version (developer-friendly)
    # This is different from NuGet default behavior but more intuitive for developers
    return f"[{version_spec}]"

def process_dependencies(dependencies_file, output_file, target_framework=""):
    """
    Process dependencies from YAML format to NuGet .nuspec XML format.
    
    Args:
        dependencies_file: Path to YAML file containing dependencies
        output_file: Path to output XML file
        target_framework: Target framework for the dependencies
    """
    try:
        with open(dependencies_file, 'r') as file:
            yaml_content = yaml.safe_load(file)
            dependencies = yaml_content.get('dependencies', [])
    except yaml.YAMLError as e:
        print(f"Error parsing YAML file: {e}")
        # Create empty output file
        with open(output_file, 'w') as empty_file_handle:
            empty_file_handle.write("")
        return
    except FileNotFoundError:
        print(f"Dependencies file not found: {dependencies_file}")
        # Create empty output file
        with open(output_file, 'w') as empty_file_handle:
            empty_file_handle.write("")
        return

    # Determine unique target frameworks used by user dependencies
    user_frameworks = set()
    for dep in dependencies:
        if 'targetFramework' in dep and dep['targetFramework']:
            user_frameworks.add(dep['targetFramework'])
    
    # Decision logic based on your requirements:
    # 1. No targetFramework specified → Simple dependencies (no groups)
    # 2. One targetFramework used → Single group with chocolatey-ice.extension
    # 3. Multiple targetFrameworks → Multiple groups, chocolatey-ice.extension in each
    
    default_framework = target_framework or 'net40'
    
    if len(user_frameworks) == 0:
        # Case 1: No targetFramework specified - simple dependencies
        print("No targetFramework specified, generating simple dependencies")
        dependency_elements = []
        
        # Add chocolatey-ice.extension first
        ice_dep = ET.Element('dependency')
        ice_dep.set('id', 'chocolatey-ice.extension')
        dependency_elements.append(ice_dep)
        
        # Add user dependencies
        for dep in dependencies:
            dep_elem = ET.Element('dependency')
            dep_elem.set('id', dep.get('id', ''))
            
            dep_version = dep.get('version', '')
            if dep_version:
                dep_version = convert_rpm_version_to_nuget(dep_version)
                dep_elem.set('version', dep_version)
                
            if dep.get('include'):
                dep_elem.set('include', dep['include'])
            if dep.get('exclude'):
                dep_elem.set('exclude', dep['exclude'])
                
            dependency_elements.append(dep_elem)
            
    else:
        # Case 2 & 3: One or multiple targetFrameworks - use groups
        print(f"Multiple targetFrameworks detected: {user_frameworks}, generating groups")
        
        # Separate dependencies into framework-specific and universal
        framework_specific_deps = {}
        universal_deps = []
        
        for dep in dependencies:
            if 'targetFramework' in dep and dep['targetFramework']:
                # Framework-specific dependency
                framework = dep['targetFramework']
                if framework not in framework_specific_deps:
                    framework_specific_deps[framework] = []
                framework_specific_deps[framework].append(dep)
            else:
                # Universal dependency (no targetFramework specified)
                universal_deps.append(dep)
        
        # Determine all frameworks we need to create groups for
        all_frameworks = set(user_frameworks)
        if not all_frameworks:
            # If no user frameworks, use default framework
            all_frameworks.add(default_framework)
        
        # Generate group elements
        dependency_elements = []
        
        for framework in all_frameworks:
            group_elem = ET.Element('group')
            group_elem.set('targetFramework', framework)
            
            # Add chocolatey-ice.extension to each group
            ice_dep = ET.SubElement(group_elem, 'dependency')
            ice_dep.set('id', 'chocolatey-ice.extension')
            
            # Add universal dependencies to each group (dependencies without targetFramework)
            for dep in universal_deps:
                dep_elem = ET.SubElement(group_elem, 'dependency')
                dep_elem.set('id', dep.get('id', ''))
                
                dep_version = dep.get('version', '')
                if dep_version:
                    dep_version = convert_rpm_version_to_nuget(dep_version)
                    dep_elem.set('version', dep_version)
                    
                if dep.get('include'):
                    dep_elem.set('include', dep['include'])
                if dep.get('exclude'):
                    dep_elem.set('exclude', dep['exclude'])
            
            # Add framework-specific dependencies to their respective groups
            if framework in framework_specific_deps:
                for dep in framework_specific_deps[framework]:
                    dep_elem = ET.SubElement(group_elem, 'dependency')
                    dep_elem.set('id', dep.get('id', ''))
                    
                    dep_version = dep.get('version', '')
                    if dep_version:
                        dep_version = convert_rpm_version_to_nuget(dep_version)
                        dep_elem.set('version', dep_version)
                        
                    if dep.get('include'):
                        dep_elem.set('include', dep['include'])
                    if dep.get('exclude'):
                        dep_elem.set('exclude', dep['exclude'])
                        
            dependency_elements.append(group_elem)
    
    # Convert elements to formatted XML strings
    if dependency_elements:
        xml_lines = []
        for elem in dependency_elements:
            # Simple approach: manually build the XML string
            if elem.tag == 'dependency':
                attrs = []
                for key, value in elem.attrib.items():
                    attrs.append(f'{key}="{value}"')
                attr_str = ' '.join(attrs)
                xml_lines.append(f'      <dependency {attr_str}/>')
            elif elem.tag == 'group':
                # Handle group elements (for multiple frameworks)
                group_attrs = []
                for key, value in elem.attrib.items():
                    group_attrs.append(f'{key}="{value}"')
                group_attr_str = ' '.join(group_attrs) if group_attrs else ''
                
                if group_attr_str:
                    xml_lines.append(f'      <group {group_attr_str}>')
                else:
                    xml_lines.append(f'      <group>')
                
                for dep_elem in elem:
                    dep_attrs = []
                    for key, value in dep_elem.attrib.items():
                        dep_attrs.append(f'{key}="{value}"')
                    dep_attr_str = ' '.join(dep_attrs)
                    xml_lines.append(f'        <dependency {dep_attr_str}/>')
                
                xml_lines.append('      </group>')
        
        final_xml = '\n'.join(xml_lines)
    else:
        # Handle case where no dependencies were provided - still need chocolatey-ice.extension
        final_xml = '      <dependency id="chocolatey-ice.extension"/>'
    
    # Write to output file
    with open(output_file, 'w', encoding='utf-8') as output_file_handle:
        output_file_handle.write(final_xml)
    
    print(f"Processed {len(dependencies)} dependencies into {output_file}")

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python process_dependencies.py <dependencies_file> <output_file> [target_framework]")
        sys.exit(1)
    
    dependencies_file = sys.argv[1]
    output_file = sys.argv[2]
    target_framework = sys.argv[3] if len(sys.argv) > 3 else ""
    
    process_dependencies(dependencies_file, output_file, target_framework)
