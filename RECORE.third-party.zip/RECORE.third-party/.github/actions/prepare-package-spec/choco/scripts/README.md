# NuGet Package Processing Scripts

This directory contains Python scripts used for processing and preparing NuGet package specifications.

## Scripts Overview

### parse_inputs.py
**New modular input parser** - Safely parses GitHub Actions inputs and creates YAML configuration files:
- Handles quotes, brackets, and special characters without shell conflicts
- Converts raw GitHub Actions inputs to properly formatted YAML files
- Supports both sources and dependencies configuration
- Features proper error handling and UTF-8 support
- Usage: `echo "$INPUT" | python parse_inputs.py <type> <output_file>`

### copy_to_nuget.py
Handles copying source files to the NuGet package build directory:
- Processes source configuration from YAML
- Copies files to appropriate package structure
- Handles file organization and directory creation

### update_nuspec_files.py
**Pre-Staging NuSpec Processor** - Eliminates NuGet path complexity with clean staging approach:
- **Pre-stages all files**: Copies source files to `nupkgStaging/` directory with exact target structure
- **Simple .nuspec generation**: Creates single `<file src="nupkgStaging/**/*" target=""/>` entry
- **Clean execution**: Runs `nuget pack` from staging directory for predictable paths
- **Developer-friendly**: Simple `path` + `target` configuration with intelligent flattening
- **No NuGet path quirks**: Avoids wildcard path preservation issues entirely
- Supports include/exclude patterns and all source types (files, directories, globs)

### process_dependencies.py
Processes NuGet package dependencies:
- Converts dependency configuration to XML format
- Handles target framework specifications
- Generates properly formatted dependency elements for .nuspec files

### process_contentfiles.py
Processes content files configuration:
- Converts content files configuration to XML format
- Handles content file inclusion patterns
- Generates content files elements for .nuspec files

### clean_nuspec.py
Cleans and validates the generated .nuspec file:
- Removes empty XML elements
- Validates XML structure
- Ensures proper formatting for NuGet package creation

## Usage

These scripts are called automatically during the GitHub Action execution and process various configuration inputs to generate a complete NuGet package structure.
