# Chocolatey Package (.nupkg) Spec File Generation Action

This action generates `.nuspec` files for Chocolatey package creation as part of the `Prepare Spec File Action` composite action. It follows the same pattern as the RPM spec file generation but is specifically designed for Chocolatey packages.

## Overview

The action processes configuration inputs and generates a properly formatted `.nuspec` file with:
- Package metadata (name, version, authors, description, etc.)
- Dependencies management with target framework support
- File inclusion patterns based on sources configuration
- Content files configuration for advanced scenarios
- Chocolatey install/uninstall scripts
- Automatic cleanup and validation

## Inputs

### Required Inputs

| Input | Description | Default |
|-------|-------------|---------|
| `packageName` | Name of the Chocolatey package | - |
| `version` | Version of the Chocolatey package | - |
| `authors` | Authors of the Chocolatey package | `RE-Core` |
| `description` | Description of the Chocolatey package | `Auto-generated Chocolatey package` |
| `sources` | Sources configuration in JSON/YAML format for files to include | - |

### Optional Inputs

| Input | Description | Default |
|-------|-------------|---------|
| `title` | Title of the Chocolatey package | `packageName` if not provided |
| `owners` | Owners of the Chocolatey package | - |
| `copyright` | Copyright information | - |
| `licenseUrl` | URL to the license | - |
| `projectUrl` | URL to the project homepage | - |
| `iconUrl` | URL to the package icon | - |
| `requireLicenseAcceptance` | Whether license acceptance is required | `false` |
| `tags` | Space-separated list of tags | - |
| `releaseNotes` | Release notes for the package | - |
| `dependencies` | Dependencies in JSON/YAML format | - |
| `targetFramework` | Target framework (e.g., net6.0, netstandard2.0) | - |
| `packageType` | Package type (e.g., Dependency, Tool) | `Dependency` |
| `developmentDependency` | Whether this is a development dependency | `false` |
| `contentFiles` | Content files configuration in JSON/YAML format | - |
| `minClientVersion` | Minimum NuGet client version required | - |

## Sources Configuration

The `sources` input should be provided in YAML format and defines which files to include in the Chocolatey package:

```yaml
sources:
  - path: "build/output/**/*.dll"
    target: "lib/net6.0"
    exclude: 
      - "*.pdb"
      - "*.xml"
  - path: "docs/README.md"
    target: "."
    target_file: "README.md"
  - path: "content/**/*"
    target: "contentFiles/any/any"
```

### Sources Properties

- `path`: Source file or directory pattern (supports wildcards)
- `target`: Target directory in the Chocolatey package
- `target_file`: Optional specific filename in target directory
- `exclude`: List of patterns to exclude
- `include`: Pattern for files to include (default: `**`)

## Chocolatey Scripts Integration

The action automatically includes Chocolatey installation/uninstallation scripts that provide:

- **Standard ICE installation behavior** (copy files, set PATH, etc.)
- **Support for custom application-specific scripts**
- **Installer executable detection for third-party packages**
- **Custom installation path support**
- **Comprehensive error handling and logging**

### Inputs for Chocolatey Scripts

| Input | Description | Default |
|-------|-------------|---------|
| `includeChocolateyScripts` | Whether to include Chocolatey scripts | `true` |
| `customInstallScript` | Path to custom installation PowerShell script | - |
| `customUninstallScript` | Path to custom uninstallation PowerShell script | - |
| `installerExecutableName` | Specific installer executable name in tools directory (optional) | - |
| `customSilentArgs` | Custom silent installation arguments (optional) | - |
| `uninstallerExecutableName` | Specific uninstaller executable name (optional) | - |
| `customUninstallArgs` | Custom silent uninstallation arguments (optional) | - |
| `customInstallPath` | Custom installation directory path override (optional) | - |

### Installer Executable Detection

For third-party packages where you need to run a specific installer:

```yaml
- name: Prepare Package Spec
  uses: ./actions/prepare-package-spec/choco
  with:
    packageName: "MyThirdPartyApp"
    version: "1.0.0"
    installerExecutableName: "setup.exe"
    customSilentArgs: "/VERYSILENT /NORESTART"
    uninstallerExecutableName: "unins000.exe"
    customUninstallArgs: "/VERYSILENT"
```

### Custom Installation Path

Override the default Program Files installation location:

```yaml
- name: Prepare Package Spec
  uses: ./actions/prepare-package-spec/choco
  with:
    packageName: "Gitclient"
    version: "2.35.1"
    customInstallPath: "D:\\ICETools\\Gitclient-2.35"
```

**Benefits:**
- Version-specific installations for side-by-side deployments
- Custom drive/partition installations
- Organizational directory standards compliance

**Path Resolution Logic:**
1. If `customInstallPath` is provided and not empty → use custom path
2. Otherwise → use default `C:\Program Files\{PackageName}`

Both install and uninstall scripts use identical path resolution for consistent cleanup.

## Dependencies Configuration

The `dependencies` input should be provided in YAML format:

```yaml
dependencies:
  - id: "Newtonsoft.Json"
    version: "13.0.1"
    targetFramework: "net6.0"
  - id: "Microsoft.Extensions.Logging"
    version: "[2.0.0,3.0.0)"
    targetFramework: "netstandard2.0"
    include: "all"
    exclude: "build,analyzers"
```

### Dependencies Properties

- `id`: Package ID (required)
- `version`: Version constraint (optional)
- `targetFramework`: Target framework (uses action's targetFramework if not specified)
- `include`: Assets to include (optional)
- `exclude`: Assets to exclude (optional)

## Content Files Configuration

The `contentFiles` input should be provided in YAML format for advanced content file scenarios:

```yaml
contentFiles:
  - include: "contentFiles/any/any/**/*.txt"
    buildAction: "Content"
    copyToOutput: "true"
  - include: "contentFiles/cs/any/**/*.cs"
    buildAction: "Compile"
```

### Content Files Properties

- `include`: File pattern to include (required)
- `exclude`: File pattern to exclude (optional)
- `buildAction`: Build action (Content, Compile, None, etc.)
- `copyToOutput`: Whether to copy to output directory
- `flatten`: Whether to flatten the directory structure

## Example Usage

```yaml
- name: Prepare Chocolatey Package Spec
  uses: ./actions/prepare-package-spec/choco
  with:
    packageName: "MyCompany.MyLibrary"
    version: "1.2.3"
    title: "My Library"
    authors: "MyCompany Development Team"
    description: "A useful library for doing amazing things"
    copyright: "© 2025 MyCompany"
    projectUrl: "https://github.com/mycompany/mylibrary"
    tags: "library utility helpers"
    targetFramework: "net6.0"
    sources: |
      sources:
        - path: "src/bin/Release/**/*.dll"
          target: "lib/net6.0"
        - path: "docs/**/*.md"
          target: "docs"
    dependencies: |
      dependencies:
        - id: "Newtonsoft.Json"
          version: "13.0.1"
        - id: "Microsoft.Extensions.DependencyInjection"
          version: "[6.0.0,7.0.0)"
```

## Output

The action creates:
- `nuget-build/{packageName}.nuspec`: The generated NuSpec file
- File structure in `nuget-build/` directory matching the sources configuration

## File Structure

```
nuget-build/
├── MyLibrary.nuspec
├── lib/
│   └── net6.0/
│       ├── MyLibrary.dll
│       └── MyLibrary.deps.json
├── docs/
│   └── README.md
└── contentFiles/
    └── any/
        └── any/
            └── config.txt
```

## Integration with Packaging Workflows

This action is designed to be used as part of a larger NuGet packaging workflow:

```yaml
jobs:
  build-and-package:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Build Application
        run: dotnet build --configuration Release
      
      - name: Prepare Package Spec
        uses: ./actions/prepare-package-spec/choco
        with:
          packageName: ${{ github.event.repository.name }}
          version: ${{ needs.version.outputs.version }}
          sources: |
            sources:
              - path: "src/bin/Release/**/*.dll"
                target: "lib/net6.0"
      
      - name: Create Chocolatey Package
        run: nuget pack nuget-build/${{ github.event.repository.name }}.nuspec -OutputDirectory packages/
      
      - name: Upload Package
        uses: actions/upload-artifact@v4
        with:
          name: nuget-package
          path: packages/*.nupkg
```

## Differences from PoC Implementation

This implementation improves upon the existing PoC in several ways:

1. **Structured Configuration**: Uses YAML for complex configurations instead of inline strings
2. **Advanced Dependencies**: Supports framework-specific dependencies and asset inclusion/exclusion
3. **Content Files**: Supports advanced content files configuration
4. **File Management**: Automatic file copying and .nuspec file updates
5. **Validation**: Input validation and error handling
6. **Cleanup**: Automatic cleanup of empty XML elements
7. **Extensibility**: Modular design with separate Python scripts for different concerns
8. **Consistency**: Follows the same pattern as the RPM implementation

## Python Scripts

The action uses several Python scripts for processing:

- `copy_to_nuget.py`: Copies files based on sources configuration
- `process_dependencies.py`: Converts dependencies YAML to XML format
- `process_contentfiles.py`: Converts content files YAML to XML format
- `clean_nuspec.py`: Cleans up the final .nuspec file

These scripts can be extended or modified as needed for specific requirements.