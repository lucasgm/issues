# NuGet Package Templates

This directory contains template files used for NuGet package generation.

## Templates Overview

### template.nuspec
The main NuGet package specification template:
- Contains token placeholders for package metadata
- Uses `#{tokenName}#` format for token replacement
- Defines package structure, dependencies, and content files
- Processed by GitHub Action to generate final .nuspec file

### chocolateyInstall.ps1
Standard Chocolatey installation script template:
- Provides standard installation logic for ICE applications
- Environment variable setup and validation
- Application directory creation and file deployment
- System PATH updates and Windows Registry registration
- Custom installation script execution support
- Uses token replacement for package-specific values

### chocolateyUninstall.ps1
Standard Chocolatey uninstallation script template:
- Provides standard uninstallation logic for ICE applications
- Custom uninstallation script execution
- Application process termination and cleanup
- System PATH cleanup and registry entry removal
- Installation directory removal and state tracking
- Uses token replacement for package-specific values

## Token Replacement

All templates use token replacement during GitHub Action execution:
- `#{packageName}#` - Replaced with the actual package name
- `#{version}#` - Replaced with the package version
- `#{title}#` - Replaced with the package title
- `#{authors}#` - Replaced with package authors
- `#{description}#` - Replaced with package description
- And many other metadata tokens...

## Environment Variables (PowerShell Templates)

The PowerShell templates use standard Chocolatey environment variables:
- `$env:CHOCOLATEYPACKAGENAME` - Package name from Chocolatey
- `$env:CHOCOLATEYPACKAGEVERSION` - Package version from Chocolatey  
- `$env:CHOCOLATEYINSTALL` - Chocolatey installation directory
- `$env:PROGRAMFILES` - Windows Program Files directory
- `$env:USERPROFILE` - Current user profile directory

## Custom Script Integration

The PowerShell templates support optional custom scripts:
- `customInstall.ps1` - Application-specific installation logic
- `customUninstall.ps1` - Application-specific uninstallation logic

These custom scripts should be provided via action inputs and will be copied to the package's tools directory.
