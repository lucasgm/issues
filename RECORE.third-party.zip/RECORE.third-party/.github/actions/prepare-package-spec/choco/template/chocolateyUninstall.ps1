# Standard Chocolatey Uninstall Script for ICE Applications
# This script provides simplified uninstallation logic for ICE applications

$ErrorActionPreference = 'Stop'

Write-Host " "
Write-Host "*************************** Uninstall Initiated ****************************"

#==============================================================================================================
# 0. ICE run-installer model (opt-in via tools\set_env_variables.ps1)
#==============================================================================================================
# Mirror of the install script: when tools\set_env_variables.ps1 is present, run
# the vendor uninstaller, purge $appDir, remove the registry entry, and drop the
# first-run marker. Packages without that file fall through to the generic flow.
$packageName    = if ($env:CHOCOLATEYPACKAGENAME) { $env:CHOCOLATEYPACKAGENAME } else { "#{packageName}#" }
$packageVersion = if ($env:CHOCOLATEYPACKAGEVERSION) { $env:CHOCOLATEYPACKAGEVERSION } else { "#{version}#" }
$sourceLocation = "$env:CHOCOLATEYINSTALL\lib\$packageName"
$toolsLocation  = "$sourceLocation\tools"
$iceConfig      = Join-Path $toolsLocation "set_env_variables.ps1"
if (Test-Path $iceConfig) {
    Write-Host "ICE run-installer model detected (tools\set_env_variables.ps1)."
    # Brings in: $appDir, $softwareName, $executable, $fileType,
    #            $uninstallSilentArgs, $uninstallValidExitCodes.
    . $iceConfig

    if (($fileType -in 'exe','msi') -and $executable -and (Test-Path -Path "$appDir\$executable" -PathType Leaf)) {
        $packageArgs = @{
            packageName    = $packageName
            fileType       = $fileType
            file           = "$appDir\$executable"
            softwareName   = "$softwareName*"
            silentArgs     = $uninstallSilentArgs
            validExitCodes = $uninstallValidExitCodes
        }
        Write-Host "Found uninstaller executable, uninstalling now."
        Uninstall-ChocolateyPackage @packageArgs
        Start-Sleep -Seconds 10
    } else {
        Write-Host "Uninstall executable not found / not applicable. Skipping uninstall."
    }

    # Purge app dir.
    if (Test-Path $appDir) {
        Write-Host "Purging deployment path: $appDir"
        Get-ChildItem -Path $appDir -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 10
        Remove-Item -Path $appDir -Force -Recurse -ErrorAction SilentlyContinue
    } else {
        Write-Host "AppDir $appDir doesn't exist. Nothing to purge."
    }

    # Remove registry entry (chocolatey-ice.extension) + write first-run marker.
    # Best-effort (see install script) — skip when the extension isn't installed.
    if (Get-Command RemoveRegistryKey -ErrorAction SilentlyContinue) {
        RemoveRegistryKey "$packageName"
    } else {
        Write-Warning "RemoveRegistryKey unavailable (chocolatey-ice.extension not installed); skipping registry cleanup."
    }
    $checkForFile = "$env:USERPROFILE\$packageName.txt"
    $fileValue = "File created by chocolatey uninstall script. Removed automatically when chocolatey runs the Install script."
    Remove-Item -Path $checkForFile -Force -ErrorAction SilentlyContinue
    New-Item -Path $env:USERPROFILE -Name "$packageName.txt" -ItemType "file" -Value "$fileValue" -Force -ErrorAction SilentlyContinue | Out-Null

    Write-Host "*************************** Uninstall Completed (ICE) ****************************"
    return
}

#==============================================================================================================
# 1. Setup Variables
#==============================================================================================================
Write-Host " "
Write-Host "----------------------------------------------------------------"
Write-Host " Setup Uninstallation Variables                                  "
Write-Host "----------------------------------------------------------------"

# Standard Chocolatey variables
$scriptPath = Split-Path $MyInvocation.MyCommand.Definition
$packageName = if ($env:CHOCOLATEYPACKAGENAME) { $env:CHOCOLATEYPACKAGENAME } else { "#{packageName}#" }
$packageVersion = if ($env:CHOCOLATEYPACKAGEVERSION) { $env:CHOCOLATEYPACKAGEVERSION } else { "#{version}#" }
$sourceLocation = "$env:CHOCOLATEYINSTALL\lib\$packageName"
$toolsLocation = "$sourceLocation\tools"

# ICE standard installation directory
$installPath = Join-Path $env:PROGRAMFILES $packageName

# Optional: Custom installation path override
$customInstallPath = "#{customInstallPath}#"  # Will be empty if not specified
if ($customInstallPath) {
    $installPath = $customInstallPath
    Write-Host "Using custom installation path: $installPath"
} else {
    Write-Host "Using default installation path: $installPath"
}

Write-Host "Package Name: $packageName"
Write-Host "Package Version: $packageVersion"
Write-Host "Installation Path: $installPath"

#==============================================================================================================
# 2. Execute Custom Uninstallation Script First
#==============================================================================================================
Write-Host " "
Write-Host "----------------------------------------------------------------"
Write-Host " Execute Custom Uninstallation Script (if provided)              "
Write-Host "----------------------------------------------------------------"

$customUninstallScript = Join-Path $toolsLocation "customUninstall.ps1"
if (Test-Path $customUninstallScript) {
    Write-Host "Executing custom uninstallation script..." -ForegroundColor Cyan
    try {
        & $customUninstallScript -InstallPath $installPath -PackageName $packageName -Version $packageVersion
        Write-Host "Custom uninstallation script completed successfully!" -ForegroundColor Green
    } catch {
        Write-Warning "Custom uninstallation script failed: $($_.Exception.Message)"
        Write-Host "Continuing with standard uninstallation..." -ForegroundColor Yellow
    }
} else {
    Write-Host "No custom uninstallation script found, skipping custom steps"
}

#==============================================================================================================
# 3. Remove Installation Directory
#==============================================================================================================
Write-Host " "
Write-Host "----------------------------------------------------------------"
Write-Host " Remove Installation Directory                                   "
Write-Host "----------------------------------------------------------------"

if (Test-Path $installPath) {
    try {
        Write-Host "Removing installation directory: $installPath"
        Remove-Item -Path $installPath -Recurse -Force -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        
        # Verify removal
        if (!(Test-Path $installPath)) {
            Write-Host "Installation directory removed successfully!" -ForegroundColor Green
        } else {
            Write-Warning "Could not completely remove installation directory. Some files may be in use."
        }
    } catch {
        Write-Warning "Error removing installation directory: $($_.Exception.Message)"
    }
} else {
    Write-Host "Installation directory not found, may have been already removed"
}

Write-Host " "
Write-Host "*************************** Uninstall Completed ****************************" -ForegroundColor Green
Write-Host " "
