# Standard Chocolatey Install Script for ICE Applications
# This script provides simplified installation logic for ICE applications

$ErrorActionPreference = 'Stop'

Write-Host " "
Write-Host "*************************** Installation Initiated ****************************"

#==============================================================================================================
# 0. ICE run-installer model (opt-in via tools\set_env_variables.ps1)
#==============================================================================================================
# When the package ships a generated tools\set_env_variables.ps1 (built by the
# RECORE.third-party Windows package workflow), run the ORIGINAL vendor installer
# into $appDir (e.g. D:\ICETools\<name>) instead of the generic copy-to-Program-
# Files flow below. Packages without that file (e.g. via the shared choco.yml)
# fall through to the standard behaviour unchanged.
$packageName    = if ($env:CHOCOLATEYPACKAGENAME) { $env:CHOCOLATEYPACKAGENAME } else { "#{packageName}#" }
$packageVersion = if ($env:CHOCOLATEYPACKAGEVERSION) { $env:CHOCOLATEYPACKAGEVERSION } else { "#{version}#" }
$sourceLocation = "$env:CHOCOLATEYINSTALL\lib\$packageName"
$toolsLocation  = "$sourceLocation\tools"
$contentLocation = "$sourceLocation\content"
$iceConfig      = Join-Path $toolsLocation "set_env_variables.ps1"
if (Test-Path $iceConfig) {
    Write-Host "ICE run-installer model detected (tools\set_env_variables.ps1)."
    # Brings in: $appDir, $softwareName, $executable, $fileType,
    #            $installSilentArgs, $installValidExitCodes.
    . $iceConfig

    $uninstallScript = Join-Path $toolsLocation "chocolateyUninstall.ps1"

    # First-time deployment: run uninstall first when no marker exists.
    $checkForFile = "$env:USERPROFILE\$packageName.txt"
    if (!(Test-Path -Path $checkForFile -PathType Leaf)) {
        Write-Host "First-time deployment of $packageName. Invoking uninstall first."
        if (Test-Path $uninstallScript) { & $uninstallScript }
    }

    # Create app dir and deploy content there.
    if (!(Test-Path $appDir)) {
        Write-Host "Creating Folder: $appDir"
        New-Item -ItemType Directory -Force -Path $appDir | Out-Null
    }
    Copy-Item ($contentLocation + "\*") -Destination $appDir -Force -Recurse -Exclude @('.chocolateyPending','*.exe.ignore')
    Start-Sleep -Seconds 10
    Get-ChildItem -Path $contentLocation -Recurse | Remove-Item -Force -Recurse -ErrorAction SilentlyContinue

    # Enable Win32 long paths.
    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -Value 1

    # Run the vendor installer silently (exe/msi). For a zip the archive IS the
    # payload, so we expand it in place rather than running an installer.
    if (($fileType -in 'exe','msi') -and $executable) {
        $packageArgs = @{
            packageName    = $packageName
            fileType       = $fileType
            file           = "$appDir\$executable"
            softwareName   = "$softwareName*"
            silentArgs     = $installSilentArgs
            validExitCodes = $installValidExitCodes
        }
        Install-ChocolateyInstallPackage @packageArgs
        Start-Sleep -Seconds 10
    } elseif ($fileType -eq 'zip' -and $executable) {
        # A zip package has no installer to run: the copy above placed the archive
        # under $appDir. Expand it in place, then remove the archive so only the
        # extracted payload remains.
        $zipPath = Join-Path $appDir $executable
        if (Test-Path $zipPath) {
            Write-Host "Expanding archive '$executable' into $appDir ..."
            Expand-Archive -Path $zipPath -DestinationPath $appDir -Force
            Remove-Item -Path $zipPath -Force -ErrorAction SilentlyContinue

            # Many vendor zips (e.g. OpenJDK) wrap everything in a single top-level
            # folder (jdk-<ver>\). Flatten that one level so the payload sits
            # directly under $appDir (…\bin\java.exe), matching the ICE layout.
            $entries = Get-ChildItem -Path $appDir -Force
            if ($entries.Count -eq 1 -and $entries[0].PSIsContainer) {
                $top = $entries[0].FullName
                Write-Host "Flattening single top-level folder '$($entries[0].Name)' into $appDir"
                Get-ChildItem -Path $top -Force | Move-Item -Destination $appDir -Force
                Remove-Item -Path $top -Force -Recurse -ErrorAction SilentlyContinue
            }
            Start-Sleep -Seconds 5
        } else {
            Write-Warning "Expected archive '$executable' not found under $appDir; nothing to expand."
        }
    } else {
        Write-Host "fileType '$fileType' has no installer to run; content deployed to $appDir."
    }

    # Registry entry (function from chocolatey-ice.extension) + clear marker.
    # Best-effort: present in production (the extension is a declared dependency);
    # skipped with a warning where it isn't installed (e.g. sandbox validation).
    if (Get-Command SetRegistryKey -ErrorAction SilentlyContinue) {
        SetRegistryKey "$packageName" "$packageVersion" "$uninstallScript"
    } else {
        Write-Warning "SetRegistryKey unavailable (chocolatey-ice.extension not installed); skipping registry entry."
    }
    Remove-Item -Path $checkForFile -Force -ErrorAction SilentlyContinue

    Write-Host "*************************** Install Completed (ICE) ******************************"
    return
}

#==============================================================================================================
# 1. Setup Variables
#==============================================================================================================
Write-Host " "
Write-Host "----------------------------------------------------------------"
Write-Host " Setup Installation Variables                                    "
Write-Host "----------------------------------------------------------------"

# Standard Chocolatey variables
$scriptPath = Split-Path $MyInvocation.MyCommand.Definition
$packageName = if ($env:CHOCOLATEYPACKAGENAME) { $env:CHOCOLATEYPACKAGENAME } else { "#{packageName}#" }
$packageVersion = if ($env:CHOCOLATEYPACKAGEVERSION) { $env:CHOCOLATEYPACKAGEVERSION } else { "#{version}#" }
$sourceLocation = "$env:CHOCOLATEYINSTALL\lib\$packageName"
$toolsLocation = "$sourceLocation\tools"

# Optional: Custom installation directory (if different from standard Program Files location)
$customInstallPath = "#{customInstallPath}#"  # Will be empty if not specified

# Determine installation directory
if ($customInstallPath) {
    $installPath = $customInstallPath
    Write-Host "Using custom installation directory: $installPath" -ForegroundColor Cyan
} else {
    # Standard installation directory
    $installPath = Join-Path $env:PROGRAMFILES $packageName
    Write-Host "Using standard installation directory: $installPath"
}

Write-Host "Package Name: $packageName"
Write-Host "Package Version: $packageVersion"
Write-Host "Installation Path: $installPath"

#==============================================================================================================
# 2. Create and Setup Application Directory
#==============================================================================================================
Write-Host " "
Write-Host "----------------------------------------------------------------"
Write-Host " Create and Setup Application Directory                          "
Write-Host "----------------------------------------------------------------"

if (!(Test-Path $installPath)) {
    Write-Host "Creating installation directory: $installPath"
    New-Item -ItemType Directory -Force -Path $installPath | Out-Null
    Write-Host "Created installation directory successfully"
} else {
    Write-Host "Installation directory already exists: $installPath"
}

#==============================================================================================================
# 3. Deploy Application Files
#==============================================================================================================
Write-Host " "
Write-Host "----------------------------------------------------------------"
Write-Host " Deploy Application Files                                        "
Write-Host "----------------------------------------------------------------"

try {
    # Get package directory (parent of tools)
    $packageDir = Split-Path $toolsLocation -Parent
    
    # Define literal name exclusions; handle wildcards in the filter below
    $excludeLiteral = @('.chocolateyPending', "${packageName}.nuspec")
    Write-Host "Copying files from package to installation directory..."
    Write-Host "Source: $packageDir"
    Write-Host "Destination: $installPath"
    
    # Copy all files except tools directory and exclusions
    Get-ChildItem -Path $packageDir -Recurse | Where-Object {
        $_.FullName -notlike "*\tools\*" -and 
        $_.Name -notin $excludeLiteral -and
        $_.Name -notlike "${packageName}*.nupkg" -and
        $_.Name -notlike '*.exe.ignore'
    } | ForEach-Object {
        $dest = $_.FullName.Replace($packageDir, $installPath)
        $destDir = Split-Path $dest -Parent
        
        if (!(Test-Path $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        
        if (!$_.PSIsContainer) {
            Copy-Item $_.FullName -Destination $dest -Force
        }
    }
    
    Write-Host "File deployment completed successfully"
    
} catch {
    Write-Error "File deployment failed: $($_.Exception.Message)"
    throw
}

#==============================================================================================================
# 4. Execute Custom Installation Script (if provided)
#==============================================================================================================
Write-Host " "
Write-Host "----------------------------------------------------------------"
Write-Host " Execute Custom Installation Script (if provided)                "
Write-Host "----------------------------------------------------------------"

$customInstallScript = Join-Path $toolsLocation "customInstall.ps1"
if (Test-Path $customInstallScript) {
    Write-Host "Executing custom installation script..." -ForegroundColor Cyan
    try {
        & $customInstallScript -InstallPath $installPath -PackageName $packageName -Version $packageVersion
        Write-Host "Custom installation script completed successfully!" -ForegroundColor Green
    } catch {
        Write-Warning "Custom installation script failed: $($_.Exception.Message)"
        Write-Host "Continuing with standard installation..." -ForegroundColor Yellow
    }
} else {
    Write-Host "No custom installation script found, skipping custom steps"
}

Write-Host " "
Write-Host "*************************** Install Completed ******************************" -ForegroundColor Green
Write-Host " "
