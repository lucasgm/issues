import os
import yaml
import shutil
import sys
import glob  # Import glob for wildcard support

# List of adapter names that require copying the initscript
VALID_ADAPTERS = [
    "apache22", "containerless", "jboss6", "jbosseap43", "mq",
    "nginx", "redis", "springboot", "tomcat6", "tomcat7"
]

def copy_to_sources(sources_file, sources_dir, adapter_name, adapter_dir, rcname):
    # Ensure the SOURCES directory exists
    os.makedirs(sources_dir, exist_ok=True)

    # Handle special case for adapter-specific initscript first
    if adapter_name in VALID_ADAPTERS:
        handle_adapter_initscript(adapter_dir, sources_dir, rcname)
    else:
        print(f"Adapter '{adapter_name}' is not in the list of valid adapters. Skipping initscript copy.")

    # Parse the YAML input from the file
    try:
        with open(sources_file, 'r') as file:
            yaml_content = yaml.safe_load(file)
            sources = yaml_content.get('sources', [])
    except yaml.YAMLError as e:
        print(f"Error parsing YAML file: {e}")
        sys.exit(1)

    # Process each entry in the sources.yaml file
    for entry in sources:
        entry_path = entry.get('path')
        destination_dir = entry.get('destination_dir')
        destination_file = entry.get('destination_file')
        exclude_patterns = entry.get('exclude', [])

        if not entry_path:
            print("Warning: 'path' is missing in an entry.")
            continue

        # Use glob to handle wildcard patterns
        matched_paths = glob.glob(entry_path, recursive=True)

        if not matched_paths:
            print(f"Warning: No files matched the pattern '{entry_path}'.")
            continue

        for matched_path in matched_paths:
            if not os.path.exists(matched_path):
                print(f"Warning: Path '{matched_path}' does not exist.")
                continue

            # Apply exclude patterns to files
            if any([shutil.fnmatch.fnmatch(os.path.basename(matched_path), pattern) for pattern in exclude_patterns]):
                print(f"Excluding file '{matched_path}' based on exclude patterns.")
                continue

            if os.path.isdir(matched_path):
                # Handle directories
                if destination_dir == "./":
                    dest_dir_path = sources_dir  # Treat ./ as the parent directory
                else:
                    dest_dir_path = os.path.join(sources_dir, destination_dir or os.path.basename(matched_path))
                os.makedirs(dest_dir_path, exist_ok=True)
                if exclude_patterns:
                    # Copy files while excluding patterns
                    for root, dirs, files in os.walk(matched_path):
                        for file in files:
                            if not any([shutil.fnmatch.fnmatch(file, pattern) for pattern in exclude_patterns]):
                                shutil.copy(os.path.join(root, file), dest_dir_path)
                else:
                    # Copy all files
                    shutil.copytree(matched_path, dest_dir_path, dirs_exist_ok=True)
            elif os.path.isfile(matched_path):
                # Handle files
                if destination_file:
                    # If destination_file is defined, copy the file with the new name
                    dest_file_path = os.path.join(sources_dir, destination_file)
                    os.makedirs(os.path.dirname(dest_file_path), exist_ok=True)
                    shutil.copy(matched_path, dest_file_path)
                elif destination_dir:
                    # If destination_dir is defined, copy the file into it
                    dest_dir_path = os.path.join(sources_dir, destination_dir)
                    os.makedirs(dest_dir_path, exist_ok=True)
                    shutil.copy(matched_path, dest_dir_path)
                else:
                    # Preserve the original directory structure
                    dest_file_path = os.path.join(sources_dir, matched_path)
                    os.makedirs(os.path.dirname(dest_file_path), exist_ok=True)
                    shutil.copy(matched_path, dest_file_path)
            else:
                print(f"Warning: Path '{matched_path}' is neither a file nor a directory.")

    print(f"Files copied successfully to {sources_dir}")


def handle_adapter_initscript(adapter_dir, sources_dir, rcname):
    # Construct the path to the adapter's initscript
    initscript_path = os.path.join(adapter_dir, "etc/rc2.d/initscript")

    if not os.path.isdir(adapter_dir):
        print(f"Error: Adapter directory '{adapter_dir}' does not exist.")
        sys.exit(1)

    if not os.path.isfile(initscript_path):
        print(f"Error: Initscript '{initscript_path}' does not exist.")
        sys.exit(1)

    # Ensure rcname is provided
    if not rcname:
        print("Error: 'rcname' is required for valid adapters but is missing.")
        sys.exit(1)

    # Define the destination directory for the initscript
    destination_dir = os.path.join(sources_dir, "etc/rc2.d")
    os.makedirs(destination_dir, exist_ok=True)

    # Define the destination file path with the new name based on rcname
    destination_file = os.path.join(destination_dir, rcname)

    # Copy and rename the initscript to the destination directory
    shutil.copy(initscript_path, destination_file)
    print(f"Initscript '{initscript_path}' copied to '{destination_file}'")


# Example usage
if __name__ == "__main__":
    sources_file = sys.argv[1]  # Path to the sources YAML file
    sources_dir = sys.argv[2]  # Path to the SOURCES directory
    adapter_name = sys.argv[3]  # Name of the adapter (e.g., apache22, tomcat6)
    adapter_dir = sys.argv[4]  # Path to the adapter directory (e.g., ${{ github.action_path }}/hooks/${{ inputs.adapterName }}/resources)
    rcname = sys.argv[5]  # RC name for the application service

    copy_to_sources(sources_file, sources_dir, adapter_name, adapter_dir, rcname)