# Handling Sources in RPM Workflow

This document provides examples and explanations for handling various use cases when defining `sources` in the RPM workflow. Below are the scenarios and their expected outcomes:

---

## Important Note: Source Binary Directory

The RPM workflow is a separate workflow from your build and compile workflows. As a mandatory step in the build/compile workflows (e.g., `gradle.yml` or `conan.yml`), there will always be an **Upload Build Artifacts** step at the end. This step ensures that the final binary is uploaded to a shared location, making it available for subsequent workflows, such as the RPM packaging workflow.

### Example: Upload Build Artifacts in Build/Compile Workflow
```yaml
- name: Upload Build Artifacts
  uses: actions/upload-artifact@v4
  with:
    name: ${{ inputs.binary_name }}.${{ inputs.version }}.${{ github.run_number }}
    path: ${{ inputs.build_dir }}/${{ inputs.binary_name }}
```

### Example: Download Build Artifacts in RPM Workflow
In the RPM workflow, the first step is to download the previously uploaded build artifacts. This ensures the binary is available for packaging into the RPM.

```yaml
- name: Download Build Artifacts
  uses: actions/download-artifact@v4
  with:
    name: ${{ inputs.binary_name }}.${{ inputs.version }}.${{ github.run_number }}
    path: ${{ github.workspace }}/downloaded-binary
```

### Including the Downloaded Binary in the RPM Package
To ensure the downloaded binary is included in the final RPM package, you must reference the `downloaded-binary` directory in the `sources` section of the RPM workflow.

**Example:**
```yaml
rpm:
  needs: build
  uses: icesdlc/recore.ReusableWorkflows/.github/workflows/rpm.yml@GHA-90
  with:
    sources: |
      - path: downloaded-binary
```

This ensures that the binary downloaded in the first step of the RPM workflow is included in the final RPM package.

---

## Required Inputs in Build/Compile Workflow
When invoking the build workflow, the following inputs must be defined:
```yaml
build_dir: 'build'
binary_name: ${{ inputs.binary_name || 'afx-cplus-poc' }}
version: ${{ inputs.version || '1.0.0' }}
```

## Required Inputs in RPM Workflow
Similarly, the same `binary_name` and `version` inputs must be defined in the RPM workflow to ensure consistency:
```yaml
binary_name: ${{ inputs.binary_name || 'afx-cplus-poc' }}
version: ${{ inputs.version || '1.0.0' }}
```

### Why This is Necessary
The final binary is zipped and uploaded in the build/compile workflow. When the RPM packaging workflow is invoked, it uses the same naming convention to download the artifact and package it into the final RPM package.

### Future Improvements
Currently, this approach requires defining the same input variables (`binary_name` and `version`) in each workflow. This is due to an ongoing effort to improve reusable workflows and centralized input variable handling. For example, [JIRA GHA-99](https://jira.intcx.net/browse/GHA-99) is one of the proposals being worked on to address this issue. In the future, a better approach will be implemented to handle centralized input variables across workflows.

---

## 1. Copying a Folder to the Application Root Directory

If you specify only the `path`, the entire folder will be copied to the root directory of the RPM application.

**Example:**
```yaml
- path: environments
```

**Result:**
The entire `environments` folder will be copied to the application directory:
```
/var/opt/ICEafxPoc/environments
```

---

## 2. Copying Single or Multiple Files While Keeping the Folder Structure

If you specify a file or a pattern (e.g., `*.txt`), the files will be copied while preserving the source folder structure.

**Example:**
```yaml
- path: environments/dummy*.txt
```

**Result:**
The files matching the pattern will be copied to the same folder structure:
```
/var/opt/ICEafxPoc/environments
/var/opt/ICEafxPoc/environments/dummy copy 2.txt
/var/opt/ICEafxPoc/environments/dummy copy 3.txt
/var/opt/ICEafxPoc/environments/dummy.txt
```

---

## 3. Moving Files to a Different Destination Folder

If you want to move files to a different destination folder, use `destination_file`.

**Example:**
```yaml
- path: environments/dummy*.txt
  destination_file: app-environments
```

**Result:**
The files will be moved to the specified destination folder:
```
/var/opt/ICEafxPoc/app-environments
/var/opt/ICEafxPoc/app-environments/dummy copy 2.txt
/var/opt/ICEafxPoc/app-environments/dummy copy 3.txt
/var/opt/ICEafxPoc/app-environments/dummy.txt
```

---

## 4. Renaming the Destination Folder

If you want to copy a folder but rename it in the destination, use `destination_dir`.

**Example:**
```yaml
- path: src
  destination_dir: src2
```

**Result:**
The folder will be copied and renamed in the destination:
```
/var/opt/ICEafxPoc/src2
/var/opt/ICEafxPoc/src2/main.cpp
/var/opt/ICEafxPoc/src2/user_roles_config.yaml
```

---

## 5. Moving a Single File to a Renamed Destination Folder

If you want to move a single file to a specific destination folder and rename it, use `destination_file`.

**Example:**
```yaml
- path: src/user_roles_config.yaml
  destination_file: source/application1/user1/user_roles_config_new.yaml
```

**Result:**
The file will be moved to the specified folder and renamed:
```
/var/opt/ICEafxPoc/source
/var/opt/ICEafxPoc/source/application1
/var/opt/ICEafxPoc/source/application1/user1
/var/opt/ICEafxPoc/source/application1/user1/user_roles_config_new.yaml
```

---

## 6. Copying a Folder While Excluding Specific Files

If you want to copy a folder but exclude certain files, use the `exclude` option.

**Example:**
```yaml
- path: config
  exclude:
    - '*requirements.txt'
```

**Result:**
The folder will be copied, but files matching the exclusion pattern will be skipped:
```
/var/opt/ICEafxPoc/config
/var/opt/ICEafxPoc/config/dummy.txt
/var/opt/ICEafxPoc/config/requirements copy.txt
```

---

## 7. Excluding Files While Using `destination_dir`

The `exclude` option also works when using `destination_dir`.

**Example:**
```yaml
- path: environments/dummy*.txt
  destination_dir: app-environments
  exclude:
    - 'dummy copy 2.txt'
```

**Result:**
The files will be copied to the specified destination folder, excluding the specified files:
```
/var/opt/ICEafxPoc/app-environments
/var/opt/ICEafxPoc/app-environments/dummy copy 3.txt
/var/opt/ICEafxPoc/app-environments/dummy.txt
```

---

## Summary Table

| Use Case                                      | Key Fields                     | Example                                                                 |
|-----------------------------------------------|--------------------------------|-------------------------------------------------------------------------|
| Copy entire folder to root directory          | `path`                         | `- path: environments`                                                 |
| Copy files while keeping folder structure     | `path`                         | `- path: environments/dummy*.txt`                                      |
| Move files to a different destination folder  | `path`, `destination_file`     | `- path: environments/dummy*.txt`<br>`destination_file: app-environments` |
| Rename destination folder                     | `path`, `destination_dir`      | `- path: src`<br>`destination_dir: src2`                               |
| Move single file to renamed destination folder| `path`, `destination_file`     | `- path: src/user_roles_config.yaml`<br>`destination_file: source/application1/user1/user_roles_config_new.yaml` |
| Copy folder while excluding specific files    | `path`, `exclude`              | `- path: config`<br>`exclude: ['*requirements.txt']`                   |
| Exclude files with `destination_dir`          | `path`, `destination_dir`, `exclude` | `- path: environments/dummy*.txt`<br>`destination_dir: app-environments`<br>`exclude: ['dummy copy 2.txt']` |

---

This document provides a comprehensive guide for handling `sources` in the RPM workflow, covering all common use cases and explaining the importance of managing source binaries between workflows.