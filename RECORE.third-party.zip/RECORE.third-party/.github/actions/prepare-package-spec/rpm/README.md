# RPM Spec File Generation Actions

This directory contains actions for generating RPM spec files as part of the `Prepare Spec File Action` composite action.

## Overview

The RPM spec file generation actions are designed to automate the creation and customization of RPM spec files. These actions are part of a larger workflow to streamline the packaging process for applications.

## Inputs

The following inputs are required for the RPM spec file generation action:

- **`packageName`**: Name of the package to be built into an RPM (required).
- **`version`**: Version of the package (required).
- **`adapterName`**: Name of the adapter (e.g., `apache22`, `tomcat6`, etc.) (required).
- **`rcname`**: RC name for the application service (required for valid adapters).
- **`appdir`**: Application directory where the RPM files will be installed (required).
- **`gid`**: Group ID for the application service account (required).
- **`group`**: Group name for the application service account (required).
- **`user`**: User name for the application service account (required).
- **`uid`**: User ID for the application service account (required).
- **`sources`**: Sources configuration in JSON format for additional files (e.g., scripts, env files) to include in the RPM (required).
- **`cron`**: Path to the cron file for scheduling tasks (optional).
- **`homedir`**: Home directory for the application service account (optional).
- **`postinstallhook`**: Path to the customized post-install hook script for the application (optional).
- **`postremovehook`**: Path to the customized post-remove hook script for the application (optional).
- **`preinstallhook`**: Path to the customized pre-install hook script for the application (optional).
- **`preremovehook`**: Path to the customized pre-remove hook script for the application (optional).
- **`rmad`**: Flag to enable or disable appdir cleanup during RPM removal (optional).
- **`scripts`**: Comma-separated list of scripts for granting sudo permissions (optional).
- **`symlink`**: Path to the symlink for the application directory (optional).
- **`systemd`**: Name of the systemd service for the application (optional).
- **`startscript`**: Path to the start script for the application (optional).
- **`startonboot`**: Flag to enable starting the application on boot (optional).
- **`url`**: RPM Spec file URL (optional).
- **`buildArch`**: Build architecture (optional).
- **`dependencies`**: Dependencies for the RPM package in JSON format (optional).

## Workflow Steps

The RPM spec file generation workflow includes the following steps:

1. **Create Directory and Copy Template File**:
   - Creates the `rpmbuild/SPECS` directory and copies the template spec file to it.

2. **Save Sources and Dependencies**:
   - Saves the `sources` and `dependencies` inputs into temporary YAML files for further processing.

3. **Copy Files to SOURCES Directory**:
   - Copies files specified in the `sources` input to the `rpmbuild/SOURCES` directory, handling wildcards, exclusions, and destination paths.

4. **Replace Tokens in Initscript**:
   - Replaces tokens in the initscript file for valid adapters.

5. **Rewrite Dependencies**:
   - Processes the `dependencies` input to generate the `Requires` section in the spec file.

6. **Insert Adapter Scripts**:
   - Inserts adapter-specific scripts into the spec file.

7. **Replace Tokens in Spec File**:
   - Replaces tokens in the spec file using the provided inputs.

8. **Debugging Steps**:
   - Outputs the contents of the `SOURCES` directory and the updated spec file for debugging purposes.

## Sources Handling

For detailed information on how the `sources` input is handled, including wildcard patterns, exclusions, and destination paths, refer to the [Sources Handling Documentation](Handling_Sources_in_RPM_Workflow.md).

## Dependencies Handling

For detailed information on how the `dependencies` input is handled, refer to the [Dependencies Handling Documentation](Handling_Dependencies_in_RPM_Workflow.md).


## Usage
* Below is an example of how the `recore.ReusableWorkflows` workflow invokes this composite action:
```yaml
      - name: Prepare Spec File
        uses: icesdlc/recore.specPreparerAction/rpm@main
        with:
          packageName: ${{ inputs.packageName }}
          version: ${{ inputs.version }}
          appdir: ${{ inputs.appdir }}
          sources: ${{ inputs.sources }}
          adapterName: ${{ inputs.adapterName }}
          cron: ${{ inputs.cron }}
          gid: ${{ inputs.gid }}
          group: ${{ inputs.group }}
          homedir: ${{ inputs.homedir }}
          postinstallhook: ${{ inputs.postinstallhook }}
          postremovehook: ${{ inputs.postremovehook }}
          preinstallhook: ${{ inputs.preinstallhook }}
          preremovehook: ${{ inputs.preremovehook }}
          rcname: ${{ inputs.rcname }}
          rmad: ${{ inputs.rmad }}
          scripts: ${{ inputs.scripts }}
          symlink: ${{ inputs.symlink }}
          user: ${{ inputs.user }}
          uid: ${{ inputs.uid }}
          systemd: ${{ inputs.systemd }}
          startscript: ${{ inputs.startscript }}
          startonboot: ${{ inputs.startonboot }}
          url: ${{ inputs.url }}
          buildArch: ${{ inputs.buildArch }}
          dependencies: ${{ inputs.dependencies }}
```
* Below is an example of how a real application workflow calls the `ReusableWorkflows` to invoke the RPM spec file generation composite action:
```yaml
  rpm:
    needs: build
    uses: icesdlc/recore.ReusableWorkflows/.github/workflows/rpm.yml@GHA-90
    with:
      adapterName: springboot
      rcname: S99afxPoc
      packageName: ICEafxPoc
      binary_name: ${{ inputs.binary_name || 'afx-cplus-poc' }}
      version: ${{ inputs.version || '1.0.0' }}
      appdir: /var/opt/ICEafxPoc
      user: my-user
      uid: 1001
      group: my-group
      gid: 1001
      sources: |
        - path: downloaded-binary
        - path: environments/dummy*.txt
          destination_dir: app-environments
          exclude:
            - 'dummy copy 2.txt'
        - path: environments/all/exec.sh
          destination_dir: env
        - path: src
          destination_dir: src2
        - path: config
          exclude:
            - '*requirements.txt'
        - path: src/user_roles_config.yaml
          destination_file: source/application1/user1/user_roles_config_new.yaml
      dependencies: |
        - ICEpackage1
        - ICEpackage2=2.35.1.RHEL8.ICE.7
        - package >=   1.29.12.ICE.0
```