import sys
import yaml
import re

def normalize_dependency_format(dependency):
    """
    Normalize the format of a single dependency string.
    Ensures consistent spacing around operators like '=', '>=', etc.
    """
    # Match operators and normalize spacing around them
    return re.sub(r'\s*([=<>]+)\s*', r' \1 ', dependency).strip()

def rewrite_dependencies(input_file, output_file):
    """
    Read dependencies from a YAML file, normalize their format,
    and write them to the output file.
    If dependencies are empty, the output file will be empty.
    """
    with open(input_file, 'r') as file:
        data = yaml.safe_load(file)

    # Ensure dependencies is a list
    dependencies = data.get('dependencies', [])
    if not isinstance(dependencies, list):
        dependencies = []

    # If dependencies are empty, write an empty file
    if not dependencies:
        with open(output_file, 'w') as file:
            file.write("")  # Write an empty file
        return

    # Normalize each dependency
    formatted_dependencies = " ".join(normalize_dependency_format(dep) for dep in dependencies)

    # Add the 'Requires:' prefix
    result = f"Requires: {formatted_dependencies}"

    with open(output_file, 'w') as file:
        file.write(result)

if __name__ == "__main__":
    input_file = sys.argv[1]
    output_file = sys.argv[2]
    rewrite_dependencies(input_file, output_file)