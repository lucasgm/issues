#!/bin/bash
# Description:
# This script is used to clean up unneeded sources from the pkg repository.
# Since the pkg repository is a Maven build, the goal is to shift each adapter's scripts 
# into the RPM spec GitHub Action repository. 
# For now, this process is manual. If you want to update the pkg repository's sources 
# in the GitHub Action repository, follow these steps:
# 1. Copy the "pkg" repository's "rpm" folder into this repository under the "hooks" folder:
#    Example: cp -R pkg/rpm /Users/louyang1/github/iceorg4/spec-preparer-action/rpm/hooks
# 2. Run this script manually to clean up the unnecessary files and restructure the folders 
#    to retain only the final 'resources' directory and its contents.
# The script restructures the folders into the format:
# hooks/<adapter_name>/resources
# In the future, this process can be automated to sync the pkg repository with this 
# GitHub Action repository.
# Current version of pkg: pkg-3.2.188

# Define the base directory
BASE_DIR="hooks/rpm"

# Loop through each subdirectory in the base directory
for dir in "$BASE_DIR"/*; do
  if [ -d "$dir" ]; then
    # Define the target resources path
    TARGET_RESOURCES="$dir/resources/src/main/resources"

    # Extract the adapter name from the directory path
    ADAPTER_NAME=$(basename "$dir")

    # Define the new folder structure
    NEW_FOLDER="hooks/$ADAPTER_NAME/resources"

    # If the target resources path exists and is not empty, restructure it; otherwise, remove the parent folder
    if [ -d "$TARGET_RESOURCES" ] && [ "$(ls -A "$TARGET_RESOURCES")" ]; then
      # Create the new folder structure
      mkdir -p "$NEW_FOLDER"

      # Move the contents of the target resources folder to the new folder
      mv "$TARGET_RESOURCES"/* "$NEW_FOLDER/"

      # Remove the original parent folder
      rm -rf "$dir"
    else
      # If the target resources folder doesn't exist or is empty, remove the parent folder
      rm -rf "$dir"
    fi
  fi
done

echo "Cleanup complete. Folders restructured to 'hooks/<adapter_name>/resources'."