import os
import sys

def insert_adapter_scripts(spec_file, adapter_dir):
    # Check if adapter directory exists
    if not os.path.isdir(adapter_dir):
        print(f"Error: Adapter directory '{adapter_dir}' does not exist.")
        sys.exit(1)

    # Read the spec file
    with open(spec_file, 'r') as file:
        spec_content = file.readlines()

    # Define sections and corresponding adapter scripts
    sections = {
        "%pre": "preinstall",
        "%post": "postinstall",
        "%preun": "preremove",
        "%postun": "postremove",
    }

    # Insert adapter scripts into the spec file
    updated_content = []
    for line in spec_content:
        updated_content.append(line)
        if line.strip() in sections:
            script_path = os.path.join(adapter_dir, sections[line.strip()])
            if os.path.isfile(script_path):
                with open(script_path, 'r') as script_file:
                    updated_content.append(script_file.read())
            else:
                print(f"Warning: Script '{script_path}' does not exist.")

    # Write the updated spec file
    with open(spec_file, 'w') as file:
        file.writelines(updated_content)

    print(f"Adapter scripts successfully inserted into '{spec_file}'")


# Example usage
if __name__ == "__main__":
    spec_file = sys.argv[1]  # Path to the spec file
    adapter_dir = sys.argv[2]  # Path to the adapter scripts directory

    insert_adapter_scripts(spec_file, adapter_dir)