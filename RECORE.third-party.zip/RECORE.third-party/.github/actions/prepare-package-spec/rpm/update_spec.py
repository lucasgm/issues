import os
import yaml
import re
import sys

def update_spec_file(spec_path, appdir, sources_file):
    # Parse the YAML input from the file
    try:
        with open(sources_file, 'r') as file:
            yaml_content = yaml.safe_load(file)
            sources = yaml_content.get('sources', [])
    except yaml.YAMLError as e:
        print(f"Error parsing YAML file: {e}")
        sys.exit(1)

    # Read the spec file
    with open(spec_path, 'r') as spec_file:
        spec_content = spec_file.read()

    # Start building the %install section
    install_section = f"""
%%install
rm -rf %%{{buildroot}}
mkdir -p %%{{buildroot}}/{appdir}
"""

    # Parse sources and add copy commands
    for entry in sources:
        entry_path = entry.get('path')
        destination_dir = entry.get('destination_dir', os.path.basename(entry_path))
        destination_file = entry.get('destination_file')
        include_patterns = entry.get('include', [])
        exclude_patterns = entry.get('exclude', [])

        if os.path.isdir(entry_path):
            # Handle directories
            install_section += f"mkdir -p %%{{buildroot}}/{appdir}/{destination_dir}\n"
            if include_patterns:
                for pattern in include_patterns:
                    install_section += f"cp -r {entry_path}/{pattern} %%{{buildroot}}/{appdir}/{destination_dir}\n"
            else:
                install_section += f"cp -r {entry_path}/* %%{{buildroot}}/{appdir}/{destination_dir}\n"
            if exclude_patterns:
                for pattern in exclude_patterns:
                    install_section += f"rm -rf %%{{buildroot}}/{appdir}/{destination_dir}/{pattern}\n"
        elif os.path.isfile(entry_path):
            # Handle files
            if destination_file:
                destination_file_dir = os.path.dirname(destination_file)
                install_section += f"mkdir -p %%{{buildroot}}/{appdir}/{destination_file_dir}\n"
                install_section += f"cp {entry_path} %%{{buildroot}}/{appdir}/{destination_file}\n"
            else:
                install_section += f"mkdir -p %%{{buildroot}}/{appdir}/{destination_dir}\n"
                install_section += f"cp {entry_path} %%{{buildroot}}/{appdir}/{destination_dir}\n"
        else:
            raise FileNotFoundError(f"Entry {entry_path} does not exist.")

    # Replace the %install section in the spec file
    spec_content = re.sub(r"%install.*?%post", install_section + "\n%post", spec_content, flags=re.DOTALL)

    # Write the updated spec file
    with open(spec_path, 'w') as spec_file:
        spec_file.write(spec_content)

    print(f"Spec file updated successfully: {spec_path}")


# Example usage
if __name__ == "__main__":
    spec_path = sys.argv[1]  # Path to the spec file
    appdir = sys.argv[2]     # Application directory
    sources_file = sys.argv[3]  # Path to the sources YAML file

    update_spec_file(spec_path, appdir, sources_file)