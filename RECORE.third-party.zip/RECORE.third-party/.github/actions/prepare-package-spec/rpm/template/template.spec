Name: #{packageName}#
Version: #{version}#
Release: 1
Summary: RPM package for #{packageName}#
License: ICE
URL: #{url}#
BuildArch: #{buildArch}#

# Runtime dependencies
#{dependencies}#

%description
This is an example RPM package for #{packageName}#.

# %prep - Uncomment this section if you have a source tarball
# %setup -q -n %{name}-%{version}

%build
# No build steps for this package

%install
rm -rf %{buildroot}
mkdir -p %{buildroot}/#{appDir}#
cp -r %{_sourcedir}/* %{buildroot}/#{appDir}#

# Preinstall commands
%pre

# Postinstall commands
%post

# Preremove commands
%preun

# Postremove commands
%postun

%files
/#{appDir}#

%clean
rm -rf %{buildroot}

%changelog