# Prepare Spec File Action

This repository contains a GitHub Composite Action designed to generate package specification files, such as RPM spec files and Chocolatey package spec files. The primary purpose of this repository is to provide reusable actions for preparing spec files that can be integrated into other workflows.

## Repository Contents

This repository currently includes the following:
- **RPM Spec File Generation Actions**: Actions for generating RPM spec files, located in the `rpm/` directory.
- **Chocolatey Package Spec File Generation Actions**: Actions for generating Chocolatey package spec files, located in the `choco/` directory.

## Intended Use

This repository is intended to be used as part of a larger workflow to automate the generation of package spec files. For example:
- Generating RPM spec files for building RPM packages.
- Preparing Chocolatey package spec files for Windows package creation.

## Integration with `recore.ReusableWorkflows`

This repository is designed to be called by the `recore.ReusableWorkflows` repository, which provides reusable workflows for building and deploying packages. By leveraging this composite action, you can streamline the process of preparing spec files as part of your CI/CD pipelines.

## Future Scope

This repository is designed to be extensible. Future updates may include actions for generating other types of spec files as needed.

## Additional Documentation

For detailed information about the spec file generation actions, including inputs and usage examples, refer to:
- [rpm/README.md](rpm/README.md) - RPM package specification files
- [choco/README.md](choco/README.md) - Chocolatey package specification files