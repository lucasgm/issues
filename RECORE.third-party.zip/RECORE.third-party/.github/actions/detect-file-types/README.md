# Detect File Types Action

This action scans a directory for different file types and sets environment variables and outputs accordingly. It's designed to be highly modular and easily extensible for new file types.

## Features

- **Modular Configuration**: File types and patterns are defined in a configuration map
- **Easy to Extend**: Add new file types by updating the configuration arrays
- **Comprehensive Detection**: Automatically detects all supported file types
- **Multiple Output Formats**: Individual type flags, format lists, and combined summaries
- **Backward Compatible**: Maintains environment variables for existing workflows

## Currently Supported File Types

| Type | Patterns | Description |
|------|----------|-------------|
| `tar` | `*.tar.gz`, `*.tgz`, `*.tar.xz`, `*.tar.bz2`, `*.tar` | Tar archives with various compressions |
| `zip` | `*.zip` | ZIP archives |
| `deb` | `*.deb` | Debian packages |
| `rpm` | `*.rpm` | RPM packages |
| `jar` | `*.jar`, `*.war`, `*.ear` | Java archives |

## Inputs

| Input | Description | Required | Default |
|-------|-------------|----------|---------|
| `sourceDir` | Directory to scan for files | false | `downloaded_sources` |

## Outputs

| Output | Description |
|--------|-------------|
| `hasTarFiles` | Whether any tar files were found (true/false) |
| `hasZipFiles` | Whether any zip files were found (true/false) |
| `hasDebFiles` | Whether any deb files were found (true/false) |
| `hasRpmFiles` | Whether any rpm files were found (true/false) |
| `hasJarFiles` | Whether any jar files were found (true/false) |
| `tarFormats` | Comma-separated list of tar formats found |
| `detectedTypes` | All detected file type groups |
| `allFormats` | All specific formats found |

## Environment Variables Set

- `HAS_TAR_FILES`: Whether tar files were found
- `HAS_ZIP_FILES`: Whether zip files were found  
- `SOURCE_DIR`: The source directory that was scanned

## Usage

### Basic Usage

```yaml
- name: Detect file types
  uses: ./actions/detect-file-types
  with:
    sourceDir: "my_downloads"
```

### Using Outputs

```yaml
- name: Detect file types
  id: detect
  uses: ./actions/detect-file-types
  with:
    sourceDir: "downloaded_files"

- name: Extract files conditionally
  if: steps.detect.outputs.hasTarFiles == 'true'
  uses: ./actions/extract-tar-files
  with:
    sourceDir: "downloaded_files"

- name: Show all detected information
  run: |
    echo "Detected types: ${{ steps.detect.outputs.detectedTypes }}"
    echo "All formats: ${{ steps.detect.outputs.allFormats }}"
    echo "Tar formats: ${{ steps.detect.outputs.tarFormats }}"
    echo "Has JAR files: ${{ steps.detect.outputs.hasJarFiles }}"
    echo "Has DEB files: ${{ steps.detect.outputs.hasDebFiles }}"
```

### Complete Workflow Example

```yaml
- name: Download sources
  uses: ./actions/download-sources
  with:
    sourceUrl: "https://example.com/file.tar.xz"

- name: Detect file types
  id: detect
  uses: ./actions/detect-file-types

- name: Extract tar files
  if: steps.detect.outputs.hasTarFiles == 'true'
  uses: ./actions/extract-tar-files

- name: Extract zip files  
  if: steps.detect.outputs.hasZipFiles == 'true'
  uses: ./actions/extract-zip-files

- name: Process JAR files
  if: steps.detect.outputs.hasJarFiles == 'true'
  run: echo "Found JAR files to process"
```

## Adding New File Types

To add support for new file types, update three simple arrays in the action:

### Step 1: Add to FILE_TYPE_CONFIG
```bash
declare -A FILE_TYPE_CONFIG=(
  ["tar"]="*.tar.gz *.tgz *.tar.xz *.tar.bz2 *.tar"
  ["zip"]="*.zip"
  ["deb"]="*.deb"
  ["rpm"]="*.rpm"
  ["jar"]="*.jar *.war *.ear"
  ["msi"]="*.msi"           # NEW: Windows installer
  ["dmg"]="*.dmg"           # NEW: macOS disk image
)
```

### Step 2: Add to type_found array
```bash
declare -A type_found=(
  ["tar"]=false
  ["zip"]=false
  ["deb"]=false
  ["rpm"]=false
  ["jar"]=false
  ["msi"]=false            # NEW
  ["dmg"]=false            # NEW
)
```

### Step 3: Add to type_formats array
```bash
declare -A type_formats=(
  ["tar"]=""
  ["zip"]=""
  ["deb"]=""
  ["rpm"]=""
  ["jar"]=""
  ["msi"]=""               # NEW
  ["dmg"]=""               # NEW
)
```

### Step 4: Add to SUPPORTED_TYPES array
```bash
SUPPORTED_TYPES=("tar" "zip" "deb" "rpm" "jar" "msi" "dmg")  # Add new types here
```

### Step 5: Add output (optional, in action.yml)
```yaml
outputs:
  hasMsiFiles:
    description: "Whether msi files were found"
    value: ${{ steps.detect.outputs.hasMsiFiles }}
  hasDmgFiles:
    description: "Whether dmg files were found"
    value: ${{ steps.detect.outputs.hasDmgFiles }}
```

### Step 6: Add output generation (in script)
```bash
echo "hasMsiFiles=${type_found[msi]}" >> $GITHUB_OUTPUT
echo "hasDmgFiles=${type_found[dmg]}" >> $GITHUB_OUTPUT
```

That's it! The new file types will be automatically detected.

## Benefits of Modular Design

✅ **Simple to Use**: No configuration needed - just point it at a directory  
✅ **Easy to Extend**: Clear step-by-step process for adding new file types  
✅ **Maintainable**: All file type definitions in one place  
✅ **Comprehensive**: Always checks for all supported types  
✅ **Future-Proof**: Structured for easy expansion  
✅ **Backward Compatible**: Maintains existing environment variables
