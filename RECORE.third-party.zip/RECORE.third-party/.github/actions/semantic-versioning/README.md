# Generate Version Action

A plug-and-play composite action that enforces versioning standards for DEV application workflows. This action takes a version input and appends GitHub run number for unique versioning.

---

## Description

This action provides a standardized approach to semantic versioning that:

1. **Takes version input** - Accepts any version format provided by the caller
2. **Enforces consistency** - Uses a fixed output format (`{VERSION}.{RUN_NUMBER}`)
3. **Prevents bypassing** - DEV teams cannot customize the versioning logic
4. **Plug-and-play** - Works with existing workflows with minimal changes

The action is designed to be simple and focused - it takes a version and appends the run number.

---

## Architecture

This action uses a **modular script architecture** for maintainability:

- **`scripts/validate-inputs.sh`** - Validates version input with clear error messaging
- **`scripts/generate-version.sh`** - Generates final version by combining base version and run number
- **`scripts/generate-summary.sh`** - Displays formatted results summary

This modular approach makes it easier to:
- Test individual components
- Update specific logic without affecting other parts
- Maintain consistent error messaging
- Follow established patterns in this repository

---

## Inputs

| Input | Description | Required | Default |
|-------|-------------|----------|---------|
| `version` | Workflow input version (from inputs.version) | No | `""` |
| `semVersion` | Repository variable fallback (from vars.SEM_VERSION) | No | `""` |

**Note**: At least one input must be provided. The action uses this priority:
1. `version` (workflow input) - highest priority
2. `semVersion` (repository variable) - fallback
3. Error if both are empty

---

## Outputs

| Output | Description |
|--------|-------------|
| `finalVersion` | The generated final version (version + run number) |
| `version` | The version that was used (after fallback logic) |
| `runNumber` | The GitHub run number that was appended |
| `versionSource` | Source of version used ("workflow input" or "repository variable") |

---

## Environment Variables

The action sets the following environment variable:

- `FINAL_VERSION`: The generated final version (available for subsequent steps)

## GitHub Actions Integration

The action provides enhanced visibility through:

- **Job Summary**: Writes a formatted table to the GitHub Actions Job Summary showing version generation results
- **Console Output**: Displays detailed logging during execution for debugging
- **Step Outputs**: Provides structured outputs for use in subsequent workflow steps

---

## Usage Examples

### Basic Usage (Simplified - No workflow-level logic needed!)

```yaml
- name: Generate Semantic Version
  id: semversion
  uses: icesdlc/recore.ReusableWorkflows/actions/semantic-versioning@main
  with:
    version: ${{ inputs.version }}
    semVersion: ${{ vars.SEM_VERSION }}

- name: Use Generated Version
  run: |
    echo "Final Version: ${{ steps.semversion.outputs.finalVersion }}"
    echo "Version Source: ${{ steps.semversion.outputs.versionSource }}"
```

### Complete Workflow Example

```yaml
version:
  runs-on:
    group: ent/icelinux-small
  outputs:
    finalVersion: ${{ steps.semversion.outputs.finalVersion }}
    versionSource: ${{ steps.semversion.outputs.versionSource }}
  steps:
    - name: Generate Semantic Version
      id: semversion
      uses: icesdlc/recore.ReusableWorkflows/actions/semantic-versioning@main
      with:
        version: ${{ inputs.version }}
        semVersion: ${{ vars.SEM_VERSION }}
```

### Input Priority Example

```yaml
# Scenario 1: Both inputs provided - uses workflow input
with:
  version: "1.0.0"           # ← This is used (highest priority)
  semVersion: "2.0.0"        # ← Ignored

# Scenario 2: Only repository variable - uses fallback
with:
  version: ""                # ← Empty
  semVersion: "2.0.0"        # ← This is used (fallback)

# Scenario 3: Neither provided - error
with:
  version: ""                # ← Empty
  semVersion: ""             # ← Empty = ERROR
```

### Dynamic Version from Files

```yaml
version:
  runs-on:
    group: ent/icelinux-small
  outputs:
    finalVersion: ${{ steps.semversion.outputs.finalVersion }}
  steps:
    - name: Checkout
      uses: actions/checkout@v4
    
    - name: Get version from package.json
      id: get-version
      run: echo "version=$(cat package.json | jq -r '.version')" >> $GITHUB_OUTPUT
    
    - name: Set semantic version
      id: semversion
      uses: icesdlc/recore.ReusableWorkflows/actions/semantic-versioning@main
      with:
        version: ${{ steps.get-version.outputs.version }}
```

### Custom Version Formats

The action works with ANY version format DEV provides and always appends `.{run_number}`:

```yaml
# Semantic versions
application_version: "1.2.3"           # → "1.2.3.123"

# Custom formats  
application_version: "v2024.1"         # → "v2024.1.123"

# Build numbers
---

## Output Examples

The action supports any input format and always outputs in the fixed format:

```yaml
# Semantic versions
version: "1.2.3"           # → "1.2.3.123"
version: "2.0.0-beta"      # → "2.0.0-beta.123"

# Build numbers  
version: "build-456"       # → "build-456.123"

# Date-based
version: "2024-07-11"      # → "2024-07-11.123"

# Marketing versions
version: "summer-release"  # → "summer-release.123"
```

**Note**: The format is fixed as `{DEV_VERSION}.{RUN_NUMBER}` to ensure consistency across all workflows.

### Dynamic Version from Files

```yaml
version:
  runs-on:
    group: ent/icelinux-small
  outputs:
    finalVersion: ${{ steps.semversion.outputs.finalVersion }}
  steps:
    - name: Checkout
      uses: actions/checkout@v4
    
    - name: Get version from package.json
      id: get-version
      run: echo "version=$(cat package.json | jq -r '.version')" >> $GITHUB_OUTPUT
    
    - name: Set semantic version
      id: semversion
      uses: icesdlc/recore.ReusableWorkflows/actions/semantic-versioning@main
      with:
        version: ${{ steps.get-version.outputs.version }}
```

---

## Key Features

### Enforced Versioning Standards
- **Locked-down logic**: DEV teams cannot bypass or customize versioning logic
- **Consistent format**: Fixed output format across all workflows
- **Automatic fallback**: Intelligent version detection with clear error handling

### Plug-and-Play Design
- **No Format Requirements**: Accepts any version format DEV provides
- **Drop-in Replacement**: Direct substitute for existing manual version steps
- **Same Outputs**: Compatible with existing workflow references
- **Environment Variables**: Maintains compatibility with existing scripts

### Centralized Control
- **Prevents Bypass**: DEV teams cannot skip version generation when used in reusable workflows
- **Consistent Application**: Ensures GitHub run number is always appended
- **Standardized Logic**: Centralizes version generation across all applications

### Flexible Input Methods
- **Hardcoded**: `"1.0.0"`, `"v2024.1"`, `"build-456"`
- **Repository Variables**: Automatic fallback to `APPLICATION_VERSION` 
- **Dynamic Values**: From files, previous steps, calculations
- **Any Format**: Works with semantic, marketing, date-based, or custom versions
- **Intelligent Fallback**: Input → Repository Variable → Error with guidance

### Clear Error Messaging
- **Contextual Guidance**: Error messages explain the complete version detection workflow
- **Fallback Explanation**: Clearly describes the workflow-level version detection order:
  1. Workflow input parameter 'version' (highest priority)
  2. Repository variable 'SEM_VERSION' (if workflow input is empty)
  3. Error with clear guidance (if both are empty)
- **Actionable Instructions**: Provides specific steps to resolve version detection issues
- **Professional Tone**: Clean, emoji-free error messages suitable for enterprise environments

---

## Integration in Reusable Workflows

```yaml
name: Application Build Workflow
on:
  workflow_call:
    inputs:
      devVersion:
        description: "DEV-provided version (optional - fallback to repo variable)"
        required: false
        type: string

jobs:
  version:
    runs-on:
      group: ent/icelinux-small
    outputs:
      finalVersion: ${{ steps.semversion.outputs.finalVersion }}
    steps:
      - name: Generate Final Version
        id: semversion
        uses: icesdlc/recore.ReusableWorkflows/actions/semantic-versioning@main      with:
        version: ${{ inputs.devVersion }}
        # Will automatically fallback to APPLICATION_VERSION repo variable if devVersion is empty
  
  build:
    needs: version
    runs-on:
      group: ent/icelinux-small
    steps:
      - name: Build with Version
        run: echo "Building version ${{ needs.version.outputs.finalVersion }}"
```

---

## Troubleshooting

### Common Issues

**❌ "No application version found!" Error**
```
Please provide version via:
1. Workflow input: applicationVersion
2. Repository variable: APPLICATION_VERSION
```

**Solution**: Either:
- Add `version` input to your workflow call
- Create an `APPLICATION_VERSION` repository variable in your repo settings

**✅ Repository Variable Setup**:
1. Go to your repository Settings
2. Navigate to Secrets and variables → Actions
3. Click Variables tab
4. Add new variable: `APPLICATION_VERSION` with your desired version (e.g., "1.0.0")

---

## Migration Benefits

1. **Zero Breaking Changes**: Works exactly like existing manual implementations
2. **Intelligent Fallback**: No need to update all workflows immediately
3. **Immediate Deployment**: Can be applied to existing workflows without modification
4. **Centralized Updates**: Version logic changes in one place affect all workflows
5. **Bypass Prevention**: When embedded in reusable workflows, DEV cannot skip versioning

---

## Notes

- **Modular Design**: Clear separation between version detection and final version generation
- **Intelligent Fallback**: Automatically tries multiple version sources
- **Unique Versioning**: GitHub run number ensures each build has a unique identifier
- **Backward Compatible**: Maintains all existing workflow patterns and outputs
- **Plug-and-Play**: Designed as a direct replacement for manual version generation
- **Centralized Control**: Prevents version generation bypass when used in reusable workflows
