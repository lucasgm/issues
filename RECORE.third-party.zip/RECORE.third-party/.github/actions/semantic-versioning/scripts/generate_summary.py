#!/usr/bin/env python3
import os
import sys

def main():
    # Accept: <version> <final_version>
    if len(sys.argv) < 3:
        print("Usage: generate_summary.py <version> <final_version>", file=sys.stderr)
        return 2
    version, final = [a.strip() for a in sys.argv[1:3]]

    print("Version Generation Results:")
    print(f"   Base Version: {version}")
    print(f"   Final Version: {final}")
    print("")
    print("Version generation completed successfully!")

    summary_path = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary_path:
        with open(summary_path, 'a', encoding='utf-8') as f:
            f.write("## Version Generation Results\n\n")
            f.write("| Property | Value |\n")
            f.write("|----------|-------|\n")
            f.write(f"| **Base Version** | `{version}` |\n")
            f.write(f"| **Final Version** | `{final}` |\n\n")
            f.write("✅ **Version generation completed successfully!**\n\n---\n")
    return 0

if __name__ == "__main__":
    sys.exit(main())