# Semantic Versioning Scripts

This directory contains modular bash scripts that implement the semantic versioning logic for the Generate Version action.

## Scripts Overview

### validate-inputs.sh
- **Purpose**: Validates the version input parameter
- **Input**: Version string to validate
- **Output**: Validation success/failure with clear error messaging
- **Error Handling**: Provides detailed explanation of version detection workflow

### generate-version.sh
- **Purpose**: Generates the final version by combining base version with GitHub run number
- **Input**: Base version string and GitHub run number
- **Output**: Final version string in format `{VERSION}.{RUN_NUMBER}`
- **Error Handling**: Validates run number availability and final version generation

### generate-summary.sh
- **Purpose**: Displays a formatted summary of the version generation results
- **Input**: Base version, run number, and final version
- **Output**: Formatted summary display and GitHub Actions Job Summary
- **Error Handling**: None (display only)
- **GitHub Integration**: Writes to `$GITHUB_STEP_SUMMARY` for enhanced visibility in the Actions UI

## Design Principles

1. **Modularity**: Each script handles a specific responsibility
2. **Error Handling**: Clear, actionable error messages with context
3. **Maintainability**: Separate concerns for easier testing and updates
4. **Consistency**: Follows the same pattern as other actions in this repository

## Usage Pattern

These scripts are called sequentially by the main `action.yml` file:

1. `validate-inputs.sh` - Ensures input is valid
2. `generate-version.sh` - Creates the final version
3. `generate-summary.sh` - Displays results

This modular approach makes it easier to:
- Test individual components
- Update specific logic without affecting other parts
- Maintain consistent error messaging
- Follow the established patterns in this repository
