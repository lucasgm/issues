#!/usr/bin/env python3
import sys

def main():
    if len(sys.argv) < 2:
        print("Usage: generate_version.py <version>", file=sys.stderr)
        return 2

    version = sys.argv[1].strip()
    if not version:
        print("ERROR: base version cannot be empty", file=sys.stderr)
        return 1

    print(version)
    return 0

if __name__ == "__main__":
    sys.exit(main())