#!/usr/bin/env python3
import sys

def main():
    # Args: input_version, sem_version
    if len(sys.argv) < 3:
        print("Usage: validate_inputs.py <input_version> <sem_version>", file=sys.stderr)
        return 2
    input_version = sys.argv[1].strip()
    sem_version = sys.argv[2].strip()

    # Logging to stderr so stdout stays parseable
    print("Generate Version Action - Python", file=sys.stderr)
    print("Determining version source with fallback logic...", file=sys.stderr)
    print(f"Workflow input version: '{input_version or '<empty>'}'", file=sys.stderr)
    print(f"Repository variable version: '{sem_version or '<empty>'}'", file=sys.stderr)

    if input_version:
        final = input_version
        source = "workflow input"
    elif sem_version:
        final = sem_version
        source = "repository variable"
    else:
        print("ERROR: No version found!", file=sys.stderr)
        return 1

    print(f"Using version from {source}: {final}", file=sys.stderr)
    # stdout formatted as version|source
    print(f"{final}|{source}")
    return 0

if __name__ == "__main__":
    sys.exit(main())
