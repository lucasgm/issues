# Verify Artifacts Action

A unified composite action for GPG signature verification in both CI and CD contexts.

## Features

- **Unified Logic** - Single action handles both CI and CD verification
- **Context-Aware** - Automatically adapts behavior based on context
- **Flexible Inputs** - Supports different signature suffixes and artifact types
- **Comprehensive Validation** - Validates inputs and provides clear error messages
- **Detailed Outputs** - Returns verification status, counts, and results

## Inputs

| Input | Description | Required | Default | Context |
|-------|-------------|----------|---------|---------|
| `signatureContext` | Verification context: "ci" or "cd" | Yes | - | Both |
| `gpgPublicKey` | GPG public key (ASCII-armored) | Yes | - | Both |
| `artifactExtensions` | Space-separated list of extensions | No | `jar rpm tgz nupkg whl` | Both |
| `artifactoryPath` | Artifactory path | No* | - | CD only |
| `artifactoryBuildName` | Build name | No* | - | CD only |
| `artifactoryBuildNumber` | Build number | No* | - | CD only |
| `jfUrl` | JFrog URL | No | `https://artifbuild.m4s.intcx.net` | CD only |
| `baseToken` | Base token for base-* artifactory paths | No* | - | CD only |
| `iceArtifToken` | ICE Artifactory token | No* | - | CD only |
| `artifactsPath` | Path to artifacts | No | `${{ github.workspace }}/tempDownload` | CI only |
| `workingDirectory` | Working directory | No | `./artifact-verification` | Both |
| `requireAllSignatures` | Require all signatures | No | `true` | Both |

*Required when context=cd

## Outputs

| Output | Description |
|--------|-------------|
| `verificationStatus` | Status: "success" or "failed" |
| `verifiedCount` | Number of artifacts with verified signatures |
| `totalCount` | Total number of artifacts checked |

## Usage

### CI Context (Verify CI Signatures)

```yaml
- name: Verify CI Signatures
  uses: ./actions/verify-artifacts
  with:
    signatureContext: 'ci'
    gpgPublicKey: ${{ secrets.GPG_PUBLIC_KEY }}
    artifactExtensions: 'jar rpm tgz'
    # signatureSuffix is automatically set from signatureContext
    artifactsPath: '${{ github.workspace }}/tempDownload'
```

### CD Context (Download and Verify CD Signatures)
**Note: This functionality is not currently used in workflows.**

```yaml
- name: Verify CD Signatures for Deployment
  uses: ./actions/verify-artifacts
  with:
    signatureContext: 'cd'
    gpgPublicKey: ${{ secrets.GPG_PUBLIC_KEY }}
    artifactoryPath: 'RE_generic_files/'
    artifactoryBuildName: 'my-app'
    artifactoryBuildNumber: '123'
    baseToken: ${{ secrets.BASE_TOKEN }}
    iceArtifToken: ${{ secrets.ICE_ARTIF_TOKEN }}
    # No jfAccessToken parameter exists in the action
```

### With Outputs

```yaml
- name: Verify Signatures
  id: verify
  uses: ./actions/verify-artifacts
  with:
    signatureContext: 'ci'
    gpgPublicKey: ${{ secrets.GPG_PUBLIC_KEY }}

- name: Use Results  
  run: |
    echo "Status: ${{ steps.verify.outputs.verificationStatus }}"
    echo "Verified: ${{ steps.verify.outputs.verifiedCount }}/${{ steps.verify.outputs.totalCount }}"
    
- name: Deploy (only if verification passed)
  if: ${{ steps.verify.outputs.verificationStatus == 'success' }}
  run: echo "Deploying verified artifacts..."
```

## How It Works

### CI Context Flow:
1. **Setup GPG** - Import public key for verification
2. **Verify Signatures** - Check signatures in the specified artifacts path
3. **Report Results** - Show verification status and counts

### CD Context Flow (Not Currently Used):
While the action supports CD verification, this functionality is not currently used in workflows. If needed, it would:

1. **Setup Working Directory** - Create clean verification space
2. **Setup JFrog CLI** - Configure Artifactory access
3. **Download Artifacts** - Download artifacts and signatures from Artifactory
4. **Setup GPG** - Import public key for verification
5. **Verify Signatures** - Check CD signatures on downloaded artifacts
6. **Report Results** - Show verification status and deployment readiness

## Migration from Separate Actions

### Migrating from Previous Actions:
```yaml
# Before (old action)
- uses: ./actions/ci-gpg-verify-artifacts
  with:
    gpgPublicKey: ${{ secrets.GPG_PUBLIC_KEY }}
    artifactExtensions: 'jar rpm'

# After (current action)
- uses: ./actions/verify-artifacts
  with:
    signatureContext: 'ci'
    gpgPublicKey: ${{ secrets.GPG_PUBLIC_KEY }}
    artifactExtensions: 'jar rpm'
```

### Note on CD Verification
CD verification functionality is not currently used in workflows.

If CD verification is needed in the future, use:
```yaml
- uses: ./actions/verify-artifacts
  with:
    signatureContext: 'cd'
    artifactoryPath: 'RE_generic_files/'
    artifactoryBuildName: 'my-app'
    artifactoryBuildNumber: '123'
    jfUrl: 'https://artifactory.company.com'
    baseToken: ${{ secrets.BASE_TOKEN }}
    iceArtifToken: ${{ secrets.ICE_ARTIF_TOKEN }}
    gpgPublicKey: ${{ secrets.GPG_PUBLIC_KEY }}
```

## Benefits

✅ **Single Maintenance Point** - One action to maintain instead of two  
✅ **Consistent Logic** - Same verification algorithm for both contexts  
✅ **Better Error Handling** - Unified validation and error reporting  
✅ **Flexible Usage** - Can be used in any verification scenario  
✅ **Clear Outputs** - Standardized outputs for both contexts
