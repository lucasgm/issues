#!/bin/bash

# Script to determine SBOM generation method
# Usage: determine-method.sh <sbomMethod> <outputFile>

sbom_method="$1"
output_file="$2"

echo "=== Determining SBOM Generation Method ==="

# Simple method selection logic
if [ "$sbom_method" == "marketplace" ]; then
  echo "method=marketplace" >> $GITHUB_OUTPUT
  echo "Using marketplace action method (explicitly requested)"
else
  # Default to API method for all other cases (including empty/unset)
  echo "method=api" >> $GITHUB_OUTPUT
  echo "Using API method (default)"
fi

echo "sbomFilePath=$output_file" >> $GITHUB_OUTPUT
echo "Selected method: $(cat $GITHUB_OUTPUT | grep method= | cut -d'=' -f2)"
