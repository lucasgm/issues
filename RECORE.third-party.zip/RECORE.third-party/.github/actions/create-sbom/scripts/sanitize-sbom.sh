#!/bin/bash

# Script to sanitize SBOM from API method
# Usage: sanitize-sbom.sh <outputFile>

output_file="$1"

echo "=== Sanitizing SBOM from API ==="

# Create sanitized version while preserving original file name
sanitized_file="${output_file%.*}-sanitized.json"

# Sanitize invalid PURLs and handle null values - output to new file
jq '
  .packages = (
    try (
      .packages
      | map(select(. != null))
      | map(
          if (try (.externalRefs | type) == "array") then
            .externalRefs |= map(select(. != null))
            | .externalRefs |= map(
                if (try (.referenceLocator | test("\\?"))) then
                  .referenceLocator = (.referenceLocator | split("?")[0])
                else
                  .
                end
              )
          else
            .
          end
        )
    ) catch []
  )
' "$output_file" > "$sanitized_file"

echo "✅ SBOM sanitized successfully"
echo "📁 Original preserved: $output_file"
echo "🔧 Sanitized version: $sanitized_file"
