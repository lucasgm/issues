#!/bin/bash

# Script to extract and classify PURLs from SBOM
# Usage: extract-purls.sh <outputFile>

output_file="$1"

echo "=== Extracting and Classifying PURLs ==="
mkdir -p sbom-output

# Extract PURLs with null safety
jq -r '.packages // [] | .[] | select(. != null) | .externalRefs // [] | .[] | select(. != null) | .referenceLocator' "$output_file" > sbom-output/all-purls.txt 2>/dev/null || echo "No PURLs found" > sbom-output/all-purls.txt

# Check if we have any PURLs
if [ ! -s sbom-output/all-purls.txt ] || grep -q "No PURLs found" sbom-output/all-purls.txt; then
  echo "No PURLs found in SBOM"
  echo "0" > sbom-output/valid-purls.txt
  echo "0" > sbom-output/invalid-purls.txt
else
  grep -v '?' sbom-output/all-purls.txt > sbom-output/valid-purls.txt || true
  grep '?' sbom-output/all-purls.txt > sbom-output/invalid-purls.txt || true
fi

valid_count=$(wc -l < sbom-output/valid-purls.txt 2>/dev/null || echo 0)
invalid_count=$(wc -l < sbom-output/invalid-purls.txt 2>/dev/null || echo 0)

echo "Valid PURLs: $valid_count"
echo "Invalid PURLs (contain '?'): $invalid_count"

if [ -f sbom-output/valid-purls.txt ] && [ "$valid_count" -gt 0 ]; then
  echo "Sample valid PURLs:"
  head -5 sbom-output/valid-purls.txt || true
fi

if [ -f sbom-output/invalid-purls.txt ] && [ "$invalid_count" -gt 0 ]; then
  echo "Sample invalid PURLs:"
  head -5 sbom-output/invalid-purls.txt || true
fi
