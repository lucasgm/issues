#!/bin/bash

# Script to convert SBOM to CycloneDX format
# Usage: convert-cyclonedx.sh <outputFile>

output_file="$1"

echo "=== Converting to CycloneDX Format ==="

# Define file names for different versions
sanitized_file="${output_file%.*}-sanitized.json"
cyclonedx_file="${output_file%.*}-cyclonedx.json"

# Use the sanitized file as input if it exists, otherwise use the original
input_file="$sanitized_file"
if [ ! -f "$input_file" ]; then
    input_file="$output_file"
fi

jq '{
  bomFormat: "CycloneDX",
  specVersion: "1.4",
  version: 1,
  metadata: {
    timestamp: (now | strflocaltime("%Y-%m-%dT%H:%M:%SZ")),
    tools: [{
      vendor: "GitHub",
      name: "create-sbom",
      version: "1.0"
    }],
    component: {
      type: "application",
      name: (.name // "unknown")
    }
  },
  components: [
    (.packages // []) 
    | .[] 
    | select(. != null)
    | {
        type: "library",
        name: (.name // "unknown"),
        version: (.versionInfo // "unknown"),
        purl: (
          (.externalRefs // [])
          | .[]
          | select(. != null)
          | select(.referenceType == "purl") 
          | .referenceLocator
        )
      }
  ]
}' "$input_file" > "$cyclonedx_file"

echo "✅ SBOM converted to CycloneDX format successfully"
echo "📁 Original preserved: $output_file"
if [ -f "$sanitized_file" ]; then
    echo "🔧 Sanitized version: $sanitized_file"
fi
echo "� CycloneDX version: $cyclonedx_file"
