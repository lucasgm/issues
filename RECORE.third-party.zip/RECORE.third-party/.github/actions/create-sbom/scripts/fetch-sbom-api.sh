#!/bin/bash

# Script to fetch SBOM from GitHub API
# Usage: fetch-sbom-api.sh <token> <owner> <repo> <outputFile>

token="$1"
owner="$2"
repo="$3"
output_file="$4"

echo "=== Generating SBOM with API Method ==="

echo "Fetching SBOM from GitHub API for $owner/$repo"

curl -s -H "Authorization: token $token" \
     -H "Accept: application/vnd.github+json" \
     "https://api.github.com/repos/$owner/$repo/dependency-graph/sbom" \
     -o "$output_file.raw"

# Extract SBOM from response
jq '.sbom' "$output_file.raw" > "$output_file"
rm "$output_file.raw"

if [ -f "$output_file" ]; then
  echo "SBOM fetched successfully: $output_file"
  echo "File size: $(du -h "$output_file" | cut -f1)"
else
  echo "ERROR: SBOM file not generated"
  exit 1
fi
