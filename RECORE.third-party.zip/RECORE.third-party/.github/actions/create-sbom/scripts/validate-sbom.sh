#!/bin/bash

# Script to validate generated SBOM and display summary
# Usage: validate-sbom.sh <outputFile> <method> <outputFormat>

output_file="$1"
method="$2"
output_format="$3"

echo "=== Validating Generated SBOM ==="

if [ ! -f "$output_file" ]; then
  echo "ERROR: SBOM file not found: $output_file"
  exit 1
fi

# Check if file is valid JSON
if ! jq . "$output_file" > /dev/null 2>&1; then
  echo "ERROR: SBOM file is not valid JSON"
  exit 1
fi

# Display summary
echo "SBOM file: $output_file"
echo "File size: $(du -h "$output_file" | cut -f1)"
echo "Method used: $method"

# Count components if possible
COMPONENT_COUNT=$(jq '.components // [] | length' "$output_file" 2>/dev/null || echo "unknown")
echo "Components found: $COMPONENT_COUNT"

# Set environment variable for downstream steps
echo "SBOM_FILE_PATH=$output_file" >> $GITHUB_ENV

# Display detailed summary
echo "=== SBOM Generation Summary ==="
echo "Method: $method"
echo "Output Format: $output_format"
echo "Output File: $output_file"

# Show SBOM preview if components exist
if [ "$COMPONENT_COUNT" != "unknown" ] && [ "$COMPONENT_COUNT" -gt 0 ]; then
  echo "=== SBOM File Preview ==="
  head -20 "$output_file"
fi

echo "=== SBOM Generation Complete ==="
