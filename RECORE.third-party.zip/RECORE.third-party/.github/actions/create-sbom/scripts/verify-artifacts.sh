#!/bin/bash

# Script to verify source artifacts structure
# Usage: verify-artifacts.sh <sbomScanTarget> <thirdPartySourceArtifact>

sbom_scan_target="$1"
third_party_artifact="$2"

echo "=== Verifying Source Artifacts ==="

# Check if this is a Docker image scan
if [[ "$sbom_scan_target" =~ ^.*\.(com|net|org|io).*:.* ]] || [[ "$sbom_scan_target" =~ ^[a-zA-Z0-9.-]+/[a-zA-Z0-9._/-]+:.+ ]]; then
  echo "Docker image scan detected: $sbom_scan_target"
  echo "Skipping filesystem verification for Docker image"
elif [ -n "$third_party_artifact" ]; then
  echo "Downloaded Artifact: $third_party_artifact"
  
  if [ -d "$sbom_scan_target" ]; then
    echo "Extraction path exists: $sbom_scan_target"
    echo "Contents:"
    ls -la "$sbom_scan_target"
    
    # Check if it's empty
    if [ -z "$(ls -A "$sbom_scan_target")" ]; then
      echo "ERROR: Extraction path is empty! Artifact download may have failed."
      exit 1
    fi
    
    # Count files and directories
    FILE_COUNT=$(find "$sbom_scan_target" -type f | wc -l)
    DIR_COUNT=$(find "$sbom_scan_target" -type d | wc -l)
    echo "Found $FILE_COUNT files and $DIR_COUNT directories"
    
    # Show a sample of files (using ls for simplicity)
    echo "Sample files (first 10):"
    (find "$sbom_scan_target" -type f | head -10) 2>/dev/null || {
      echo "Using directory listing instead:"
      ls -la "$sbom_scan_target" | head -10 || true
    }
    
  else
    echo "ERROR: Extraction path does not exist: $sbom_scan_target"
    exit 1
  fi
else
  echo "No artifact specified - will scan specified target: $sbom_scan_target"
  if [ -d "$sbom_scan_target" ]; then
    echo "Target directory contents:"
    ls -la "$sbom_scan_target"
  else
    echo "Target directory does not exist: $sbom_scan_target"
    echo "This may be a Docker image or current directory will be used"
  fi
fi
