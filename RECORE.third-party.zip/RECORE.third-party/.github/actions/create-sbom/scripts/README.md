# Create SBOM Scripts

This directory contains modular scripts used by the create-sbom action. Each script handles a specific part of the SBOM generation process.

## Scripts

### `determine-method.sh`
Determines which SBOM generation method to use based on input parameters.
- **Usage**: `determine-method.sh <sbomMethod> <outputFile>`
- **Purpose**: Simple method selection logic (api vs marketplace)

### `verify-artifacts.sh`
Verifies the structure and availability of source artifacts.
- **Usage**: `verify-artifacts.sh <sbomScanTarget> <thirdPartySourceArtifact>`
- **Purpose**: Validates downloaded artifacts and Docker images

### `fetch-sbom-api.sh`
Fetches SBOM from GitHub API.
- **Usage**: `fetch-sbom-api.sh <token> <owner> <repo> <outputFile>`
- **Purpose**: Retrieves SBOM from GitHub's dependency graph API

### `sanitize-sbom.sh`
Sanitizes SBOM data from API method.
- **Usage**: `sanitize-sbom.sh <outputFile>`
- **Purpose**: Cleans up invalid PURLs and handles null values

### `convert-cyclonedx.sh`
Converts SBOM to CycloneDX format.
- **Usage**: `convert-cyclonedx.sh <outputFile>`
- **Purpose**: Transforms API SBOM data to CycloneDX format

### `extract-purls.sh`
Extracts and classifies PURLs from SBOM.
- **Usage**: `extract-purls.sh <outputFile>`
- **Purpose**: Analyzes SBOM for Package URLs (PURLs)

### `validate-sbom.sh`
Validates generated SBOM and displays summary.
- **Usage**: `validate-sbom.sh <outputFile> <method> <outputFormat>`
- **Purpose**: Final validation and comprehensive summary

## Benefits

1. **Modularity**: Each script handles a specific function
2. **Reusability**: Scripts can be tested and maintained independently
3. **Maintainability**: Easier to update individual components
4. **Testability**: Individual scripts can be unit tested
5. **Readability**: Main action.yml is cleaner and more focused
6. **Consistency**: Follows the same pattern as other actions in the repository

## Usage in Action

The main `action.yml` calls these scripts using the `${{ github.action_path }}/scripts/` pattern, ensuring they're always found relative to the action location.

Example:
```yaml
- name: Determine SBOM Generation Method
  shell: bash
  run: |
    ${{ github.action_path }}/scripts/determine-method.sh "${{ inputs.sbomMethod }}" "${{ inputs.outputFile }}"
```
