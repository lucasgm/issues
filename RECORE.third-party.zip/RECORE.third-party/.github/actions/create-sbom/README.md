# Create SBOM Action

This action generates Software Bill of Materials (SBOM) using either GitHub API or marketplace actions based on the available inputs and artifacts.

## Features

- **Simple Method Selection**: Uses API method by default, or marketplace action method when explicitly specified
- **Third-Party Source Support**: Downloads and scans artifacts using marketplace actions
- **GitHub Dependency Support**: Fetches SBOM from GitHub's dependency graph API
- **Flexible Configuration**: Supports both API and marketplace action selection
- **Multiple Output Formats**: Supports CycloneDX, SPDX, and Syft JSON formats

## Usage

### Default API Method (Recommended)

```yaml
- name: Generate SBOM
  uses: icesdlc/recore.ReusableWorkflows/actions/create-sbom@v0
  with:
    # GitHub API method inputs (default behavior)
    appId: ${{ inputs.appId }}
    privateKey: ${{ secrets.PRIVATE_KEY }}
    
    # Uses API method by default for repository dependencies
```

### Force Marketplace Action Method for Third-Party Sources

```yaml
- name: Generate SBOM (Marketplace Action for Third-Party)
  uses: icesdlc/recore.ReusableWorkflows/actions/create-sbom@v0
  with:
    # Force marketplace action method for third-party sources
    sbomMethod: "marketplace"
    thirdPartySourceArtifact: ${{ inputs.artifactoryBuildName }}.${{ inputs.artifactoryBuildNumber }}
```

### Force GitHub API Method (Explicit)

```yaml
- name: Generate SBOM (API)
  uses: icesdlc/recore.ReusableWorkflows/actions/create-sbom@v0
  with:
    sbomMethod: "api"
    appId: ${{ inputs.appId }}
    privateKey: ${{ secrets.PRIVATE_KEY }}
```

### Force Marketplace Action Method with Current Directory

```yaml
- name: Generate SBOM (Marketplace Action Current Directory)
  uses: icesdlc/recore.ReusableWorkflows/actions/create-sbom@v0
  with:
    sbomMethod: "marketplace"
    # If no artifact specified, will scan current directory
    # If thirdPartySourceArtifact specified, will download and scan that
```

### Marketplace Action with Docker Image

```yaml
- name: Generate SBOM (Marketplace Action)
  uses: icesdlc/recore.ReusableWorkflows/actions/create-sbom@v0
  with:
    sbomMethod: "marketplace"
    sbomScanTarget: ${{ env.SBOM_TAG }}  # Docker image or filesystem path
    outputFile: ${{ inputs.sbomOutputFile }}
    outputFormat: "cyclonedx-json"
```

### Marketplace Action with Artifact

```yaml
- name: Generate SBOM (Marketplace Action)
  uses: icesdlc/recore.ReusableWorkflows/actions/create-sbom@v0
  with:
    sbomMethod: "marketplace"
    thirdPartySourceArtifact: "my-sources.1.0.0"
```

## Inputs

### GitHub API Method Inputs
- `appId`: GitHub App ID for API-based SBOM generation
- `privateKey`: GitHub App private key for API-based SBOM generation
- `owner`: GitHub organization or user (default: repository owner)
- `repo`: GitHub repo name (default: repository name)

### Marketplace Action Method Inputs
- `thirdPartySourceArtifact`: Name of the third-party source artifact to download and scan
- `sbomScanTarget`: Target to scan for SBOM generation - can be a filesystem path (for extracted sources) or Docker image (e.g., myimage:tag)
- `uploadArtifact`: Whether to upload SBOM as artifact (marketplace mode) (default: "false")
- `workflowArtifactName`: Name for the uploaded artifact (required if uploadArtifact is true)

### Common Inputs
- `outputFile`: Output file name for SBOM (default: "sbom.json")
- `outputFormat`: Output format for SBOM (default: "cyclonedx-json")
- `sbomMethod`: SBOM generation method - "api" or "marketplace" (default: "api")

## Outputs

- `sbomMethod`: The method used to generate the SBOM ("api" or "marketplace")
- `sbomFilePath`: Path to the generated SBOM file

## Generated Artifacts

The action automatically uploads all SBOM-related files as artifacts for complete transparency and easy access.

### Artifact Upload: `sbom-files-{run_id}`

The action creates a comprehensive artifact containing all SBOM versions and processing files:

| File | Description | Purpose |
|------|-------------|---------|
| **`sbom.json`** | **Original SBOM file** (preserved) | The unmodified SBOM as generated/received - use for compliance/audit |
| **`sbom-sanitized.json`** | **Sanitized SBOM** | Invalid PURLs removed, null values cleaned up |
| **`sbom-cyclonedx.json`** | **CycloneDX format SBOM** | Converted to CycloneDX format with proper structure |
| **`sbom-formatted.json`** | **Pretty-formatted SBOM** | Human-readable version for analysis and review |

### File Preservation Strategy

- **Original preserved**: `sbom.json` remains exactly as generated (from API or marketplace actions)
- **Processing versions**: Each transformation step creates a new file with descriptive suffix
- **No overwriting**: Original files are never modified to maintain audit integrity
- **Complete transparency**: All processing steps and intermediate results available

### Processing Flow

```
GitHub API/Marketplace Action → sbom.json (original preserved)
     ↓
Sanitization (API only) → sbom-sanitized.json (new file)
     ↓
CycloneDX Conversion (API only) → sbom-cyclonedx.json (new file)
     ↓
Formatting → sbom-formatted.json (new file)
```

### Use Cases

- **`sbom.json`**: Use for compliance, audit, or when you need the exact original
- **`sbom-sanitized.json`**: Use when you need cleaned data but original format (API method only)
- **`sbom-cyclonedx.json`**: Use for tools that require CycloneDX format specifically (API method only)
- **`sbom-formatted.json`**: Use for human review, analysis, or pretty-printed reports

**Retention**: All files retained for 30 days automatically

## Method Selection Logic

The action uses the following simple logic to determine which method to use:

1. **Default**: Uses **API method** for repository dependencies (when `sbomMethod` is not specified or set to "api")
2. **Marketplace Override**: Uses **marketplace action method** only when `sbomMethod` is explicitly set to "marketplace"

### Method Comparison

| Method | Tool Used | Use Case |
|--------|-----------|----------|
| `api` (default) | GitHub API | Repository dependencies, standard projects |
| `marketplace` | Marketplace action (anchore/sbom-action) | Third-party sources, container images, extracted files |

## Artifact Pattern

The action automatically derives source artifact information using the same pattern as other workflows (like RPM):

This action uses the same simple artifact download pattern as the RPM workflow.

For third-party workflows, the artifact is typically named:
```
${{ inputs.artifactoryBuildName }}.${{ inputs.artifactoryBuildNumber }}
```

The download logic is simple and reliable:
```yaml
# Same pattern as RPM workflow
- name: Download Source Artifacts
  if: inputs.artifactName != ''
  uses: actions/download-artifact@v4
  with:
    name: ${{ inputs.artifactName }}
    path: extracted_sources
```

This approach is:
- **Simple**: Uses the proven pattern from existing workflows
- **Reliable**: No complex discovery logic or API calls
- **Consistent**: Matches the artifact handling in RPM, thirdparty, and other workflows

## Integration with Workflows

### Typical Third-Party Workflow Integration

In your third-party processing workflow, you no longer need to call legacy SBOM actions directly. Instead, the artifactory workflow will handle SBOM generation:

```yaml
# Third-party workflow (thirdparty.yml)
- name: Upload Build Artifacts
  uses: actions/upload-artifact@v4
  with:
    name: ${{ inputs.artifactoryBuildName }}.${{ inputs.artifactoryBuildNumber }}
    path: extracted_sources/

# No SBOM generation here anymore - moved to artifactory workflow
```

### Artifactory Workflow Integration

```yaml
# Artifactory workflow (artifactory.yml)
- name: Generate SBOM (Unified)
  uses: icesdlc/recore.ReusableWorkflows/actions/create-sbom@v0
  with:
    appId: ${{ inputs.appId }}
    privateKey: ${{ secrets.PRIVATE_KEY }}
    # Uses same artifact pattern as RPM workflow
    artifactName: ${{ inputs.artifactoryBuildName }}.${{ inputs.artifactoryBuildNumber }}
```

## Benefits

1. **Simplified Workflows**: Single action handles both repository and third-party SBOM generation
2. **Intelligent Selection**: Uses the appropriate method based on configuration (API for repo deps, marketplace actions for third-party sources)
3. **Simple Pattern**: Uses the same artifact download pattern as other workflows
4. **Reduced Duplication**: Eliminates the need for separate legacy SBOM actions
5. **Better Integration**: Seamlessly works with artifact upload/download patterns
6. **Consistent Output**: Produces standardized SBOM format regardless of generation method
7. **No External Dependencies**: Works entirely with built-in GitHub Actions capabilities

## Error Handling

The action includes comprehensive error handling:
- Validates that scan targets exist before processing
- Checks for valid JSON output
- Provides detailed logging for troubleshooting
- Fails gracefully with descriptive error messages

## Complete Workflow Examples

### Third-Party Application Workflow

```yaml
name: Third-Party Application CI/CD

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  # Step 1: Process third-party sources
  process-sources:
    uses: icesdlc/recore.ReusableWorkflows/.github/workflows/thirdparty.yml@v0
    with:
      sourceUrl: "https://releases.apache.org/kafka/3.5.0/kafka_2.13-3.5.0.tgz"
      # thirdPartySourceArtifact: "kafka-sources"  # Optional - defaults to "thirdparty-source"
      version: "3.5.0"
      keepParentFolder: true
      runnerGroup: "icelinux-small"
    secrets:
      username: ${{ secrets.DOWNLOAD_USERNAME }}
      password: ${{ secrets.DOWNLOAD_PASSWORD }}
      SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}

  # Step 2: Publish to artifactory with SBOM generation
  publish-artifactory:
    needs: [process-sources]
    uses: icesdlc/recore.ReusableWorkflows/.github/workflows/artifactory.yml@v0
    with:
      artifactoryPath: "RE_generic_files/"
      artifactoryBuildName: "kafka-sources"
      artifactoryBuildNumber: "3.5.0"
      runtime: "default"
      
      # SBOM generation - uses create-sbom action automatically
      appId: 1472178
      # thirdPartySourceArtifact: "thirdparty-source"  # Optional - uses default value
      
      # Security scanning
      failureSeverityThreshold: "high"
      sbomFilePath: "sbom.json"
    secrets:
      PRIVATE_KEY_1472178: ${{ secrets.PRIVATE_KEY_1472178 }}
      GPG_PRIVATE_KEY: ${{ secrets.GPG_PRIVATE_KEY }}
      GPG_PASSWORD: ${{ secrets.GPG_PASSWORD }}
      GPG_PUBLIC_KEY: ${{ secrets.GPG_PUBLIC_KEY }}
      ICE_ARTIF_WRITER_TOKEN: ${{ secrets.ICE_ARTIF_WRITER_TOKEN }}
      BASE_TOKEN: ${{ secrets.BASE_TOKEN }}
      SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
```

### Repository Dependencies Workflow

```yaml
name: Repository Dependencies CI/CD

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  # Build step (your existing build logic)
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build Application
        run: |
          # Your build commands here
          mkdir -p dist
          echo "Built application" > dist/app.jar
      
      - name: Upload Build Artifacts
        uses: actions/upload-artifact@v4
        with:
          name: "my-app.1.0.0"
          path: dist/

  # Publish to artifactory (SBOM will be generated automatically)
  publish-artifactory:
    needs: [build]
    uses: icesdlc/recore.ReusableWorkflows/.github/workflows/artifactory.yml@v0
    with:
      artifactoryPath: "RE_generic_files/"
      artifactoryBuildName: "my-app"
      artifactoryBuildNumber: "1.0.0"
      runtime: "maven"
      
      # For repository dependencies, only GitHub API inputs needed
      appId: 1472178
      # No thirdPartySourceArtifact = uses API method for repository dependencies
      
      # Security scanning
      failureSeverityThreshold: "high"
      sbomFilePath: "sbom.json"
    secrets:
      PRIVATE_KEY_1472178: ${{ secrets.PRIVATE_KEY_1472178 }}
      GPG_PRIVATE_KEY: ${{ secrets.GPG_PRIVATE_KEY }}
      GPG_PASSWORD: ${{ secrets.GPG_PASSWORD }}
      GPG_PUBLIC_KEY: ${{ secrets.GPG_PUBLIC_KEY }}
      ICE_ARTIF_WRITER_TOKEN: ${{ secrets.ICE_ARTIF_WRITER_TOKEN }}
      BASE_TOKEN: ${{ secrets.BASE_TOKEN }}
      SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}
```

### Mixed Workflow (Both Third-Party and Repository Dependencies)

```yaml
name: Mixed Application CI/CD

on:
  push:
    branches: [main]

jobs:
  # Process third-party dependencies
  process-third-party:
    uses: icesdlc/recore.ReusableWorkflows/.github/workflows/thirdparty.yml@v0
    with:
      sourceUrl: "https://example.com/external-lib.tar.gz"
      # thirdPartySourceArtifact: "external-lib"  # Optional - defaults to "thirdparty-source"
      version: "2.0.0"

  # Build repository code
  build-repo:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Build
        run: |
          mkdir -p dist
          echo "Built app with external deps" > dist/app.jar
      - name: Upload Build Artifacts
        uses: actions/upload-artifact@v4
        with:
          name: "mixed-app.1.0.0"
          path: dist/

  # Publish third-party components
  publish-third-party:
    needs: [process-third-party]
    uses: icesdlc/recore.ReusableWorkflows/.github/workflows/artifactory.yml@v0
    with:
      artifactoryPath: "RE_generic_files/third-party/"
      artifactoryBuildName: "external-lib"
      artifactoryBuildNumber: "2.0.0"
      appId: 1472178
      # thirdPartySourceArtifact: "thirdparty-source"  # Optional - uses default value
      sbomMethod: "marketplace"  # Force marketplace action method
    secrets:
      PRIVATE_KEY_1472178: ${{ secrets.PRIVATE_KEY_1472178 }}
      # ... other secrets

  # Publish repository components  
  publish-repo:
    needs: [build-repo]
    uses: icesdlc/recore.ReusableWorkflows/.github/workflows/artifactory.yml@v0
    with:
      artifactoryPath: "RE_generic_files/internal/"
      artifactoryBuildName: "mixed-app"
      artifactoryBuildNumber: "1.0.0"
      appId: 1472178
      # No thirdPartySourceArtifact = uses API method for repository dependencies
      sbomMethod: "api"  # Force API for repository deps
    secrets:
      PRIVATE_KEY_1472178: ${{ secrets.PRIVATE_KEY_1472178 }}
      # ... other secrets
```

## Key Configuration Points

### 1. **Zero Configuration for Repository Dependencies**
When using repository dependencies, the system works with **zero manual configuration**:
```yaml
# ✅ This is all you need for repository dependencies!
appId: 1472178
privateKey: ${{ secrets.PRIVATE_KEY_1472178 }}
# Uses API method by default
```

### 2. **Simple Configuration for Third-Party Sources**
When using third-party sources, explicitly set the marketplace method:
```yaml
# ✅ This is all you need for third-party sources!
sbomMethod: "marketplace"
thirdPartySourceArtifact: ${{ inputs.artifactoryBuildName }}.${{ inputs.artifactoryBuildNumber }}
```

### 2. **Simple Artifact Pattern**
The system uses the same proven pattern as the RPM workflow:
1. **Artifact upload**: `{name}.{version}`
2. **Artifact download**: Uses `thirdPartySourceArtifact` input
3. **Auto-construction**: `{buildName}.{buildNumber}` from workflow inputs

### 3. **Method Selection**
- **Default**: Uses API method for repository dependencies (no configuration needed)
- **Marketplace Override**: `sbomMethod: "marketplace"` for third-party sources
- **Marketplace Action**: Uses anchore/sbom-action marketplace action

### 4. **Secret Requirements**
- **For API method**: `PRIVATE_KEY_1472178` is required
- **For marketplace method**: `SNYK_TOKEN` is required for security scanning
- **For both**: Standard artifactory and GPG secrets

## Troubleshooting

### Common Issues

1. **Artifact Download Failed**: 
   - Ensure the thirdparty workflow completed successfully
   - Check that artifacts were uploaded with the standard naming pattern
   - Verify artifact name matches `{buildName}.{buildNumber}`

2. **SBOM Generation Failed**: Check the "Display SBOM Generation Results" step for method selection and errors

3. **Wrong Method Selected**: Use `sbomMethod` to specify the desired method ("api" or "marketplace")

4. **Security Scan Failed**: Ensure `SNYK_TOKEN` is properly configured and has necessary permissions
