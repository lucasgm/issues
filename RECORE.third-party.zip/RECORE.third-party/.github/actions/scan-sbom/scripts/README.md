# Scan SBOM Scripts

This directory contains the modular scripts that implement the SBOM security scanning functionality.

## Scripts Overview

### 1. `validate-inputs.sh`
**Purpose**: Input validation and environment setup  
**Usage**: `./validate-inputs.sh <sbom_file> <severity_threshold> <snyk_token> <show_summary> <fail_on_issues> <results_file>`

**What it does**:
- Validates SBOM file existence
- Checks severity threshold values
- Validates Snyk token presence
- Sets up output files for inter-script communication

**Output Files**:
- `sbom-file-exists.txt` - Boolean flag for SBOM file existence
- `severity-threshold.txt` - Validated severity threshold
- `show-summary.txt` - Validated show summary flag
- `fail-on-issues.txt` - Validated fail on issues flag
- `results-file-path.txt` - Path to results file
- Various status files initialized with defaults

### 2. `run-scan.sh`
**Purpose**: Execute Snyk SBOM scan  
**Usage**: `./run-scan.sh <sbom_file> <results_file>`

**What it does**:
- Sets up Snyk environment
- Executes the SBOM security scan using Snyk CLI
- Handles JSON output extraction and cleanup
- Manages scan artifacts and debug logs

**Output Files**:
- `snyk-exit-code.txt` - Snyk command exit code
- `snyk-results-raw.json` - Raw scan output
- `snyk-debug.log` - Debug logs from scan

### 3. `analyze-results.sh`
**Purpose**: Analyze scan results and determine status  
**Usage**: `./analyze-results.sh <results_file> <severity_threshold>`

**What it does**:
- Processes scan results and exit codes
- Counts vulnerabilities by severity using jq
- Determines bypass conditions (e.g., no testable packages)
- Calculates final scan status and build failure flags

**Output Files**:
- `scan-status.txt` - Final scan status (passed/failed/bypassed/passed_with_lower_severity)
- `build-should-fail.txt` - Boolean flag for build failure
- `threshold-count.txt` - Number of issues meeting severity threshold
- `threshold-desc.txt` - Description of threshold used
- `total-vulns.txt` - Total vulnerability count
- `total-license.txt` - Total license issue count
- `bypass-reason.txt` - Reason for bypass if applicable

### 4. `generate-summary.sh`
**Purpose**: Generate summaries and GitHub integration  
**Usage**: `./generate-summary.sh <sbom_file> <severity_threshold> <results_file> <show_summary>`

**What it does**:
- Creates console output summaries
- Generates GitHub Summary with detailed tables
- Formats vulnerability and license issue details
- Handles different scan status scenarios

**Output**: Console logs and GitHub Step Summary (if enabled)

### 5. `evaluate-results.sh`
**Purpose**: Final evaluation and build failure logic  
**Usage**: `./evaluate-results.sh`

**What it does**:
- Performs final build failure evaluation
- Respects `failOnIssues` configuration
- Provides comprehensive status logging
- Determines final exit code

**Exit Codes**:
- `0` - Success (build should continue)
- `1` - Failure (build should fail)

## Script Communication

Scripts communicate through temporary files written to the current working directory:

- **Status Files**: Store boolean flags and status values
- **Count Files**: Store numeric counts for vulnerabilities and issues
- **Configuration Files**: Store validated input parameters

## Error Handling

Each script implements robust error handling:
- Input validation with clear error messages
- Graceful degradation for missing dependencies
- Comprehensive logging of operations
- Proper exit codes for workflow control

## Testing Scripts Individually

You can test individual scripts for development and debugging:

```bash
# Navigate to the scripts directory
cd actions/scan-sbom/scripts

# Test input validation
./validate-inputs.sh "test-sbom.json" "high" "test-token" "true" "false" "results.json"

# Test scan execution (requires valid SBOM and Snyk setup)
SNYK_TOKEN="your-token" ./run-scan.sh "test-sbom.json" "results.json"

# Test results analysis
./analyze-results.sh "results.json" "high"

# Test summary generation
./generate-summary.sh "test-sbom.json" "high" "results.json" "true"

# Test final evaluation
./evaluate-results.sh
```

## Dependencies

- **bash**: All scripts require bash shell
- **jq**: Required for JSON processing in `analyze-results.sh` and `generate-summary.sh`
- **snyk**: Required for scan execution in `run-scan.sh`
- **Standard Unix tools**: grep, wc, cat, echo, etc.
