#!/bin/bash
# analyze-results.sh - Analyze Snyk scan results and determine status

set -e

# Function to build JQ filter based on severity threshold
build_jq_filter() {
    local threshold="$1"
    
    case "$threshold" in
        "critical")
            echo '.severity == "critical"'
            ;;
        "high")
            echo '.severity == "high" or .severity == "critical"'
            ;;
        "medium")
            echo '.severity == "medium" or .severity == "high" or .severity == "critical"'
            ;;
        "low")
            echo '.severity == "low" or .severity == "medium" or .severity == "high" or .severity == "critical"'
            ;;
        *)
            echo "⚠️  Unknown severity threshold '$threshold', defaulting to 'high'" >&2
            echo '.severity == "high" or .severity == "critical"'
            ;;
    esac
}

# Function to get threshold description
get_threshold_description() {
    local threshold="$1"
    
    case "$threshold" in
        "critical")
            echo "critical"
            ;;
        "high")
            echo "high/critical"
            ;;
        "medium")
            echo "medium/high/critical"
            ;;
        "low")
            echo "all severities"
            ;;
        *)
            echo "high/critical"
            ;;
    esac
}

# Function to count issues using jq
count_issues() {
    local results_file="$1"
    local jq_filter="$2"
    local issue_type="$3"
    
    if [ ! -f "$results_file" ]; then
        echo "0"
        return
    fi
    
    local count
    
    # Check if this is an enhanced report (has snyk_scan_results wrapper)
    local is_enhanced=false
    if jq -e '.snyk_scan_results' "$results_file" >/dev/null 2>&1; then
        is_enhanced=true
        echo "📋 Detected enhanced report format" >&2
    else
        echo "📋 Detected original Snyk report format" >&2
    fi
    
    if [ "$issue_type" = "vulnerabilities" ]; then
        if [ "$is_enhanced" = "true" ]; then
            count=$(jq -r ".snyk_scan_results.vulnerabilities[]? | select($jq_filter) | .id" "$results_file" 2>/dev/null | wc -l || echo "0")
        else
            count=$(jq -r ".vulnerabilities[]? | select($jq_filter) | .id" "$results_file" 2>/dev/null | wc -l || echo "0")
        fi
    elif [ "$issue_type" = "license_issues" ]; then
        if [ "$is_enhanced" = "true" ]; then
            count=$(jq -r ".snyk_scan_results.license_issues[]? | select($jq_filter) | .id" "$results_file" 2>/dev/null | wc -l || echo "0")
        else
            count=$(jq -r ".license_issues[]? | select($jq_filter) | .id" "$results_file" 2>/dev/null | wc -l || echo "0")
        fi
    elif [ "$issue_type" = "total_vulnerabilities" ]; then
        if [ "$is_enhanced" = "true" ]; then
            count=$(jq -r '.snyk_scan_results.vulnerabilities[]? | .id' "$results_file" 2>/dev/null | wc -l || echo "0")
        else
            count=$(jq -r '.vulnerabilities[]? | .id' "$results_file" 2>/dev/null | wc -l || echo "0")
        fi
    elif [ "$issue_type" = "total_license" ]; then
        if [ "$is_enhanced" = "true" ]; then
            count=$(jq -r '.snyk_scan_results.license_issues[]? | .id' "$results_file" 2>/dev/null | wc -l || echo "0")
        else
            count=$(jq -r '.license_issues[]? | .id' "$results_file" 2>/dev/null | wc -l || echo "0")
        fi
    else
        count="0"
    fi
    
    # Trim whitespace and ensure it's a number
    count=$(echo "$count" | tr -d ' ')
    if ! [[ "$count" =~ ^[0-9]+$ ]]; then
        count="0"
    fi
    
    echo "$count"
}

# Function to check for specific bypass conditions
check_bypass_conditions() {
    local results_file="$1"
    
    if [ -f "$results_file" ]; then
        # Check for various forms of "no testable packages" error
        if grep -qi "no testable packages" "$results_file" || \
           grep -qi "SNYK-SBOM-0010" "$results_file" || \
           grep -qi "did not contain any testable packages" "$results_file"; then
            echo "bypassed"
            echo "No testable packages found - Snyk could not analyze any dependencies" > bypass-reason.txt
            return 0
        fi
    fi
    
    echo "" > bypass-reason.txt
    return 1
}

# Function to analyze scan results
analyze_results() {
    local results_file="$1"
    local severity_threshold="$2"
    local snyk_exit_code="$3"
    
    echo "=== Analyzing scan results ==="
    echo "Results file: $results_file"
    echo "Severity threshold: $severity_threshold"
    echo "Snyk exit code: $snyk_exit_code"
    
    # Check if SBOM file existed
    if [ -f sbom-file-exists.txt ] && [ "$(cat sbom-file-exists.txt)" = "false" ]; then
        echo "❌ SBOM file was not found"
        echo "failed" > scan-status.txt
        echo "true" > build-should-fail.txt
        echo "0" > threshold-count.txt
        echo "file_not_found" > threshold-desc.txt
        echo "0" > total-vulns.txt
        echo "0" > total-license.txt
        return 0
    fi
    
    # Build JQ filter for severity threshold
    local jq_filter
    local threshold_desc
    
    jq_filter=$(build_jq_filter "$severity_threshold")
    threshold_desc=$(get_threshold_description "$severity_threshold")
    echo "$threshold_desc" > threshold-desc.txt
    
    echo "Threshold description: $threshold_desc"
    echo "JQ filter: $jq_filter"
    
    # Analyze based on exit code
    if [ "$snyk_exit_code" -eq 0 ]; then
        echo "✅ Snyk SBOM test passed - no vulnerabilities found"
        echo "passed" > scan-status.txt
        echo "false" > build-should-fail.txt
        echo "0" > threshold-count.txt
        echo "0" > total-vulns.txt
        echo "0" > total-license.txt
        return 0
    fi
    
    echo "❌ Snyk SBOM test failed with exit code: $snyk_exit_code"
    
    # Check for bypass conditions
    if check_bypass_conditions "$results_file"; then
        echo "⚠️  No testable packages found in SBOM - this may be expected for some third-party sources"
        echo "This is a known limitation, not a security issue - allowing build to continue"
        echo "bypassed" > scan-status.txt
        echo "false" > build-should-fail.txt
        echo "0" > threshold-count.txt
        echo "0" > total-vulns.txt
        echo "0" > total-license.txt
        return 0
    fi
    
    echo "Checking for vulnerabilities at $threshold_desc severity level..."
    
    # Count vulnerabilities and license issues
    local vuln_count
    local license_count
    local total_vulns
    local total_license
    
    vuln_count=$(count_issues "$results_file" "$jq_filter" "vulnerabilities")
    license_count=$(count_issues "$results_file" "$jq_filter" "license_issues")
    total_vulns=$(count_issues "$results_file" "" "total_vulnerabilities")
    total_license=$(count_issues "$results_file" "" "total_license")
    
    # Calculate total threshold-level issues
    local threshold_count=$((vuln_count + license_count))
    
    echo "Total vulnerabilities found: $total_vulns"
    echo "Total license issues found: $total_license"
    echo "$threshold_desc severity issues: $threshold_count (vulnerabilities: $vuln_count, license: $license_count)"
    
    # Save counts to files
    echo "$threshold_count" > threshold-count.txt
    echo "$total_vulns" > total-vulns.txt
    echo "$total_license" > total-license.txt
    
    # Determine scan status and build failure
    if [ "$threshold_count" -gt 0 ]; then
        echo "🚨 Found $threshold_count $threshold_desc severity issues - build must fail"
        echo "failed" > scan-status.txt
        echo "true" > build-should-fail.txt
    elif [ "$((total_vulns + total_license))" -gt 0 ]; then
        echo "⚠️  Found $((total_vulns + total_license)) total issue(s) but none meet the $threshold_desc threshold - allowing build to continue"
        echo "passed_with_lower_severity" > scan-status.txt
        echo "false" > build-should-fail.txt
    else
        echo "✅ No vulnerabilities or license issues found - scan passed"
        echo "passed" > scan-status.txt
        echo "false" > build-should-fail.txt
    fi
    
    return 0
}

# Main function
main() {
    local results_file="$1"
    local severity_threshold="$2"
    
    echo "=== SBOM Scan Results Analysis ==="
    echo "Timestamp: $(date)"
    echo ""
    
    # Read severity threshold from file if not provided
    if [ -z "$severity_threshold" ] && [ -f severity-threshold.txt ]; then
        severity_threshold=$(cat severity-threshold.txt)
    fi
    
    # Read Snyk exit code
    local snyk_exit_code=0
    if [ -f snyk-exit-code.txt ]; then
        snyk_exit_code=$(cat snyk-exit-code.txt)
    fi
    
    # Analyze the results
    analyze_results "$results_file" "$severity_threshold" "$snyk_exit_code"
    
    echo ""
    echo "✅ Results analysis completed"
    
    # Display final status
    local scan_status
    if [ -f scan-status.txt ]; then
        scan_status=$(cat scan-status.txt)
        echo "Final scan status: $scan_status"
    fi
    
    return 0
}

# Execute main function with all arguments
main "$@"
