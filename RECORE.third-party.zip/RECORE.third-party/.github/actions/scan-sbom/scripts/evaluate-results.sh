#!/bin/bash
# evaluate-results.sh - Final evaluation and build failure logic

set -e

# Function to read values from status files
read_status_file() {
    local file="$1"
    local default="$2"
    
    if [ -f "$file" ]; then
        cat "$file"
    else
        echo "$default"
    fi
}

# Function to perform final evaluation
evaluate_results() {
    local build_should_fail="$1"
    local fail_on_issues="$2"
    local scan_status="$3"
    local threshold_count="$4"
    local threshold_desc="$5"
    
    echo "=== Final Security Evaluation ==="
    echo "Build should fail: $build_should_fail"
    echo "Fail on issues: $fail_on_issues"
    echo "Scan status: $scan_status"
    
    if [ "$build_should_fail" = "true" ]; then
        if [ "$fail_on_issues" = "true" ]; then
            echo "🚨 Security scan detected issues that require attention"
            echo "Build must fail to prevent deployment of vulnerable code"
            echo "Check the scan artifacts for detailed vulnerability information"
            echo "Issues found: $threshold_count $threshold_desc severity"
            return 1
        else
            echo "⚠️  Security scan detected issues but failOnIssues is set to false"
            echo "Build will continue despite security issues (not recommended for production)"
            echo "Issues found: $threshold_count $threshold_desc severity"
            echo "Status: $scan_status"
            return 0
        fi
    else
        echo "✅ Security scan completed successfully"
        echo "Status: $scan_status"
        
        if [ "$scan_status" = "bypassed" ]; then
            local bypass_reason
            bypass_reason=$(read_status_file "bypass-reason.txt" "Unknown reason")
            echo "Note: Scan was bypassed due to known technical limitations, not security issues"
            echo "Bypass reason: $bypass_reason"
        fi
        
        return 0
    fi
}

# Function to log final status
log_final_status() {
    local scan_status="$1"
    local build_should_fail="$2"
    local fail_on_issues="$3"
    
    echo ""
    echo "=== Final Status Summary ==="
    echo "Scan Status: $scan_status"
    echo "Build Should Fail: $build_should_fail"
    echo "Fail On Issues: $fail_on_issues"
    
    if [ "$build_should_fail" = "true" ] && [ "$fail_on_issues" = "true" ]; then
        echo "Result: BUILD WILL FAIL ❌"
    else
        echo "Result: BUILD WILL CONTINUE ✅"
    fi
    
    echo "Timestamp: $(date)"
}

# Main function
main() {
    echo "=== SBOM Scan Results Evaluation ==="
    echo "Timestamp: $(date)"
    echo ""
    
    # Read status from files
    local build_should_fail
    local fail_on_issues
    local scan_status
    local threshold_count
    local threshold_desc
    
    build_should_fail=$(read_status_file "build-should-fail.txt" "false")
    fail_on_issues=$(read_status_file "fail-on-issues.txt" "false")
    scan_status=$(read_status_file "scan-status.txt" "unknown")
    threshold_count=$(read_status_file "threshold-count.txt" "0")
    threshold_desc=$(read_status_file "threshold-desc.txt" "unknown")
    
    # Log final status summary
    log_final_status "$scan_status" "$build_should_fail" "$fail_on_issues"
    
    echo ""
    
    # Perform final evaluation
    evaluate_results "$build_should_fail" "$fail_on_issues" "$scan_status" "$threshold_count" "$threshold_desc"
    local exit_code=$?
    
    echo ""
    if [ $exit_code -eq 0 ]; then
        echo "✅ Evaluation completed - build will continue"
    else
        echo "❌ Evaluation completed - build will fail"
    fi
    
    return $exit_code
}

# Execute main function
main "$@"
