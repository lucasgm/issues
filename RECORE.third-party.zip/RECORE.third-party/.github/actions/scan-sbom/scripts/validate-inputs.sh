#!/bin/bash
# validate-inputs.sh - Input validation for SBOM Scan action

set -e

# Function to validate SBOM file path
validate_sbom_file() {
    local sbom_file="$1"
    
    echo "=== Validating SBOM file ==="
    echo "SBOM file path: $sbom_file"
    
    if [ ! -f "$sbom_file" ]; then
        echo "❌ SBOM file not found: $sbom_file"
        echo "false" > sbom-file-exists.txt
        return 1
    fi
    
    echo "✅ SBOM file found: $sbom_file"
    echo "true" > sbom-file-exists.txt
    return 0
}

# Function to validate severity threshold
validate_severity_threshold() {
    local threshold="$1"
    
    echo "=== Validating severity threshold ==="
    echo "Severity threshold: $threshold"
    
    case "$threshold" in
        critical|high|medium|low)
            echo "✅ Valid severity threshold: $threshold"
            ;;
        *)
            echo "⚠️  Invalid severity threshold '$threshold', defaulting to 'high'"
            echo "high" > severity-threshold.txt
            return 0
            ;;
    esac
    
    echo "$threshold" > severity-threshold.txt
    return 0
}

# Function to check Snyk token
validate_snyk_token() {
    local snyk_token="$1"
    
    echo "=== Validating Snyk token ==="
    
    if [ -z "$snyk_token" ]; then
        echo "❌ Snyk token is required but not provided"
        return 1
    fi
    
    echo "✅ Snyk token provided"
    return 0
}

# Function to validate boolean inputs
validate_boolean() {
    local value="$1"
    local param_name="$2"
    
    case "$value" in
        true|false)
            echo "✅ Valid boolean value for $param_name: $value" >&2
            ;;
        *)
            echo "⚠️  Invalid boolean value for $param_name: '$value', defaulting to 'false'" >&2
            echo "false"
            return 0
            ;;
    esac
    echo "$value"
}

# Function to setup output files
setup_output_files() {
    echo "=== Setting up output files ==="
    
    # Initialize output files with default values
    echo "unknown" > scan-status.txt
    echo "false" > build-should-fail.txt
    echo "0" > threshold-count.txt
    echo "unknown" > threshold-desc.txt
    echo "0" > total-vulns.txt
    echo "0" > total-license.txt
    echo "" > bypass-reason.txt
    
    echo "✅ Output files initialized"
}

# Main validation function
main() {
    local sbom_file="$1"
    local severity_threshold="$2"
    local snyk_token="$3"
    local show_summary="$4"
    local fail_on_issues="$5"
    local results_file="$6"
    
    echo "=== SBOM Scan Input Validation ==="
    echo "Timestamp: $(date)"
    echo ""
    
    # Store validated inputs
    echo "$results_file" > results-file-path.txt
    
    # Validate boolean inputs
    show_summary=$(validate_boolean "$show_summary" "showSummary")
    echo "$show_summary" > show-summary.txt
    
    fail_on_issues=$(validate_boolean "$fail_on_issues" "failOnIssues")
    echo "$fail_on_issues" > fail-on-issues.txt
    
    # Validate core inputs
    validate_severity_threshold "$severity_threshold"
    validate_snyk_token "$snyk_token"
    
    # Setup output files
    setup_output_files
    
    # Validate SBOM file (can fail gracefully)
    if ! validate_sbom_file "$sbom_file"; then
        echo "failed" > scan-status.txt
        echo "true" > build-should-fail.txt
        echo "file_not_found" > threshold-desc.txt
        
        # Check if we should fail on this issue
        if [ "$fail_on_issues" = "true" ]; then
            echo "❌ Validation failed: SBOM file not found and failOnIssues=true"
            return 1
        else
            echo "⚠️  SBOM file not found but failOnIssues=false, continuing"
            return 0
        fi
    fi
    
    echo ""
    echo "✅ Input validation completed successfully"
    return 0
}

# Execute main function with all arguments
main "$@"
