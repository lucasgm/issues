#!/bin/bash
# generate-summary.sh - Generate security scan summary and GitHub Summary

set -e

# Function to extract dependency count from results file
extract_dependency_count() {
    local results_file="$1"
    local scan_status="$2"
    local dependency_count="N/A"
    
    # For bypassed scans (e.g., no testable packages), the actual scanned count is 0
    if [ "$scan_status" = "bypassed" ]; then
        echo "0"
        return
    fi
    
    if [ -f "$results_file" ]; then
        # Try to extract from enhanced report first
        if jq -e '.scan_metadata.dependency_count' "$results_file" >/dev/null 2>&1; then
            dependency_count=$(jq -r '.scan_metadata.dependency_count // "N/A"' "$results_file" 2>/dev/null || echo "N/A")
        # Fall back to scanned_dependencies array length
        elif jq -e '.scanned_dependencies' "$results_file" >/dev/null 2>&1; then
            dependency_count=$(jq -r '.scanned_dependencies | length' "$results_file" 2>/dev/null || echo "N/A")
        # Fall back to Snyk's dependencyCount
        elif jq -e '.snyk_scan_results.dependencyCount' "$results_file" >/dev/null 2>&1; then
            dependency_count=$(jq -r '.snyk_scan_results.dependencyCount // "N/A"' "$results_file" 2>/dev/null || echo "N/A")
        # Fall back to original dependencyCount
        elif jq -e '.dependencyCount' "$results_file" >/dev/null 2>&1; then
            dependency_count=$(jq -r '.dependencyCount // "N/A"' "$results_file" 2>/dev/null || echo "N/A")
        fi
    fi
    
    echo "$dependency_count"
}

# Function to read values from status files
read_status_file() {
    local file="$1"
    local default="$2"
    
    if [ -f "$file" ]; then
        cat "$file"
    else
        echo "$default"
    fi
}

# Function to build JQ filter for detailed reporting
build_jq_filter_for_details() {
    local threshold="$1"
    
    case "$threshold" in
        "critical")
            echo '.severity == "critical"'
            ;;
        "high")
            echo '.severity == "high" or .severity == "critical"'
            ;;
        "medium")
            echo '.severity == "medium" or .severity == "high" or .severity == "critical"'
            ;;
        "low")
            echo '.severity == "low" or .severity == "medium" or .severity == "high" or .severity == "critical"'
            ;;
        *)
            echo '.severity == "high" or .severity == "critical"'
            ;;
    esac
}

# Function to generate console summary
generate_console_summary() {
    local scan_status="$1"
    local severity_threshold="$2"
    local total_vulns="$3"
    local total_license="$4"
    local threshold_count="$5"
    local threshold_desc="$6"
    local bypass_reason="$7"
    
    echo "=== Security Scan Summary ==="
    echo "Snyk Scan Status: $scan_status"
    echo "Failure Severity Threshold: $severity_threshold"
    
    case "$scan_status" in
        "bypassed")
            echo "⚠️  Bypass Reason: $bypass_reason"
            echo "Note: This bypass is only allowed for specific known limitations"
            ;;
        "passed")
            echo "✅ No security vulnerabilities detected"
            echo "Vulnerabilities Found: $total_vulns"
            echo "License Issues: $total_license"
            ;;
        "passed_with_lower_severity")
            echo "⚠️  Found $total_vulns vulnerabilities and $total_license license issues"
            echo "✅ No $threshold_desc severity issues - build allowed to continue"
            ;;
        "failed")
            echo "🚨 Found $threshold_count $threshold_desc severity issues"
            echo "🚨 Build will fail to prevent deployment of vulnerable code"
            ;;
    esac
}

# Function to generate GitHub Summary
generate_github_summary() {
    local scan_status="$1"
    local severity_threshold="$2"
    local results_file="$3"
    local sbom_file="$4"
    local total_vulns="$5"
    local total_license="$6"
    local threshold_count="$7"
    local threshold_desc="$8"
    local bypass_reason="$9"
    local fail_on_issues="${10}"
    
    echo "=== Generating GitHub Summary ==="
    
    # Create GitHub Summary header
    echo "# 🛡️ SBOM Security Scan Results" >> $GITHUB_STEP_SUMMARY
    echo "" >> $GITHUB_STEP_SUMMARY
    
    case "$scan_status" in
        "bypassed")
            echo "## ⚠️ Scan Bypassed" >> $GITHUB_STEP_SUMMARY
            echo "**Reason:** $bypass_reason" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            echo "> This bypass is only allowed for specific known technical limitations, not security issues." >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            
            # Add dependency count information for bypassed scans
            local dependency_count
            dependency_count=$(extract_dependency_count "$results_file" "$scan_status")
            
            echo "| Metric | Count |" >> $GITHUB_STEP_SUMMARY
            echo "|--------|-------|" >> $GITHUB_STEP_SUMMARY
            echo "| Dependencies Scanned | $dependency_count |" >> $GITHUB_STEP_SUMMARY
            echo "| Vulnerabilities Found | N/A |" >> $GITHUB_STEP_SUMMARY
            echo "| License Issues Found | N/A |" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            echo "⚠️ **Result:** Security scan could not be performed due to technical limitations. Manual review may be required." >> $GITHUB_STEP_SUMMARY
            ;;
        "passed")
            echo "## ✅ Scan Passed" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            echo "🎉 **Great news!** No security vulnerabilities or license issues detected in the SBOM." >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            
            # Extract dependency count from results file
            local dependency_count
            dependency_count=$(extract_dependency_count "$results_file" "$scan_status")
            
            echo "| Metric | Count |" >> $GITHUB_STEP_SUMMARY
            echo "|--------|-------|" >> $GITHUB_STEP_SUMMARY
            echo "| Dependencies Scanned | $dependency_count |" >> $GITHUB_STEP_SUMMARY
            echo "| Vulnerabilities Found | 0 |" >> $GITHUB_STEP_SUMMARY
            echo "| License Issues Found | 0 |" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            echo "✅ **Result:** All dependencies are secure and compliant." >> $GITHUB_STEP_SUMMARY
            ;;
        "passed_with_lower_severity")
            echo "## ⚠️ Issues Found (Below Threshold)" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            
            # Add dependency count information
            local dependency_count
            dependency_count=$(extract_dependency_count "$results_file" "$scan_status")
            
            echo "| Metric | Count |" >> $GITHUB_STEP_SUMMARY
            echo "|--------|-------|" >> $GITHUB_STEP_SUMMARY
            echo "| Dependencies Scanned | $dependency_count |" >> $GITHUB_STEP_SUMMARY
            echo "| Vulnerabilities Found | $total_vulns |" >> $GITHUB_STEP_SUMMARY
            echo "| License Issues Found | $total_license |" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            echo "✅ **Result:** No **$threshold_desc** severity issues found - build allowed to continue." >> $GITHUB_STEP_SUMMARY
            ;;
        "failed")
            echo "## 🚨 Scan Failed" >> $GITHUB_STEP_SUMMARY
            echo "Found **$threshold_count** issues meeting the **$threshold_desc** severity threshold." >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            
            # Add dependency count information
            local dependency_count
            dependency_count=$(extract_dependency_count "$results_file" "$scan_status")
            
            echo "| Metric | Count |" >> $GITHUB_STEP_SUMMARY
            echo "|--------|-------|" >> $GITHUB_STEP_SUMMARY
            echo "| Dependencies Scanned | $dependency_count |" >> $GITHUB_STEP_SUMMARY
            echo "| Total Vulnerabilities | $total_vulns |" >> $GITHUB_STEP_SUMMARY
            echo "| Total License Issues | $total_license |" >> $GITHUB_STEP_SUMMARY
            echo "| Issues Meeting Threshold | $threshold_count |" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            
            generate_detailed_failure_summary "$results_file" "$severity_threshold" "$total_vulns" "$total_license" "$fail_on_issues"
            ;;
    esac
    
    # Add common footer information
    echo "" >> $GITHUB_STEP_SUMMARY
    echo "---" >> $GITHUB_STEP_SUMMARY
    echo "**Severity Threshold:** $severity_threshold" >> $GITHUB_STEP_SUMMARY
    echo "**SBOM File:** \`$sbom_file\`" >> $GITHUB_STEP_SUMMARY
    
    # Add count comparison if available
    if [ -f "$results_file" ]; then
        echo "**Artifacts:** Detailed JSON report available in workflow artifacts" >> $GITHUB_STEP_SUMMARY
        
        # Show count comparison if available in enhanced report
        local snyk_count
        local sbom_count 
        local difference
        
        snyk_count=$(jq -r '.scan_metadata.count_comparison.snyk_reported // "N/A"' "$results_file" 2>/dev/null || echo "N/A")
        sbom_count=$(jq -r '.scan_metadata.count_comparison.sbom_extracted // "N/A"' "$results_file" 2>/dev/null || echo "N/A")
        difference=$(jq -r '.scan_metadata.count_comparison.difference // "N/A"' "$results_file" 2>/dev/null || echo "N/A")
        
        if [ "$snyk_count" != "N/A" ] && [ "$sbom_count" != "N/A" ] && [ "$difference" != "N/A" ] && [ "$difference" != "0" ]; then
            echo "" >> $GITHUB_STEP_SUMMARY
            echo "<details>" >> $GITHUB_STEP_SUMMARY
            echo "<summary>🔍 Dependency Count Analysis</summary>" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            echo "| Source | Count | Notes |" >> $GITHUB_STEP_SUMMARY
            echo "|--------|-------|-------|" >> $GITHUB_STEP_SUMMARY
            echo "| Snyk Reported | $snyk_count | Total items Snyk attempted to scan |" >> $GITHUB_STEP_SUMMARY
            echo "| SBOM Extracted | $sbom_count | Actual package dependencies from SBOM |" >> $GITHUB_STEP_SUMMARY
            echo "| Difference | $difference | May include files, metadata, or transitive deps |" >> $GITHUB_STEP_SUMMARY
            echo "" >> $GITHUB_STEP_SUMMARY
            echo "ℹ️ **Note:** The 'Dependencies Scanned' count above shows the SBOM extracted count, which represents actual package dependencies analyzed for vulnerabilities." >> $GITHUB_STEP_SUMMARY
            echo "</details>" >> $GITHUB_STEP_SUMMARY
        fi
    fi
}

# Function to generate detailed failure summary
generate_detailed_failure_summary() {
    local results_file="$1"
    local severity_threshold="$2"
    local total_vulns="$3"
    local total_license="$4"
    local fail_on_issues="$5"
    
    # Build JQ filter for detailed reporting
    local jq_filter
    jq_filter=$(build_jq_filter_for_details "$severity_threshold")
    
    # Count threshold-level issues for detailed reporting
    local threshold_vulns=0
    local threshold_license=0
    
    if [ -f "$results_file" ]; then
        threshold_vulns=$(jq -r ".vulnerabilities[]? | select($jq_filter) | .id" "$results_file" 2>/dev/null | wc -l || echo "0")
        threshold_license=$(jq -r ".license_issues[]? | select($jq_filter) | .id" "$results_file" 2>/dev/null | wc -l || echo "0")
        
        # Clean up whitespace
        threshold_vulns=$(echo "$threshold_vulns" | tr -d ' ')
        threshold_license=$(echo "$threshold_license" | tr -d ' ')
    fi
    
    # Add detailed vulnerability information if available
    if [ -f "$results_file" ] && [ "$threshold_vulns" -gt 0 ]; then
        echo "### 🔍 Vulnerability Details" >> $GITHUB_STEP_SUMMARY
        echo "" >> $GITHUB_STEP_SUMMARY
        echo "| Vulnerability ID | Package | Severity | Title |" >> $GITHUB_STEP_SUMMARY
        echo "|------------------|---------|----------|-------|" >> $GITHUB_STEP_SUMMARY
        
        jq -r ".vulnerabilities[]? | select($jq_filter) | \"| \(.id) | \(.packageName)@\(.version) | \(.severity | ascii_upcase) | \(.title) |\"" "$results_file" 2>/dev/null | head -10 >> $GITHUB_STEP_SUMMARY || true
    fi
    
    # Add license issues if available
    if [ -f "$results_file" ] && [ "$threshold_license" -gt 0 ]; then
        echo "" >> $GITHUB_STEP_SUMMARY
        echo "### 📄 License Issues" >> $GITHUB_STEP_SUMMARY
        echo "" >> $GITHUB_STEP_SUMMARY
        echo "| License Issue ID | Package | Severity | License |" >> $GITHUB_STEP_SUMMARY
        echo "|------------------|---------|----------|---------|" >> $GITHUB_STEP_SUMMARY
        
        jq -r ".license_issues[]? | select($jq_filter) | \"| \(.id) | \(.packageName)@\(.version) | \(.severity | ascii_upcase) | \(.title) |\"" "$results_file" 2>/dev/null | head -10 >> $GITHUB_STEP_SUMMARY || true
    fi
    
    echo "" >> $GITHUB_STEP_SUMMARY
    if [ "$fail_on_issues" = "true" ]; then
        echo "🚨 **Build will fail** to prevent deployment of vulnerable code." >> $GITHUB_STEP_SUMMARY
    else
        echo "⚠️  **Build will continue** despite security issues (failOnIssues=false)." >> $GITHUB_STEP_SUMMARY
        echo "" >> $GITHUB_STEP_SUMMARY
        echo "> ⚠️  **Warning:** Continuing builds with security issues is not recommended for production environments." >> $GITHUB_STEP_SUMMARY
    fi
}

# Main function
main() {
    local sbom_file="$1"
    local severity_threshold="$2"
    local results_file="$3"
    local show_summary="$4"
    
    echo "=== SBOM Scan Summary Generation ==="
    echo "Timestamp: $(date)"
    echo ""
    
    # Read status from files
    local scan_status
    local total_vulns
    local total_license
    local threshold_count
    local threshold_desc
    local bypass_reason
    local fail_on_issues
    
    scan_status=$(read_status_file "scan-status.txt" "unknown")
    total_vulns=$(read_status_file "total-vulns.txt" "0")
    total_license=$(read_status_file "total-license.txt" "0")
    threshold_count=$(read_status_file "threshold-count.txt" "0")
    threshold_desc=$(read_status_file "threshold-desc.txt" "unknown")
    bypass_reason=$(read_status_file "bypass-reason.txt" "")
    fail_on_issues=$(read_status_file "fail-on-issues.txt" "false")
    
    # Generate console summary
    generate_console_summary "$scan_status" "$severity_threshold" "$total_vulns" "$total_license" "$threshold_count" "$threshold_desc" "$bypass_reason"
    
    # Generate GitHub Summary if requested
    if [ "$show_summary" = "true" ]; then
        generate_github_summary "$scan_status" "$severity_threshold" "$results_file" "$sbom_file" "$total_vulns" "$total_license" "$threshold_count" "$threshold_desc" "$bypass_reason" "$fail_on_issues"
        echo "✅ GitHub Summary generated"
    else
        echo "ℹ️  GitHub Summary generation skipped (showSummary=false)"
    fi
    
    echo ""
    echo "✅ Summary generation completed"
    return 0
}

# Execute main function with all arguments
main "$@"
