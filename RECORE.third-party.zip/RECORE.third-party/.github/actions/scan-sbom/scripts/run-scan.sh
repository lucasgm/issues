#!/bin/bash
# run-scan.sh - Execute Snyk SBOM scan

set -e

# Function to setup Snyk environment
setup_snyk() {
    echo "=== Setting up Snyk environment ==="
    
    # Check if Snyk is available
    if ! command -v snyk &> /dev/null; then
        echo "❌ Snyk CLI is not available"
        echo "Please ensure Snyk is installed and available in PATH"
        return 1
    fi
    
    echo "✅ Snyk CLI is available"
    snyk --version
    return 0
}

# Function to run Snyk SBOM test
run_snyk_scan() {
    local sbom_file="$1"
    local results_file="$2"
    
    echo "=== Running Snyk SBOM scan ==="
    echo "SBOM file: $sbom_file"
    echo "Results file: $results_file"
    echo ""
    
    # Always run the scan and capture results
    set +e  # Don't exit on error immediately
    
    # Run Snyk without debug to get clean JSON output
    echo "Executing: snyk sbom test --experimental --file=$sbom_file --json"
    snyk sbom test --experimental --file="$sbom_file" --json > snyk-results-raw.json 2>snyk-debug.log
    SNYK_EXIT_CODE=$?
    
    set -e  # Re-enable exit on error
    
    echo "Snyk exit code: $SNYK_EXIT_CODE"
    echo "$SNYK_EXIT_CODE" > snyk-exit-code.txt
    
    # Extract only the JSON part (in case there are still debug messages mixed in)
    if grep -q '{"ok":' snyk-results-raw.json; then
        # Extract the JSON part starting from the {"ok": line
        grep -o '{"ok":.*}$' snyk-results-raw.json > "$results_file" || cp snyk-results-raw.json "$results_file"
        echo "✅ JSON results extracted successfully"
    else
        # If no JSON found, copy the raw file and we'll handle the error later
        cp snyk-results-raw.json "$results_file"
        echo "⚠️  No clean JSON found, using raw output"
    fi
    
    # Log file sizes for debugging
    if [ -f snyk-results-raw.json ]; then
        echo "Raw results file size: $(wc -c < snyk-results-raw.json) bytes"
    fi
    if [ -f "$results_file" ]; then
        echo "Processed results file size: $(wc -c < "$results_file") bytes"
    fi
    if [ -f snyk-debug.log ]; then
        echo "Debug log file size: $(wc -c < snyk-debug.log) bytes"
    fi
    
    return 0
}

# Main function
main() {
    local sbom_file="$1"
    local results_file="$2"
    
    echo "=== SBOM Security Scan Execution ==="
    echo "Timestamp: $(date)"
    echo ""
    
    # Check if SBOM file exists (from validation step)
    if [ -f sbom-file-exists.txt ] && [ "$(cat sbom-file-exists.txt)" = "false" ]; then
        echo "⚠️  SBOM file does not exist, skipping scan"
        echo "0" > snyk-exit-code.txt
        return 0
    fi
    
    # Setup Snyk environment
    setup_snyk
    
    # Run the scan
    run_snyk_scan "$sbom_file" "$results_file"
    
    echo ""
    echo "✅ Scan execution completed"
    return 0
}

# Execute main function with all arguments
main "$@"
