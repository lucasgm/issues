# Scan SBOM Action

This composite action scans Software Bill of Materials (SBOM) files for vulnerabilities and license issues using Snyk. The action is built with a modular architecture using separate scripts for maintainability.

## Architecture

The action is organized into modular scripts for easy maintenance:

- **`validate-inputs.sh`** - Input validation and environment setup
- **`run-scan.sh`** - Snyk SBOM scan execution
- **`analyze-results.sh`** - Results analysis and status determination
- **`generate-summary.sh`** - Summary generation and GitHub integration
- **`evaluate-results.sh`** - Final evaluation and build failure logic

## Features

- Scans SBOM files for security vulnerabilities
- Checks for license compliance issues
- Configurable severity thresholds for build failures
- **Enhanced JSON reports** with complete dependency details extracted from SBOM
- Handles edge cases like "no testable packages found"
- Provides detailed outputs for downstream processing
- **Modular script architecture** for easy maintenance and testing
- **Built-in summary and evaluation steps** with configurable display
- **Automatic build failure** on security issues (configurable)
- **GitHub Summary integration** showing detailed scan results on the Summary tab

## Usage

```yaml
- name: Scan SBOM for Security Issues
  uses: icesdlc/recore.ReusableWorkflows/actions/scan-sbom@v0
  with:
    sbomFilePath: 'sbom.json'
    failureSeverityThreshold: 'high'
    snykToken: ${{ secrets.SNYK_TOKEN }}
    showSummary: 'true'
    failOnIssues: 'false'
```

## Inputs

| Input | Description | Required | Default |
|-------|-------------|----------|---------|
| `sbomFilePath` | Path to the SBOM file to scan | Yes | `sbom.json` |
| `failureSeverityThreshold` | Minimum severity level that causes build failure. Options: `critical`, `high`, `medium`, `low` | No | `high` |
| `snykToken` | Snyk authentication token | Yes | - |
| `generateHtmlReport` | Whether to generate HTML report | No | `true` |
| `showSummary` | Whether to display security scan summary | No | `true` |
| `failOnIssues` | Whether to fail the build when issues are found meeting the severity threshold | No | `false` |
| `resultsFilePath` | Path for the Snyk scan results JSON file | No | `snyk-results.json` |

## Outputs

| Output | Description |
|--------|-------------|
| `scanStatus` | Status of the scan: `passed`, `failed`, `passed_with_lower_severity`, `bypassed` |
| `buildShouldFail` | Whether the build should fail based on scan results (`true`/`false`) |
| `thresholdCount` | Number of issues meeting the severity threshold |
| `thresholdDescription` | Description of the severity threshold used |
| `totalVulnerabilities` | Total number of vulnerabilities found |
| `totalLicenseIssues` | Total number of license issues found |
| `bypassReason` | Reason for bypass if scan was bypassed |

## Severity Thresholds

- **`critical`**: Only fail on critical vulnerabilities
- **`high`**: Fail on high or critical vulnerabilities (default)
- **`medium`**: Fail on medium, high, or critical vulnerabilities
- **`low`**: Fail on any vulnerability (all severities)

## Generated Artifacts

The action automatically uploads all scan-related files as artifacts for easy access and debugging.

### Artifact Upload: `snyk-scan-reports-{run_id}`

The action creates a comprehensive artifact containing all scan results and processing files:

| File | Description | Purpose |
|------|-------------|---------|
| **`snyk-results.json`** | **Original Snyk scan results** (preserved) | The unmodified output from Snyk CLI - use for compliance/audit |
| **`snyk-results-enhanced.json`** | **Enhanced report with SBOM dependencies** | Combines Snyk results with complete dependency details extracted from SBOM |
| **`snyk-results-formatted.json`** | **Pretty-formatted results** | Human-readable version of enhanced results for analysis |
| **`snyk-results-raw.json`** | **Complete raw CLI output** | Full unprocessed output from Snyk command for debugging |
| **`snyk-debug.log`** | **Debug logs from Snyk execution** | Error messages, warnings, and execution details |

### File Preservation Strategy

- **Original preserved**: `snyk-results.json` remains exactly as received from Snyk
- **Enhanced versions**: Additional files created with descriptive suffixes
- **No overwriting**: Original files are never modified to maintain audit integrity
- **Complete transparency**: All processing steps and intermediate files available

### Enhanced Report Format

The enhanced `snyk-results-enhanced.json` includes:

```json
{
  "snyk_scan_results": {
    "ok": false,
    "dependencyCount": 4,
    "summary": "Found 2 issues",
    "vulnerabilities": [...],
    "license_issues": []
  },
  "scanned_dependencies": [
    {
      "name": "package-name",
      "version": "1.0.0",
      "type": "library",
      "purl": "pkg:npm/package-name@1.0.0",
      "supplier": "supplier-name",
      "licenses": "MIT"
    }
  ],
  "scan_metadata": {
    "enhanced_report_version": "1.0",
    "scan_timestamp": "2025-01-21T10:30:45Z",
    "dependency_count": 3,
    "sbom_format": "detected"
  }
}
```

**Dependency Count Logic**: 
- **Normal scans**: The GitHub Summary displays the `dependency_count` from Snyk's `dependencyCount` field, representing what Snyk actually scanned
- **Bypassed scans** (e.g., "no testable packages"): Shows 0, as Snyk could not scan any dependencies  
- **Enhanced metadata**: The `scan_metadata.dependency_count` field shows the SBOM-extracted count for comparison
- **Count differences**: Snyk may report different counts than SBOM extraction due to files, metadata, or transitive dependencies

This ensures the "Dependencies Scanned" metric accurately reflects what was actually analyzed for vulnerabilities, not just what was present in the SBOM.

This enhanced format provides complete visibility into both the scan results and all dependencies that were analyzed.

## Script Architecture

### Input Validation (`validate-inputs.sh`)
- Validates SBOM file existence
- Checks severity threshold values
- Validates Snyk token presence
- Sets up output files for inter-script communication

### Scan Execution (`run-scan.sh`)
- Sets up Snyk environment
- Executes the SBOM security scan
- Handles JSON output extraction
- Manages scan artifacts

### Results Analysis (`analyze-results.sh`)
- Processes scan results and exit codes
- Counts vulnerabilities by severity
- Determines bypass conditions
- Calculates final scan status

### Summary Generation (`generate-summary.sh`)
- Creates console output summaries
- Generates GitHub Summary with detailed tables
- Formats vulnerability and license issue details
- Handles different scan status scenarios

### Results Evaluation (`evaluate-results.sh`)
- Performs final build failure evaluation
- Respects `failOnIssues` configuration
- Provides comprehensive status logging
- Determines final exit code

## Example with Full Workflow

```yaml
- name: Generate SBOM
  uses: icesdlc/recore.ReusableWorkflows/actions/create-sbom@v0
  with:
    scanMethod: 'cli'
    scanTool: 'syft'

- name: Scan SBOM for Security Issues
  id: security-scan
  uses: icesdlc/recore.ReusableWorkflows/actions/scan-sbom@v0
  with:
    sbomFilePath: 'sbom.json'
    failureSeverityThreshold: 'medium'
    snykToken: ${{ secrets.SNYK_TOKEN }}

- name: Upload Scan Results
  uses: actions/upload-artifact@v4
  with:
    name: security-scan-results
    path: |
      snyk-results.json
      snyk-debug.log

- name: Fail Build on Security Issues
  if: steps.security-scan.outputs.buildShouldFail == 'true'
  run: |
    echo "🚨 Security scan found ${{ steps.security-scan.outputs.thresholdCount }} ${{ steps.security-scan.outputs.thresholdDescription }} severity issues"
    exit 1
```

## Error Handling

The modular architecture provides robust error handling:
- **Missing SBOM file**: Gracefully handled with clear error messages
- **No testable packages**: Bypassed with detailed reasoning and accurate dependency counts
- **Invalid inputs**: Validated and defaulted with warnings
- **Scan failures**: Comprehensive analysis and reporting
- **Script failures**: Each module handles errors independently

### Special Case: No Testable Packages

When Snyk reports "The provided SBOM did not contain any testable packages," the action:
- **Status**: Sets scan status to `bypassed` (not `passed`)
- **Dependencies Scanned**: Reports 0 (actual count scanned by Snyk, not SBOM count)
- **Summary Message**: Shows appropriate warning instead of "Great news!" 
- **Reasoning**: Provides clear explanation that this is a technical limitation
- **Build Result**: Continues build (does not fail) as this is not a security issue

This ensures accurate reporting when Snyk cannot analyze package types like Erlang/OTP, certain proprietary formats, or unsupported package managers.

## Development and Maintenance

The modular script architecture makes it easy to:
- **Test individual components** by running scripts independently
- **Debug specific functionality** by examining individual script outputs
- **Extend features** by modifying specific scripts
- **Maintain code quality** with smaller, focused modules

### Testing Individual Scripts

```bash
# Test input validation
./scripts/validate-inputs.sh "sbom.json" "high" "token" "true" "false" "results.json"

# Test scan execution
./scripts/run-scan.sh "sbom.json" "results.json"

# Test results analysis
./scripts/analyze-results.sh "results.json" "high"
```

## License Issues

The action also checks for license compliance issues in addition to security vulnerabilities. Both types of issues are counted towards the severity threshold.

## GitHub Summary Integration

The action automatically generates a detailed summary that appears on the GitHub Actions Summary tab, providing:

- **Visual status indicators** (✅ passed, ⚠️ bypassed/low severity, 🚨 failed)
- **Issue breakdown tables** showing counts by type and severity
- **Detailed vulnerability listings** with package information, severity, and descriptions
- **License issue details** when applicable
- **Bypass reasons** with clear explanations
- **Configuration details** (threshold, SBOM file path)

### Summary Examples

**When vulnerabilities are found:**
```
🛡️ SBOM Security Scan Results
## 🚨 Scan Failed
Found 2 issues meeting the high/critical severity threshold.

| Type | Total Found | Meeting Threshold |
|------|-------------|-------------------|
| Vulnerabilities | 3 | 1 |
| License Issues | 1 | 1 |

### 🔍 Vulnerability Details
| Vulnerability ID | Package | Severity | Title |
|------------------|---------|----------|-------|
| SNYK-PYTHON-REDIS-5291196 | redis@4.5.1 | MEDIUM | Exposure of Data Element to Wrong Session |

### 📄 License Issues  
| License Issue ID | Package | Severity | License |
|------------------|---------|----------|---------|
| snyk:lic:pip:codespell:GPL-2.0 | codespell@2.2.5 | HIGH | GPL-2.0 license |
```

## Customization Options

### Disable Summary Display
```yaml
- name: Scan SBOM (Silent)
  uses: icesdlc/recore.ReusableWorkflows/actions/scan-sbom@v0
  with:
    sbomFilePath: 'sbom.json'
    failureSeverityThreshold: 'high'
    snykToken: ${{ secrets.SNYK_TOKEN }}
    showSummary: 'false'  # No summary display
```

### Scan Only (Don't Fail Build)
```yaml
- name: Scan SBOM (Report Only)
  uses: icesdlc/recore.ReusableWorkflows/actions/scan-sbom@v0
  with:
    sbomFilePath: 'sbom.json'
    failureSeverityThreshold: 'high'
    snykToken: ${{ secrets.SNYK_TOKEN }}
    failOnIssues: 'false'  # Don't fail build, just report
```

**Note:** When `failOnIssues: 'false'`, the action will:
- Still run the scan and generate reports
- Still show detailed summaries and GitHub Summary
- **NOT** fail the build even if security issues are found
- Display warnings about continuing with security issues

### Custom Build Failure Logic
```yaml
- name: Scan SBOM with Custom Logic
  id: scan
  uses: icesdlc/recore.ReusableWorkflows/actions/scan-sbom@v0
  with:
    sbomFilePath: 'sbom.json'
    failureSeverityThreshold: 'medium'
    snykToken: ${{ secrets.SNYK_TOKEN }}
    failOnIssues: 'false'  # Handle failure logic ourselves

- name: Custom Failure Logic
  if: steps.scan.outputs.buildShouldFail == 'true'
  run: |
    echo "Custom handling of security issues..."
    # Your custom logic here
    exit 1
```
