#!/usr/bin/env python3
"""Discover tags and lifecycle metadata for IBM Cloud Container Registry (cp.icr.io) images.

Authentication: reads IBM_API_KEY (iamapikey) for standard ICR registries,
  and IBM_API_KEY (cp) for cp.icr.io entitled registry.
"""

import argparse
import concurrent.futures
import json
import os
import re
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple


EXCLUDE_PATTERN = re.compile(
    r"(beta|alpha|rc|dev|snapshot|test|nightly|preview|tech-preview)",
    re.IGNORECASE,
)

_ARCH_TAG_PATTERNS = {
    "amd64": [
        re.compile(r"(?:^|[-_.])amd64(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])x86_64(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])x64(?:$|[-_.])", re.IGNORECASE),
    ],
    "arm64": [
        re.compile(r"(?:^|[-_.])arm64(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])aarch64(?:$|[-_.])", re.IGNORECASE),
    ],
    "arm": [
        re.compile(r"(?:^|[-_.])armv7(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])armv6(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])armhf(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])arm(?:$|[-_.])", re.IGNORECASE),
    ],
    "ppc64le": [
        re.compile(r"(?:^|[-_.])ppc64le(?:$|[-_.])", re.IGNORECASE),
    ],
    "s390x": [
        re.compile(r"(?:^|[-_.])s390x(?:$|[-_.])", re.IGNORECASE),
    ],
}


def _is_digest(tag: str) -> bool:
    """Return True if tag is a digest (sha256:...)."""
    return tag.startswith("sha256:")


def _build_image_ref(repo: str, tag: str) -> str:
    """Build correct image ref: repo@sha256:... for digests, repo:tag for regular tags."""
    if _is_digest(tag):
        return f"{repo}@{tag}"
    return f"{repo}:{tag}"


def _get_creds(repo: str) -> Optional[str]:
    """Return appropriate credentials based on registry."""
    if "cp.icr.io" in repo:
        entitlement_key = os.environ.get("IBM_API_KEY", "").strip()
        if entitlement_key:
            return f"cp:{entitlement_key}"
        # fallback to API key with cp username
        api_key = os.environ.get("IBM_API_KEY", "").strip()
        if api_key:
            print(
                "[WARN] IBM_API_KEY not set; falling back to IBM_API_KEY for cp.icr.io (may fail for entitled images)",
                file=sys.stderr,
            )
            return f"cp:{api_key}"
        return None
    # Standard ICR registries (us.icr.io, icr.io, etc.)
    api_key = os.environ.get("IBM_API_KEY", "").strip()
    if api_key:
        return f"iamapikey:{api_key}"
    return None


def _normalise_arch_name(arch: str) -> str:
    a = arch.lower().strip()
    if a in {"x86_64", "x64"}:
        return "amd64"
    if a == "aarch64":
        return "arm64"
    return a


def _infer_arches_from_tag(tag: str) -> List[str]:
    found = set()
    for canon, patterns in _ARCH_TAG_PATTERNS.items():
        for pat in patterns:
            if pat.search(tag):
                found.add(canon)
                break
    return list(found)


def _parse_created_iso(created_raw: Optional[str]) -> Optional[datetime]:
    if not created_raw:
        return None
    val = created_raw.replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(val)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    return dt.replace(microsecond=0)


def run_skopeo_list_tags(repo: str) -> List[str]:
    """Return tags for docker://repo using skopeo with appropriate credentials."""
    creds = _get_creds(repo)
    cmd = ["skopeo", "list-tags"]
    if creds:
        cmd += ["--creds", creds]
    cmd.append(f"docker://{repo}")

    try:
        proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
    except FileNotFoundError:
        print(
            f"ERROR: skopeo not found on PATH; cannot discover tags for {repo}",
            file=sys.stderr,
        )
        return []

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(
            f"[WARN] skopeo list-tags failed for {repo} (rc={proc.returncode}): {msg[:200]}",
            file=sys.stderr,
        )
        return []

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        print(f"[WARN] Failed to parse skopeo output for {repo}: {exc}", file=sys.stderr)
        return []

    tags = data.get("Tags") or []
    return [t for t in tags if isinstance(t, str)]


def parse_min_date(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    m = re.match(r"^\s*(\d+)\s*(day|days|week|weeks|month|months)\s*$", value, re.IGNORECASE)
    if not m:
        print(f"[WARN] Unsupported min_date format '{value}'; ignoring.", file=sys.stderr)
        return None
    amount = int(m.group(1))
    unit = m.group(2).lower()
    if "day" in unit:
        delta = timedelta(days=amount)
    elif "week" in unit:
        delta = timedelta(weeks=amount)
    else:
        delta = timedelta(days=30 * amount)
    return datetime.now(timezone.utc) - delta


def inspect_tag_for_arches(
    repo: str,
    tag: str,
    arches: List[str],
    oses: Optional[List[str]] = None,
) -> Tuple[bool, Optional[datetime]]:
    """Return (ok, created_at_utc) for repo:tag or repo@digest with appropriate auth."""
    creds = _get_creds(repo)
    created_best: Optional[datetime] = None
    arches = arches or []
    oses = oses or []
    image_ref = _build_image_ref(repo, tag)

    # Digest refs don't support arch/os overrides — inspect directly
    if _is_digest(tag):
        try:
            cmd = ["skopeo", "inspect"]
            if creds:
                cmd += ["--creds", creds]
            cmd.append(f"docker://{image_ref}")
            proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
        except FileNotFoundError:
            print("ERROR: skopeo not found on PATH; cannot inspect images", file=sys.stderr)
            return False, None

        if proc.returncode != 0:
            msg = proc.stderr.strip() or proc.stdout.strip()
            print(
                f"[WARN] skopeo inspect failed for {image_ref} (rc={proc.returncode}): {msg[:200]}",
                file=sys.stderr,
            )
            return False, None

        try:
            data = json.loads(proc.stdout or "{}")
        except json.JSONDecodeError:
            return False, None

        created = _parse_created_iso(data.get("Created") or data.get("created"))
        return True, created

    if arches or oses:
        arch_list = arches or [None]
        os_list = oses or [None]

        for arch in arch_list:
            for os_val in os_list:
                try:
                    cmd = ["skopeo", "inspect"]
                    if creds:
                        cmd += ["--creds", creds]
                    if arch:
                        cmd.append(f"--override-arch={arch}")
                    if os_val:
                        cmd.append(f"--override-os={os_val}")
                    cmd.append(f"docker://{image_ref}")
                    proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
                except FileNotFoundError:
                    print("ERROR: skopeo not found on PATH; cannot inspect images", file=sys.stderr)
                    return False, None

                if proc.returncode != 0:
                    msg = proc.stderr.strip() or proc.stdout.strip()
                    details = []
                    if arch:
                        details.append(f"arch={arch}")
                    if os_val:
                        details.append(f"os={os_val}")
                    detail_str = " ".join(details) or "no-overrides"
                    print(
                        f"[WARN] skopeo inspect failed for {image_ref} {detail_str} (rc={proc.returncode}): {msg[:200]}",
                        file=sys.stderr,
                    )
                    continue

                try:
                    data = json.loads(proc.stdout or "{}")
                except json.JSONDecodeError:
                    continue

                created = _parse_created_iso(data.get("Created") or data.get("created"))
                if created and (created_best is None or created > created_best):
                    created_best = created

        return (created_best is not None), created_best

    try:
        cmd = ["skopeo", "inspect"]
        if creds:
            cmd += ["--creds", creds]
        cmd.append(f"docker://{image_ref}")
        proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
    except FileNotFoundError:
        print("ERROR: skopeo not found on PATH; cannot inspect images", file=sys.stderr)
        return False, None

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(
            f"[WARN] skopeo inspect failed for {image_ref} (rc={proc.returncode}): {msg[:200]}",
            file=sys.stderr,
        )
        return False, None

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError:
        print(f"[WARN] Failed to parse inspect output for {image_ref}", file=sys.stderr)
        return False, None

    created = _parse_created_iso(data.get("Created") or data.get("created"))
    return True, created


def build_repo_from_entry(entry: Dict) -> str:
    base_registry = (entry.get("base_registry") or "").rstrip("/")
    source_path = (entry.get("source_path") or "").lstrip("/")
    software = entry.get("software") or ""
    repo = "/".join(part for part in [base_registry, source_path, software] if part)
    return repo


def get_architectures_from_entry(entry: Dict) -> List[str]:
    container = entry.get("container") or {}
    arch_val = container.get("architecture")
    if isinstance(arch_val, list):
        return [str(a) for a in arch_val if isinstance(a, str) and a]
    if isinstance(arch_val, str) and arch_val.strip():
        return [arch_val.strip()]
    return []


def get_oses_from_entry(entry: Dict) -> List[str]:
    container = entry.get("container") or {}
    os_val = container.get("os")
    if isinstance(os_val, list):
        return [str(o) for o in os_val if isinstance(o, str) and o]
    if isinstance(os_val, str) and os_val.strip():
        return [os_val.strip()]
    return []


def inspect_metadata(
    repo: str,
    tag: str,
    arches: Optional[List[str]] = None,
    oses: Optional[List[str]] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """Return (release_date_iso, sunset_date_iso) using skopeo with appropriate auth."""
    creds = _get_creds(repo)
    image_ref = _build_image_ref(repo, tag)

    try:
        cmd = ["skopeo", "inspect"]
        if creds:
            cmd += ["--creds", creds]
        cmd.append(f"docker://{image_ref}")
        proc = subprocess.run(cmd, check=False, capture_output=True, text=True)
    except FileNotFoundError:
        print("ERROR: skopeo not found on PATH; cannot inspect images for metadata", file=sys.stderr)
        return None, None

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(
            f"[WARN] skopeo inspect for metadata failed for {image_ref} (rc={proc.returncode}): {msg[:200]}",
            file=sys.stderr,
        )
        return None, None

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        print(f"[WARN] Failed to parse inspect metadata output for {image_ref}: {exc}", file=sys.stderr)
        return None, None

    created_raw = data.get("Created") or data.get("created")
    created_dt = _parse_created_iso(created_raw)
    release_date: Optional[str] = None
    if created_dt is not None:
        release_date = created_dt.strftime("%Y-%m-%dT%H:%M:%SZ")

    labels = data.get("Labels") or data.get("labels") or {}
    sunset_date: Optional[str] = None
    if isinstance(labels, dict):
        for key in ("vendor.eol", "maintainer.eol", "org.opencontainers.image.endoflife"):
            val = labels.get(key)
            if not isinstance(val, str):
                continue
            v = val.strip()
            if re.match(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$", v):
                sunset_date = f"{v}T00:00:00Z"
                break
        if sunset_date is None:
            for k, v in labels.items():
                if not isinstance(k, str) or not isinstance(v, str):
                    continue
                if not re.search(r"eol|sunset", k, re.IGNORECASE):
                    continue
                vv = v.strip()
                if re.match(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$", vv):
                    sunset_date = f"{vv}T00:00:00Z"
                    break

    if created_dt is None and not _is_digest(tag) and (arches or oses):
        ok, created_arch = inspect_tag_for_arches(repo, tag, arches or [], oses or [])
        if ok and created_arch is not None:
            created_dt = created_arch.replace(microsecond=0)
            release_date = created_dt.strftime("%Y-%m-%dT%H:%M:%SZ")

    if sunset_date is None and created_dt is not None:
        try:
            eol_dt = created_dt + timedelta(days=730)
            eol_dt = eol_dt.replace(hour=0, minute=0, second=0, microsecond=0)
            sunset_date = eol_dt.strftime("%Y-%m-%dT00:00:00Z")
        except Exception:
            sunset_date = None

    return release_date, sunset_date


def discover_for_entry(entry: Dict) -> Dict:
    """Discover the best tag for a single config entry lacking ``tag``."""
    provider = entry.get("provider", "")
    software = entry.get("software") or ""
    architectures = get_architectures_from_entry(entry)
    oses = get_oses_from_entry(entry)
    allowed_arches = {_normalise_arch_name(a) for a in architectures}

    repo = build_repo_from_entry(entry)
    if not repo:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": None,
            "reason": "missing repo parts (base_registry/source_path/software)",
        }

    print(
        f"[INFO] Discovering tags for {repo} (provider={provider}, software={software})",
        file=sys.stderr,
    )
    tags = run_skopeo_list_tags(repo)
    if not tags:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": None,
            "reason": "no tags returned by skopeo list-tags",
        }

    cutoff = parse_min_date(entry.get("min_date"))

    plain_major_tags: List[str] = []
    ga_numeric_tags: List[str] = []

    for t in tags:
        tag_arches = set(_infer_arches_from_tag(t))
        if architectures and tag_arches and not tag_arches.issubset(allowed_arches):
            continue
        if EXCLUDE_PATTERN.search(t):
            continue
        if t.lower() == "latest":
            continue
        if re.match(r"^[0-9]+$", t):
            plain_major_tags.append(t)
            ga_numeric_tags.append(t)
            continue
        if re.match(r"^[0-9]+(\.[0-9]+){0,2}$", t):
            ga_numeric_tags.append(t)

    def select_best_from_tags(candidates: List[str], scope: str) -> Tuple[Optional[str], Optional[str]]:
        if not candidates:
            return None, None

        cores: Dict[str, List[str]] = {}
        for tag in candidates:
            m = re.match(r"^([0-9]+(\.[0-9]+){0,2})", tag)
            if not m:
                continue
            core = m.group(1)
            cores.setdefault(core, []).append(tag)

        if not cores:
            return None, f"numeric {scope} tags found but could not derive core versions"

        def core_key(core: str) -> tuple:
            parts = [int(p) for p in core.split(".")]
            while len(parts) < 3:
                parts.append(0)
            return tuple(parts)

        def pick_tag(ignore_min_date: bool) -> Optional[str]:
            for core in sorted(cores.keys(), key=core_key, reverse=True):
                candidates_sorted = sorted(cores[core])
                for tag in reversed(candidates_sorted):
                    ok, created = inspect_tag_for_arches(repo, tag, architectures, oses)
                    if not ok:
                        continue
                    if not ignore_min_date and cutoff and created and created < cutoff:
                        continue
                    return tag
            return None

        best_tag = pick_tag(ignore_min_date=False)
        if best_tag is not None:
            return best_tag, f"ok ({scope})"

        if cutoff is not None:
            best_tag = pick_tag(ignore_min_date=True)
            if best_tag is not None:
                return best_tag, f"ok ({scope}; min_date ignored; no tag satisfied cutoff)"

        return None, None

    best, reason = select_best_from_tags(plain_major_tags, "plain major tag preference")
    if best is not None:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": best,
            "reason": reason or "ok (plain major tag preference)",
        }

    best, reason = select_best_from_tags(ga_numeric_tags, "GA numeric tag fallback")
    if best is not None:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": best,
            "reason": reason or "ok (GA numeric tag fallback)",
        }

    return {
        "provider": provider,
        "software": software,
        "repo": repo,
        "best_tag": None,
        "reason": "no plain major or GA numeric tags available that satisfy architecture/min_date constraints",
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Discover tags and metadata for IBM Cloud Container Registry (cp.icr.io) config entries"
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to ibm-catalog-container-config.json",
    )
    args = parser.parse_args()

    if not _get_creds("cp.icr.io"):
        print(
            "[WARN] Neither IBM_API_KEY nor IBM_API_KEY is set; skopeo calls to cp.icr.io will be unauthenticated and will fail for entitled images.",
            file=sys.stderr,
        )

    try:
        with open(args.config, "r", encoding="utf-8") as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"ERROR: Config file not found: {args.config}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as exc:
        print(f"ERROR: Failed to parse JSON from {args.config}: {exc}", file=sys.stderr)
        return 1

    if not isinstance(config, list):
        print("ERROR: Config JSON is not a list of entries", file=sys.stderr)
        return 1

    # Each entry is independent and dominated by network-bound `skopeo` calls, so we
    # process them concurrently with a bounded thread pool (GIL is released during
    # subprocess I/O). Results are collected and re-sorted by `index`, so the output is
    # byte-identical to the sequential version — only the wall-clock time changes.
    # Concurrency is tunable via DISCOVERY_CONCURRENCY (default 16); kept bounded to avoid
    # tripping cp.icr.io rate limits.
    def process_entry(idx: int, entry: Dict) -> Dict:
        provider = entry.get("provider", "")
        software = entry.get("software") or ""
        architectures = get_architectures_from_entry(entry)
        oses = get_oses_from_entry(entry)
        repo = build_repo_from_entry(entry)

        if not repo:
            return {
                "index": idx,
                "provider": provider,
                "software": software,
                "repo": repo,
                "best_tag": None,
                "tag": None,
                "digest": None,
                "release_date": None,
                "sunset_date": None,
                "reason": "missing repo parts (base_registry/source_path/software)",
            }

        raw_tag = entry.get("tag")
        explicit_tag: Optional[str] = None
        if isinstance(raw_tag, str) and raw_tag.strip():
            explicit_tag = raw_tag.strip()

        best_tag: Optional[str] = None
        reason: str = ""
        discovered = False

        if explicit_tag is not None:
            if explicit_tag.lower() == "latest":
                best_tag = None
                reason = "rejected: 'latest' tag is not allowed; pin a specific version"
                print(
                    f"[ERROR] {software}: explicit tag 'latest' is not allowed",
                    file=sys.stderr,
                )
            elif EXCLUDE_PATTERN.search(explicit_tag):
                best_tag = None
                reason = f"rejected: explicit tag '{explicit_tag}' matches pre-release/non-stable pattern"
                print(
                    f"[ERROR] {software}: explicit tag '{explicit_tag}' matches pre-release pattern and is not allowed",
                    file=sys.stderr,
                )
            elif not _is_digest(explicit_tag) and not re.match(
                r"^[0-9]+(\.[0-9]+){0,3}$", explicit_tag
            ):
                best_tag = None
                reason = f"rejected: explicit tag '{explicit_tag}' is not a numeric/semver version or sha256 digest"
                print(
                    f"[ERROR] {software}: explicit tag '{explicit_tag}' is not a pinned numeric version or digest — only versions like '11.5.9.0' or 'sha256:...' are allowed",
                    file=sys.stderr,
                )
            else:
                best_tag = explicit_tag
                reason = "explicit tag from config"
        else:
            res = discover_for_entry(entry)
            best_tag = res.get("best_tag")
            reason = res.get("reason", "")
            discovered = best_tag is not None

        digest: Optional[str] = None
        release_date: Optional[str] = None
        sunset_date: Optional[str] = None
        if best_tag is not None:
            rd, sd = inspect_metadata(repo, best_tag, architectures, oses)
            release_date, sunset_date = rd, sd

        return {
            "index": idx,
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": best_tag if discovered else None,
            "tag": best_tag,
            "digest": digest,
            "release_date": release_date,
            "sunset_date": sunset_date,
            "reason": reason,
        }

    try:
        max_workers = int(os.environ.get("DISCOVERY_CONCURRENCY", "16").strip())
    except ValueError:
        max_workers = 16
    max_workers = max(1, min(max_workers, len(config) or 1))
    print(
        f"[INFO] Discovering {len(config)} entries with up to {max_workers} parallel worker(s)",
        file=sys.stderr,
    )

    results: List[Dict] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(process_entry, idx, entry)
            for idx, entry in enumerate(config)
        ]
        for fut in concurrent.futures.as_completed(futures):
            results.append(fut.result())

    # Restore input order so the emitted JSON is identical to the sequential run.
    results.sort(key=lambda r: r.get("index", 0))

    print(json.dumps(results, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())