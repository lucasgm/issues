
import json
import sys
from datetime import datetime

# Usage: python add_security_to_vendor_json.py <vendor_json> <scan_report_json> <version> <rpm_path> <json_url> <html_url>

def main():
    if len(sys.argv) != 7:
        print("Usage: python add_security_to_vendor_json.py <vendor_json> <scan_report_json> <version> <rpm_path> <json_url> <html_url>")
        sys.exit(1)

    vendor_json = sys.argv[1]
    scan_report_json = sys.argv[2]
    version = sys.argv[3]
    rpm_path = sys.argv[4]
    json_url = sys.argv[5]
    html_url = sys.argv[6]

    with open(vendor_json) as f:
        vendor_data = json.load(f)
    with open(scan_report_json) as f:
        scan_data = json.load(f)

    summary = scan_data.get("vulnerability_summary", {})
    # Fill in missing fields with 0/defaults
    for k in ["critical", "high", "medium", "low", "negligible", "unknown", "total", "highest_severity"]:
        summary.setdefault(k, 0 if k != "highest_severity" else "unknown")

    security_block = {
        "scanned_at": datetime.utcnow().isoformat() + "Z",
        "tool": "AquaSec scannercli",
        "tool_version": scan_data.get("tool_version", "2022.4.517"),
        "target": {
            "type": "rpm",
            "repository": "base-rpm-thirdparty",
            "path": rpm_path
        },
        "status": "passed",
        "policy_gate": "pass",
        "summary": summary,
        "reports": {
            "json_url": json_url,
            "html_url": html_url
        },
        "exceptions": []
    }

    updated = False
    for release in vendor_data.get('releases', []):
        if release.get('version') == version:
            release['security'] = security_block
            updated = True
            break
    if not updated:
        print(f"Version {version} not found in vendor JSON.")
        sys.exit(2)

    with open(vendor_json, 'w') as f:
        json.dump(vendor_data, f, indent=2)
    print(f"Security block added to version {version} in {vendor_json}.")

if __name__ == "__main__":
    main()
