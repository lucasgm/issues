#!/usr/bin/env python3
"""Discover tags and lifecycle metadata for NetBox Labs images.

Reads the NetBox Labs catalog config and, for entries without an explicit
tag, selects a stable semver tag using skopeo, then emits JSON on stdout
with the effective tag and derived release/sunset dates.
"""

import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple


EXCLUDE_PATTERN = re.compile(r"(beta|alpha|rc|dev|snapshot|test|nightly|preview|tech-preview)", re.IGNORECASE)


def run_skopeo_list_tags(repo: str) -> List[str]:
    """Return tags for docker://repo using skopeo, or an empty list on error."""
    try:
        proc = subprocess.run(
            ["skopeo", "list-tags", f"docker://{repo}"],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        print(f"ERROR: skopeo not found on PATH; cannot discover tags for {repo}", file=sys.stderr)
        return []

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(f"[WARN] skopeo list-tags failed for {repo} (rc={proc.returncode}): {msg[:200]}", file=sys.stderr)
        return []

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        print(f"[WARN] Failed to parse skopeo output for {repo}: {exc}", file=sys.stderr)
        return []

    tags = data.get("Tags") or []
    return [t for t in tags if isinstance(t, str)]

def parse_min_date(value: Optional[str]) -> Optional[datetime]:
    """Parse a ``min_date`` string (e.g. ``"6 months"``) into a UTC cutoff."""
    if not value:
        return None

    m = re.match(r"^\s*(\d+)\s*(day|days|week|weeks|month|months)\s*$", value, re.IGNORECASE)
    if not m:
        print(f"[WARN] Unsupported min_date format '{value}'; ignoring.", file=sys.stderr)
        return None

    amount = int(m.group(1))
    unit = m.group(2).lower()
    if "day" in unit:
        delta = timedelta(days=amount)
    elif "week" in unit:
        delta = timedelta(weeks=amount)
    else:
        # months -> approximate as 30 days each
        delta = timedelta(days=30 * amount)

    return datetime.now(timezone.utc) - delta


def inspect_tag_for_arches(repo: str, tag: str, arches: List[str]) -> Tuple[bool, Optional[datetime]]:
    """Return (ok, created_at_utc) for repo:tag, enforcing required arches."""
    created_best: Optional[datetime] = None

    def parse_created(created_raw: Optional[str]) -> Optional[datetime]:
        if not created_raw:
            return None
        val = created_raw.replace("Z", "+00:00")
        try:
            dt = datetime.fromisoformat(val)
        except ValueError:
            return None
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        else:
            dt = dt.astimezone(timezone.utc)
        return dt

    if arches:
        for arch in arches:
            try:
                proc = subprocess.run(
                    [
                        "skopeo",
                        "inspect",
                        f"--override-arch={arch}",
                        f"docker://{repo}:{tag}",
                    ],
                    check=False,
                    capture_output=True,
                    text=True,
                )
            except FileNotFoundError:
                print("ERROR: skopeo not found on PATH; cannot inspect images", file=sys.stderr)
                return False, None

            if proc.returncode != 0:
                msg = proc.stderr.strip() or proc.stdout.strip()
                print(
                    f"[WARN] skopeo inspect failed for {repo}:{tag} arch={arch} (rc={proc.returncode}): {msg[:200]}",
                    file=sys.stderr,
                )
                return False, None

            try:
                data = json.loads(proc.stdout or "{}")
            except json.JSONDecodeError:
                print(f"[WARN] Failed to parse inspect output for {repo}:{tag} arch={arch}", file=sys.stderr)
                return False, None

            created = parse_created(data.get("Created") or data.get("created"))
            if created and (created_best is None or created > created_best):
                created_best = created
        return True, created_best

    # No specific arch requested; inspect once without override
    try:
        proc = subprocess.run(
            ["skopeo", "inspect", f"docker://{repo}:{tag}"],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        print("ERROR: skopeo not found on PATH; cannot inspect images", file=sys.stderr)
        return False, None

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(
            f"[WARN] skopeo inspect failed for {repo}:{tag} (rc={proc.returncode}): {msg[:200]}",
            file=sys.stderr,
        )
        return False, None

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError:
        print(f"[WARN] Failed to parse inspect output for {repo}:{tag}", file=sys.stderr)
        return False, None

    created = parse_created(data.get("Created") or data.get("created"))
    return True, created


def build_repo_from_entry(entry: Dict) -> str:
    """Return base_registry/source_path/software for a config entry."""
    base_registry = (entry.get("base_registry") or "").rstrip("/")
    source_path = (entry.get("source_path") or "").lstrip("/")
    software = entry.get("software") or ""
    repo = "/".join(part for part in [base_registry, source_path, software] if part)
    return repo


def inspect_metadata(repo: str, tag: str) -> Tuple[Optional[str], Optional[str]]:
    """Return (release_date_iso, sunset_date_iso) from ``skopeo inspect``."""

    try:
        proc = subprocess.run(
            ["skopeo", "inspect", f"docker://{repo}:{tag}"],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        print("ERROR: skopeo not found on PATH; cannot inspect images for metadata", file=sys.stderr)
        return None, None

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(
            f"[WARN] skopeo inspect for metadata failed for {repo}:{tag} (rc={proc.returncode}): {msg[:200]}",
            file=sys.stderr,
        )
        return None, None

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        print(f"[WARN] Failed to parse inspect metadata output for {repo}:{tag}: {exc}", file=sys.stderr)
        return None, None

    created_raw = data.get("Created") or data.get("created")
    release_date: Optional[str] = None
    created_dt: Optional[datetime] = None
    if created_raw:
        val = created_raw.replace("Z", "+00:00")
        try:
            created_dt = datetime.fromisoformat(val)
            if created_dt.tzinfo is None:
                created_dt = created_dt.replace(tzinfo=timezone.utc)
            else:
                created_dt = created_dt.astimezone(timezone.utc)
            created_dt = created_dt.replace(microsecond=0)
            release_date = created_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            created_dt = None

    labels = data.get("Labels") or data.get("labels") or {}
    sunset_date: Optional[str] = None
    if isinstance(labels, dict):
        # First, honor well-known explicit EOL labels if they look like dates.
        for key in ("vendor.eol", "maintainer.eol", "org.opencontainers.image.endoflife"):
            val = labels.get(key)
            if not isinstance(val, str):
                continue
            v = val.strip()
            if re.match(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$", v):
                sunset_date = f"{v}T00:00:00Z"
                break

        # Fallback: search any label whose key mentions eol/sunset.
        if sunset_date is None:
            for k, v in labels.items():
                if not isinstance(k, str) or not isinstance(v, str):
                    continue
                if not re.search(r"eol|sunset", k, re.IGNORECASE):
                    continue
                vv = v.strip()
                if re.match(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$", vv):
                    sunset_date = f"{vv}T00:00:00Z"
                    break

    # If still not set, but we have a release_date, default EOL to +730 days.
    if sunset_date is None and created_dt is not None:
        try:
            eol_dt = created_dt + timedelta(days=730)
            eol_dt = eol_dt.replace(hour=0, minute=0, second=0, microsecond=0)
            sunset_date = eol_dt.strftime("%Y-%m-%dT00:00:00Z")
        except Exception:
            sunset_date = None

    return release_date, sunset_date


def discover_for_entry(entry: Dict) -> Dict:
    """Discover the best tag for a single config entry lacking ``tag``."""

    provider = entry.get("provider", "")
    software = entry.get("software") or ""
    architectures: List[str] = []
    container = entry.get("container") or {}
    arch_val = container.get("architecture")
    if isinstance(arch_val, list):
        architectures = [str(a) for a in arch_val if isinstance(a, str) and a]

    repo = build_repo_from_entry(entry)
    if not repo:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": None,
            "reason": "missing repo parts (base_registry/source_path/software)",
        }

    print(f"[INFO] Discovering tags for {repo} (provider={provider}, software={software})", file=sys.stderr)
    tags = run_skopeo_list_tags(repo)
    if not tags:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": None,
            "reason": "no tags returned by skopeo list-tags",
        }

    cutoff = parse_min_date(entry.get("min_date"))

    numeric_tags: List[str] = []
    for t in tags:
        if EXCLUDE_PATTERN.search(t):
            continue
        if not re.match(r"^[0-9]+(\.[0-9]+){0,2}([^ ]*)?$", t):
            continue
        numeric_tags.append(t)

    if not numeric_tags:
        if "latest" in tags:
            ok, created = inspect_tag_for_arches(repo, "latest", architectures)
            if not ok:
                return {
                    "provider": provider,
                    "software": software,
                    "repo": repo,
                    "best_tag": None,
                    "reason": "'latest' exists but does not satisfy architecture constraints",
                }
            return {
                "provider": provider,
                "software": software,
                "repo": repo,
                "best_tag": "latest",
                "reason": "ok (fallback to latest; no numeric tags; min_date ignored)",
            }
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": None,
            "reason": "no numeric GA tags available",
        }

    cores: Dict[str, List[str]] = {}
    for t in numeric_tags:
        m = re.match(r"^([0-9]+(\.[0-9]+){0,2})", t)
        if not m:
            continue
        core = m.group(1)
        cores.setdefault(core, []).append(t)

    if not cores:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": None,
            "reason": "numeric tags found but could not derive core versions",
        }

    def core_key(core: str) -> tuple:
        parts = [int(p) for p in core.split(".")]
        while len(parts) < 3:
            parts.append(0)
        return tuple(parts)

    def pick_tag(ignore_min_date: bool) -> Optional[str]:
        for core in sorted(cores.keys(), key=core_key, reverse=True):
            candidates = sorted(cores[core])
            for t in reversed(candidates):  # prefer lexicographically last
                ok, created = inspect_tag_for_arches(repo, t, architectures)
                if not ok:
                    continue
                if not ignore_min_date and cutoff and created and created < cutoff:
                    # Tag is older than allowed window
                    continue
                # Either no cutoff, or created is newer than cutoff, or
                # created timestamp is unavailable (in which case we assume
                # acceptable).
                return t
        return None

    best = pick_tag(ignore_min_date=False)
    if best is not None:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": best,
            "reason": "ok",
        }

    if cutoff is not None:
        best = pick_tag(ignore_min_date=True)
        if best is not None:
            return {
                "provider": provider,
                "software": software,
                "repo": repo,
                "best_tag": best,
                "reason": "ok (min_date ignored; no tag satisfied cutoff)",
            }

    return {
        "provider": provider,
        "software": software,
        "repo": repo,
        "best_tag": None,
        "reason": "no tag satisfied architecture constraints (even without min_date)",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Discover tags and metadata for NetBox Labs config entries")
    parser.add_argument(
        "--config",
        required=True,
        help="Path to netboxlabs-catalog-container-config.json",
    )
    args = parser.parse_args()

    try:
        with open(args.config, "r", encoding="utf-8") as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"ERROR: Config file not found: {args.config}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as exc:
        print(f"ERROR: Failed to parse JSON from {args.config}: {exc}", file=sys.stderr)
        return 1

    if not isinstance(config, list):
        print("ERROR: Config JSON is not a list of entries", file=sys.stderr)
        return 1

    results: List[Dict] = []
    for idx, entry in enumerate(config):
        provider = entry.get("provider", "")
        software = entry.get("software") or ""
        repo = build_repo_from_entry(entry)

        if not repo:
            results.append(
                {
                    "index": idx,
                    "provider": provider,
                    "software": software,
                    "repo": repo,
                    "best_tag": None,
                    "tag": None,
                    "digest": None,
                    "release_date": None,
                    "sunset_date": None,
                    "reason": "missing repo parts (base_registry/source_path/software)",
                }
            )
            continue

        # Determine the effective tag: use explicit config tag when present,
        # otherwise discover a best tag using the existing selection logic.
        raw_tag = entry.get("tag")
        explicit_tag: Optional[str] = None
        if isinstance(raw_tag, str) and raw_tag.strip():
            explicit_tag = raw_tag.strip()

        best_tag: Optional[str] = None
        reason: str = ""
        discovered = False

        if explicit_tag is not None:
            best_tag = explicit_tag
            reason = "explicit tag from config"
        else:
            res = discover_for_entry(entry)
            best_tag = res.get("best_tag")
            reason = res.get("reason", "")
            discovered = best_tag is not None

        digest: Optional[str] = None
        release_date: Optional[str] = None
        sunset_date: Optional[str] = None
        if best_tag is not None:
            rd, sd = inspect_metadata(repo, best_tag)
            release_date, sunset_date = rd, sd

        results.append(
            {
                "index": idx,
                "provider": provider,
                "software": software,
                "repo": repo,
                # Preserve best_tag semantics for backward-compat with the
                # workflow merge step while also surfacing the effective tag
                # (explicit or discovered) via "tag".
                "best_tag": best_tag if discovered else None,
                "tag": best_tag,
                "digest": digest,
                "release_date": release_date,
                "sunset_date": sunset_date,
                "reason": reason,
            }
        )

    print(json.dumps(results, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
