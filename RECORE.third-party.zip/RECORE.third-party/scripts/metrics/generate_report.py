#!/usr/bin/env python3
"""
Generate a management-readable REPORT.md from the NDJSON metrics files
produced by extract_from_catalog_commits.py.

Also writes (or overwrites) metrics/README.md explaining the data files.

Usage:
    python generate_report.py --metrics-dir /path/to/metrics/events

The script reads:
    additions.ndjson
    scans.ndjson

And writes:
    REPORT.md  — one directory above metrics-dir  (i.e. metrics/REPORT.md)
    README.md  — same location
"""

import json
import argparse
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_ndjson(path: Path) -> list[dict]:
    if not path.exists():
        return []
    records = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return records


def pct(num: int, total: int) -> str:
    if total == 0:
        return "—"
    return f"{num / total * 100:.1f}%"


def month_label(ts: str) -> str:
    """'2024-03-15T…' → '2024-03'"""
    return ts[:7] if ts else "unknown"


def week_label(ts: str) -> str:
    """'2024-03-15T…' → '2024-W11'"""
    if not ts:
        return "unknown"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        iso = dt.isocalendar()
        return f"{iso[0]}-W{iso[1]:02d}"
    except ValueError:
        return ts[:10]


def render_table(headers: list[str], rows: list[list]) -> str:
    col_widths = [len(h) for h in headers]
    for row in rows:
        for i, cell in enumerate(row):
            col_widths[i] = max(col_widths[i], len(str(cell)))

    def fmt_row(cells):
        return "| " + " | ".join(str(c).ljust(col_widths[i]) for i, c in enumerate(cells)) + " |"

    sep = "| " + " | ".join("-" * w for w in col_widths) + " |"
    lines = [fmt_row(headers), sep]
    for row in rows:
        lines.append(fmt_row(row))
    return "\n".join(lines)


# ── Report sections ───────────────────────────────────────────────────────────

def section_executive_summary(additions: list[dict], scans: list[dict],
                               now: datetime) -> str:
    total_sw   = sum(1 for e in additions if e.get("action") == "software_added")
    total_rel  = sum(1 for e in additions if e.get("action") == "release_added")
    total_scan = len(scans)

    cutoff_30  = (now - timedelta(days=30)).isoformat()
    recent_adds = [e for e in additions if (e.get("timestamp") or "") >= cutoff_30]

    scan_pass  = sum(1 for e in scans if "pass" in str(e.get("security", {}).get("policy_gate", "")).lower())
    scan_fail  = sum(1 for e in scans if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower())

    # Last-week highlight
    this_week   = week_label(now.isoformat())
    lw_adds     = sum(1 for e in additions if week_label(e.get("timestamp") or "") == this_week)
    lw_vuln     = sum(1 for e in additions
                      if week_label(e.get("timestamp") or "") == this_week
                      and "fail" in str(e.get("security", {}).get("policy_gate", "")).lower())
    lw_scan_fail = sum(1 for e in scans
                       if week_label(e.get("timestamp") or "") == this_week
                       and "fail" in str(e.get("security", {}).get("policy_gate", "")).lower())

    lines = [
        "## Executive Summary",
        "",
        f"| Metric | Count |",
        f"|--------|-------|",
        f"| Total software packages approved | {total_sw + total_rel:,} |",
        f"| Distinct software names added | {total_sw:,} |",
        f"| New releases (additional tags/versions) | {total_rel:,} |",
        f"| Security scan events recorded | {total_scan:,} |",
        f"| Additions in last 30 days | {len(recent_adds):,} |",
        f"| Scan results — PASS | {scan_pass:,} ({pct(scan_pass, total_scan)}) |",
        f"| Scan results — FAIL | {scan_fail:,} ({pct(scan_fail, total_scan)}) |",
        f"| **This week ({this_week}) — images pulled** | **{lw_adds:,}** |",
        f"| **This week ({this_week}) — vulnerable at ingestion** | **{lw_vuln:,}** |",
        f"| **This week ({this_week}) — scan re-checks failed** | **{lw_scan_fail:,}** |",
        "",
        f"_Report generated: {now.strftime('%Y-%m-%d %H:%M UTC')}_",
    ]
    return "\n".join(lines)


def section_inventory_by_vendor(additions: list[dict]) -> str:
    by_vendor: dict[str, dict] = defaultdict(lambda: {"software": set(), "releases": 0, "images": 0, "helm": 0, "packages": 0})

    for e in additions:
        v = e.get("vendor", "unknown")
        t = e.get("type", "")
        by_vendor[v]["software"].add(e.get("software", ""))
        by_vendor[v]["releases"] += 1
        if t == "image":
            by_vendor[v]["images"] += 1
        elif t == "helm":
            by_vendor[v]["helm"] += 1
        elif t == "package":
            by_vendor[v]["packages"] += 1

    rows = []
    for v in sorted(by_vendor, key=lambda x: -by_vendor[x]["releases"]):
        d = by_vendor[v]
        rows.append([v, len(d["software"]), d["releases"], d["images"], d["helm"], d["packages"]])

    headers = ["Vendor", "Distinct Software", "Total Entries", "Container Images", "Helm Charts", "Packages"]
    return "## Inventory by Vendor\n\n" + render_table(headers, rows)


def section_security_posture(scans: list[dict]) -> str:
    by_vendor: dict[str, dict] = defaultdict(lambda: {"pass": 0, "fail": 0, "unknown": 0,
                                                        "critical": 0, "high": 0})
    for e in scans:
        v    = e.get("vendor", "unknown")
        gate = str(e.get("security", {}).get("policy_gate", "")).lower()
        sec  = e.get("security", {})
        if "pass" in gate:
            by_vendor[v]["pass"] += 1
        elif "fail" in gate:
            by_vendor[v]["fail"] += 1
            by_vendor[v]["critical"] += sec.get("critical", 0)
            by_vendor[v]["high"]     += sec.get("high", 0)
        else:
            by_vendor[v]["unknown"] += 1

    rows = []
    for v in sorted(by_vendor, key=lambda x: -(by_vendor[x]["pass"] + by_vendor[x]["fail"])):
        d = by_vendor[v]
        total = d["pass"] + d["fail"] + d["unknown"]
        rows.append([v, d["pass"], d["fail"], d["unknown"], d["critical"], d["high"], pct(d["pass"], total)])

    headers = ["Vendor", "Pass", "Fail", "Unknown", "Critical CVEs (fail)", "High CVEs (fail)", "Pass Rate"]
    return "## Security Posture by Vendor\n\n" + render_table(headers, rows)


def section_recent_additions(additions: list[dict], now: datetime, days: int = 30) -> str:
    cutoff = (now - timedelta(days=days)).isoformat()
    recent = [e for e in additions if (e.get("timestamp") or "") >= cutoff]
    recent.sort(key=lambda x: x.get("timestamp") or "", reverse=True)

    if not recent:
        return f"## Recent Additions (Last {days} Days)\n\n_No new additions in this period._"

    rows = []
    for e in recent[:50]:  # cap at 50 rows
        ts   = (e.get("timestamp") or "")[:10]
        rows.append([ts, e.get("vendor", ""), e.get("software", ""), e.get("tag", ""), e.get("type", ""), e.get("action", "")])

    headers = ["Date", "Vendor", "Software", "Tag / Version", "Type", "Action"]
    note = f"\n\n_Showing up to 50 of {len(recent)} additions._" if len(recent) > 50 else ""
    return f"## Recent Additions (Last {days} Days)\n\n" + render_table(headers, rows) + note


def section_policy_failures(scans: list[dict]) -> str:
    failures = [e for e in scans
                if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower()]
    if not failures:
        return "## Current Policy Failures\n\n_No policy failures recorded._"

    # Keep only the most recent scan event per (vendor, software, tag)
    latest: dict[tuple, dict] = {}
    for e in failures:
        key = (e.get("vendor", ""), e.get("software", ""), e.get("tag", ""))
        if key not in latest or (e.get("timestamp") or "") > (latest[key].get("timestamp") or ""):
            latest[key] = e

    rows = []
    for e in sorted(latest.values(), key=lambda x: -(x.get("security", {}).get("critical", 0))):
        sec = e.get("security", {})
        rows.append([
            e.get("vendor", ""), e.get("software", ""), e.get("tag", ""),
            sec.get("critical", 0), sec.get("high", 0),
            sec.get("medium", 0),  str(e.get("security", {}).get("policy_gate", "")),
        ])

    headers = ["Vendor", "Software", "Tag", "Critical", "High", "Medium", "Gate Status"]
    return (f"## Current Policy Failures\n\n"
            f"_Items with the most recent scan result showing a policy gate failure._\n\n"
            + render_table(headers, rows[:100]))


def section_weekly_trend(additions: list[dict], scans: list[dict], weeks: int = 12) -> str:
    """
    Table showing per-week:
      - Images Added     : new entries in additions.ndjson
      - Vulnerable Added : new entries whose policy_gate was already 'fail' at ingestion
      - Scan Fails       : existing images flagged as failing on a re-scan
      - Scan Passes      : existing images cleared on a re-scan
      - Fail Rate        : scan_fails / (scan_fails + scan_passes) for the week
    """
    by_week_adds:       dict[str, int] = defaultdict(int)
    by_week_vuln_added: dict[str, int] = defaultdict(int)
    by_week_scan_fail:  dict[str, int] = defaultdict(int)
    by_week_scan_pass:  dict[str, int] = defaultdict(int)

    for e in additions:
        w = week_label(e.get("timestamp") or "")
        by_week_adds[w] += 1
        if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower():
            by_week_vuln_added[w] += 1

    for e in scans:
        w    = week_label(e.get("timestamp") or "")
        gate = str(e.get("security", {}).get("policy_gate", "")).lower()
        if "fail" in gate:
            by_week_scan_fail[w] += 1
        elif "pass" in gate:
            by_week_scan_pass[w] += 1

    all_weeks = sorted(
        set(by_week_adds) | set(by_week_scan_fail) | set(by_week_scan_pass)
        - {"unknown"}
    )
    if not all_weeks:
        return f"## Weekly Activity (Last {weeks} Weeks)\n\n_No data._"

    recent = all_weeks[-weeks:]
    rows = []
    for w in recent:
        adds       = by_week_adds.get(w, 0)
        vuln_added = by_week_vuln_added.get(w, 0)
        sf         = by_week_scan_fail.get(w, 0)
        sp         = by_week_scan_pass.get(w, 0)
        total_sc   = sf + sp
        rows.append([w, adds, vuln_added, sf, sp, pct(sf, total_sc)])

    headers = ["Week", "Images Added", "Vulnerable at Add", "Scan Fails", "Scan Passes", "Rescan Fail Rate"]
    note = (
        "\n\n_Showing last "
        + str(weeks)
        + " weeks. "
        "'Images Added' = new catalog entries that week. "
        "'Vulnerable at Add' = new entries where AquaSec gate was already **fail** at ingestion. "
        "'Scan Fails/Passes' = re-scan events on existing entries._"
    )
    return f"## Weekly Activity (Last {weeks} Weeks)\n\n" + render_table(headers, rows) + note


def section_weekly_image_detail(additions: list[dict], scans: list[dict],
                                weeks: int = 4) -> str:
    """
    Per-week collapsible detail blocks showing every image added and every
    vulnerable image (new additions + re-scan failures) for the last N weeks.
    """
    # Group by week
    adds_by_week:  dict[str, list[dict]] = defaultdict(list)
    scans_by_week: dict[str, list[dict]] = defaultdict(list)

    for e in additions:
        w = week_label(e.get("timestamp") or "")
        if w != "unknown":
            adds_by_week[w].append(e)

    for e in scans:
        w    = week_label(e.get("timestamp") or "")
        gate = str(e.get("security", {}).get("policy_gate", "")).lower()
        if w != "unknown" and "fail" in gate:
            scans_by_week[w].append(e)

    all_weeks = sorted(set(adds_by_week) | set(scans_by_week))
    if not all_weeks:
        return f"## Weekly Image Detail (Last {weeks} Weeks)\n\n_No data._"

    recent = all_weeks[-weeks:]
    parts  = [f"## Weekly Image Detail (Last {weeks} Weeks)\n"]

    for w in reversed(recent):  # most recent first
        week_adds  = sorted(adds_by_week.get(w, []),
                            key=lambda x: x.get("timestamp") or "")
        week_vulns = sorted(
            [e for e in week_adds
             if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower()],
            key=lambda x: -(x.get("security", {}).get("critical", 0))
        )
        rescan_fails = sorted(scans_by_week.get(w, []),
                              key=lambda x: -(x.get("security", {}).get("critical", 0)))

        total_vuln = len(week_vulns) + len(rescan_fails)
        summary_line = (
            f"{len(week_adds)} image(s) added"
            + (f", {total_vuln} vulnerable" if total_vuln else ", none vulnerable")
        )

        parts.append(f"<details>")
        parts.append(f"<summary><strong>{w}</strong> — {summary_line}</summary>")
        parts.append("")

        # ── Images added this week ──
        if week_adds:
            add_rows = []
            for e in week_adds:
                gate = str(e.get("security", {}).get("policy_gate", "")).lower()
                vuln_flag = "⚠️ yes" if "fail" in gate else "no"
                add_rows.append([
                    (e.get("timestamp") or "")[:10],
                    e.get("vendor", ""),
                    e.get("software", ""),
                    e.get("tag", ""),
                    e.get("type", ""),
                    vuln_flag,
                ])
            parts.append(f"**Images Added ({len(week_adds)})**\n")
            parts.append(render_table(
                ["Date", "Vendor", "Software", "Tag", "Type", "Vulnerable"],
                add_rows
            ))
        else:
            parts.append("_No new images added this week._")

        parts.append("")

        # ── Vulnerable images this week ──
        all_vuln_rows = []
        for e in week_vulns:
            sec = e.get("security", {})
            all_vuln_rows.append([
                (e.get("timestamp") or "")[:10],
                e.get("vendor", ""),
                e.get("software", ""),
                e.get("tag", ""),
                sec.get("critical", 0),
                sec.get("high", 0),
                sec.get("medium", 0),
                "new entry",
            ])
        for e in rescan_fails:
            sec = e.get("security", {})
            all_vuln_rows.append([
                (e.get("timestamp") or "")[:10],
                e.get("vendor", ""),
                e.get("software", ""),
                e.get("tag", ""),
                sec.get("critical", 0),
                sec.get("high", 0),
                sec.get("medium", 0),
                "re-scan",
            ])

        if all_vuln_rows:
            # Sort by critical desc
            all_vuln_rows.sort(key=lambda r: -int(r[4]))
            parts.append(f"**Vulnerable Images ({len(all_vuln_rows)})**\n")
            parts.append(render_table(
                ["Date", "Vendor", "Software", "Tag", "Critical", "High", "Medium", "Source"],
                all_vuln_rows
            ))
        else:
            parts.append("_No vulnerable images this week._")

        parts.append("")
        parts.append("</details>")
        parts.append("")

    return "\n".join(parts)


def section_monthly_trend(additions: list[dict]) -> str:
    by_month: dict[str, int] = defaultdict(int)
    for e in additions:
        m = month_label(e.get("timestamp") or "")
        by_month[m] += 1

    if not by_month:
        return "## Monthly Addition Trend\n\n_No data._"

    rows = [[m, by_month[m]] for m in sorted(by_month)]
    headers = ["Month", "Additions"]
    return "## Monthly Addition Trend\n\n" + render_table(headers, rows)


# ── README content ────────────────────────────────────────────────────────────

README_CONTENT = """\
# Catalog Metrics — Data Reference

This directory contains metrics derived purely from the git commit history of
the vendor catalog JSON files.  The data is regenerated automatically each day
by the `Catalog Metrics` GitHub Actions workflow in `icesdlc/RECORE.third-party`.

---

## Files

### `additions.ndjson`

One JSON record per line.  Each record represents a **new software package or
release tag** that appeared in the catalog for the first time.

| Field | Description |
|-------|-------------|
| `timestamp` | ISO-8601 datetime of the git commit that introduced this entry |
| `git_hash` | Full SHA of that commit |
| `git_subject` | Commit message subject line |
| `run_id` | GitHub Actions run ID extracted from the commit message (if present) |
| `action` | `software_added` — first time this software name appeared; `release_added` — existing software, new tag/version |
| `type` | `image`, `helm`, or `package` |
| `vendor` | Source registry / vendor (e.g. `dockerhub`, `redhat`, `helm`) |
| `software` | Software / chart name |
| `tag` | Container tag, chart version, or package version |
| `release_date` | Release date as recorded in the catalog |
| `scanned_date` | Date the AquaSec scan was performed |
| `sunset_date` | Scheduled support end date (if recorded) |
| `artif_ng` | Artifactory next-gen path where the artifact is mirrored |
| `security.policy_gate` | AquaSec policy gate result (`pass` / `fail`) |
| `security.critical` | Number of critical CVEs |
| `security.high` | Number of high CVEs |
| `security.medium` | Number of medium CVEs |
| `security.low` | Number of low CVEs |
| `security.negligible` | Number of negligible CVEs |
| `security.total` | Total CVE count |
| `security.score_average` | Average CVSS score |
| `security.report_url` | Link to the full AquaSec report |

### `scans.ndjson`

Same schema as `additions.ndjson`.  Each record represents a **security scan
result update** — the `scanned_date` or `policy_gate` changed for an existing
release between two consecutive commits.

Use this file to track:
- How the security posture of an artifact changed over time
- When a previously failing item was remediated (gate changed to `pass`)
- New vulnerabilities discovered on a re-scan

### `all-events.ndjson`

A single chronologically-sorted stream merging both `additions.ndjson` and
`scans.ndjson`.  Useful for replaying the full catalog history in order.

### `REPORT.md`

A management-friendly summary generated from the NDJSON files above.  Updated
automatically with each daily workflow run.

---

## How data is collected

The extraction script (`scripts/metrics/extract_from_catalog_commits.py` in
`icesdlc/RECORE.third-party`) walks the main-branch commit history of every
JSON file under `vendor-catalog/`.  For each commit it reconstructs the full
catalog snapshot at that point in time and compares it against the previous
commit.  No GitHub Issues API, no external data sources — everything comes
from the git object store.

## Refreshing manually

Trigger the `Catalog Metrics` workflow in the `icesdlc/RECORE.third-party`
repository via **Actions → Catalog Metrics → Run workflow**.
"""


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Generate management report from catalog metrics")
    ap.add_argument("--metrics-dir", required=True,
                    help="Directory containing additions.ndjson and scans.ndjson")
    ap.add_argument("--dry-run", action="store_true",
                    help="Print report to stdout instead of writing files")
    args = ap.parse_args()

    metrics_dir = Path(args.metrics_dir).resolve()
    output_dir  = metrics_dir.parent  # metrics/ — one level up from metrics/events/

    additions = load_ndjson(metrics_dir / "additions.ndjson")
    scans     = load_ndjson(metrics_dir / "scans.ndjson")

    print(f"Loaded {len(additions):,} additions and {len(scans):,} scan events.")

    now = datetime.now(timezone.utc)

    sections = [
        f"# Third-Party Catalog — Metrics Report",
        "",
        section_executive_summary(additions, scans, now),
        "",
        section_weekly_trend(additions, scans),
        "",
        section_weekly_image_detail(additions, scans),
        "",
        section_monthly_trend(additions),
        "",
        section_inventory_by_vendor(additions),
        "",
        section_security_posture(scans),
        "",
        section_recent_additions(additions, now),
        "",
        section_policy_failures(scans),
        "",
        "---",
        "_Data sourced from git commit history of `icesdlc/RECORE.third-party-catalog`. "
        "Regenerated daily by the Catalog Metrics workflow._",
    ]
    report = "\n".join(sections) + "\n"

    if args.dry_run:
        print("\n" + "=" * 72)
        print(report)
        return

    report_path = output_dir / "REPORT.md"
    readme_path = output_dir / "README.md"

    output_dir.mkdir(parents=True, exist_ok=True)

    report_path.write_text(report)
    print(f"Wrote report  → {report_path}")

    readme_path.write_text(README_CONTENT)
    print(f"Wrote README  → {readme_path}")


if __name__ == "__main__":
    main()
