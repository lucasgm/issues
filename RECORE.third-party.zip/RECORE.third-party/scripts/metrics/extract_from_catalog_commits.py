#!/usr/bin/env python3
"""
Extract metrics from RECORE.third-party-catalog git history.

Walks the commit history of every vendor catalog JSON file and emits one
NDJSON event for each new software entry or new release that appears in a
commit's diff. No GitHub API, no issue parsing — purely from git.

Events are written to:
  {output_dir}/additions.ndjson  — new software added per commit
  {output_dir}/scans.ndjson     — security scan result per release per commit
  {output_dir}/all-events.ndjson — combined stream sorted by timestamp

Run on demand or via a scheduled GHA workflow in the catalog repo.

Usage:
    python extract_from_catalog_commits.py \\
        --catalog-repo /path/to/RECORE.third-party-catalog \\
        --output-dir   /path/to/output

Requirements: git on PATH, Python 3.9+
"""

import json
import re
import subprocess
import argparse
from pathlib import Path
from typing import Optional


# ── Git helpers ───────────────────────────────────────────────────────────────

def run_git(args: list[str], cwd: Path) -> str:
    result = subprocess.run(
        ["git"] + args, cwd=cwd,
        capture_output=True, text=True, check=True
    )
    return result.stdout


def get_file_commits(repo: Path, rel_path: str) -> list[dict]:
    """
    Return all commits that touched rel_path, oldest first.
    Each dict: hash, author_email, timestamp, subject, parent_hash
    """
    raw = run_git(
        ["log", "HEAD", "--reverse",
         "--format=COMMIT|%H|%P|%ae|%aI|%s", "--", rel_path],
        repo
    )
    commits = []
    for line in raw.splitlines():
        if not line.startswith("COMMIT|"):
            continue
        parts = line.split("|", 5)
        _, h, parents, ae, ts, subj = parts
        commits.append({
            "hash":         h.strip(),
            "parent":       parents.strip().split()[0] if parents.strip() else "",
            "author_email": ae.strip(),
            "timestamp":    ts.strip(),
            "subject":      subj.strip(),
            "run_id":       _extract_run_id(subj),
        })
    return commits


def get_json_at(repo: Path, commit_hash: str, rel_path: str) -> Optional[dict]:
    result = subprocess.run(
        ["git", "show", f"{commit_hash}:{rel_path}"],
        cwd=repo, capture_output=True, text=True
    )
    if result.returncode != 0:
        return None
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return None


def _extract_run_id(subject: str) -> Optional[str]:
    m = re.search(r'run\s+(\d+)', subject, re.IGNORECASE)
    return m.group(1) if m else None


def is_bot(email: str) -> bool:
    return any(x in email for x in ("github-actions", "noreply", "recore-bot", "svc-"))


# ── Security helpers ──────────────────────────────────────────────────────────

SFIELDS = ("critical", "high", "medium", "low", "negligible", "unknown")


def normalise_security(sec: dict) -> dict:
    vuln = sec.get("vulnerability_summary", {})
    return {
        "policy_gate":  sec.get("policy_gate", ""),
        "critical":     vuln.get("critical", 0),
        "high":         vuln.get("high", 0),
        "medium":       vuln.get("medium", 0),
        "low":          vuln.get("low", 0),
        "negligible":   vuln.get("negligible", 0),
        "total":        vuln.get("total", 0),
        "score_average": vuln.get("score_average"),
        "report_url":   sec.get("security_report"),
    }


# ── Event builder ─────────────────────────────────────────────────────────────

def make_event(commit: dict, etype: str, vendor: str, software: str,
               tag: str, release: dict, action: str) -> dict:
    sec = normalise_security(release.get("security", {}))
    return {
        "timestamp":      commit["timestamp"],
        "git_hash":       commit["hash"],
        "git_subject":    commit["subject"],
        "run_id":         commit["run_id"],
        "action":         action,          # "software_added" | "release_added" | "scan_updated"
        "type":           etype,           # "image" | "helm" | "package"
        "vendor":         vendor,
        "software":       software,
        "tag":            tag,
        "release_date":   release.get("release_date"),
        "scanned_date":   release.get("scanned_date"),
        "sunset_date":    release.get("sunset_date"),
        "artif_ng":       release.get("artif_ng", ""),
        "security":       sec,
    }


# ── Container file diff (dockerhub.json, redhat.json, etc.) ──────────────────

def diff_container(before: Optional[dict], after: dict,
                   commit: dict, vendor: str) -> tuple[list[dict], list[dict]]:
    """
    Compare two snapshots of a container catalog file.
    Returns (addition_events, scan_events).
    """
    additions: list[dict] = []
    scans:     list[dict] = []

    sw_before = (before or {}).get("software", {})
    sw_after  = after.get("software", {})

    if not isinstance(sw_after, dict) or not isinstance(sw_before, dict):
        return additions, scans

    for sw_name, sw_data in sw_after.items():
        releases_after  = sw_data.get("releases", [])
        releases_before = sw_before.get(sw_name, {}).get("releases", [])

        # Index previous releases by tag for fast lookup
        prev_by_tag = {r.get("tag", ""): r for r in releases_before}

        new_sw = sw_name not in sw_before

        for rel in releases_after:
            tag        = rel.get("tag", "")
            prev_rel   = prev_by_tag.get(tag)

            if prev_rel is None:
                # Brand-new software or brand-new tag
                action = "software_added" if new_sw else "release_added"
                additions.append(make_event(commit, "image", vendor, sw_name, tag, rel, action))
            else:
                # Existing tag — check if security data changed
                prev_gate = prev_rel.get("security", {}).get("policy_gate")
                cur_gate  = rel.get("security", {}).get("policy_gate")
                prev_scan = prev_rel.get("scanned_date")
                cur_scan  = rel.get("scanned_date")
                if cur_scan != prev_scan or cur_gate != prev_gate:
                    scans.append(make_event(commit, "image", vendor, sw_name, tag, rel, "scan_updated"))

    return additions, scans


# ── Helm chart diff ───────────────────────────────────────────────────────────

def diff_helm(before_list: Optional[list], after_list: list,
              commit: dict) -> tuple[list[dict], list[dict]]:
    additions: list[dict] = []
    scans:     list[dict] = []

    before_list = before_list or []

    # Index by chart name
    before_by_name = {c["name"]: c for c in before_list if c.get("name")}

    for chart in after_list:
        name           = chart.get("name", "")
        releases_after = chart.get("releases", [])
        prev_chart     = before_by_name.get(name)
        prev_rels      = prev_chart.get("releases", []) if prev_chart else []
        prev_by_ver    = {r.get("chart_version", ""): r for r in prev_rels}

        new_chart = name not in before_by_name

        for rel in releases_after:
            ver      = rel.get("chart_version", "")
            prev_rel = prev_by_ver.get(ver)

            # Flatten helm release into the same event shape
            flat_rel = {
                "tag":          ver,
                "release_date": rel.get("scanned_date"),   # helm has no release_date
                "scanned_date": rel.get("scanned_date"),
                "artif_ng":     chart.get("artif_ng", ""),
                "security": {
                    "policy_gate":          rel.get("gate_status", ""),
                    "vulnerability_summary": _aggregate_helm_images(rel.get("images", [])),
                },
            }

            if prev_rel is None:
                action = "software_added" if new_chart else "release_added"
                additions.append(make_event(commit, "helm", "helm", name, ver, flat_rel, action))
            else:
                if prev_rel.get("gate_status") != rel.get("gate_status") or \
                   prev_rel.get("scanned_date") != rel.get("scanned_date"):
                    scans.append(make_event(commit, "helm", "helm", name, ver, flat_rel, "scan_updated"))

    return additions, scans


def _aggregate_helm_images(images: list[dict]) -> dict:
    acc: dict = {}
    for img in images:
        v = img.get("security", {}).get("vulnerability_summary", {})
        for f in SFIELDS:
            acc[f] = acc.get(f, 0) + v.get(f, 0)
        acc["total"] = acc.get("total", 0) + v.get("total", 0)
    return acc


# ── Package diff (amazon.json etc.) ──────────────────────────────────────────

def diff_packages(before: Optional[dict], after: dict,
                  commit: dict) -> tuple[list[dict], list[dict]]:
    additions: list[dict] = []
    scans:     list[dict] = []

    rels_after  = after.get("releases", [])
    rels_before = (before or {}).get("releases", [])

    # Index by (name + version)
    prev_by_key = {(r.get("name", ""), r.get("version", "")): r for r in rels_before}
    vendor_name = (rels_after[0].get("vendor", "amazon") if rels_after else "amazon").lower()

    for rel in rels_after:
        key  = (rel.get("name", ""), rel.get("version", ""))
        prev = prev_by_key.get(key)

        flat_rel = {
            "tag":          rel.get("version", ""),
            "release_date": str(rel.get("release_date", "")),
            "scanned_date": None,
            "artif_ng":     "",
            "security":     rel.get("security", {}),
        }

        if prev is None:
            additions.append(
                make_event(commit, "package", vendor_name,
                           rel.get("name", ""), rel.get("version", ""), flat_rel, "software_added")
            )
        else:
            prev_gate = prev.get("security", {}).get("policy_gate")
            cur_gate  = rel.get("security", {}).get("policy_gate")
            if prev_gate != cur_gate:
                scans.append(
                    make_event(commit, "package", vendor_name,
                               rel.get("name", ""), rel.get("version", ""), flat_rel, "scan_updated")
                )

    return additions, scans


# ── File walker ───────────────────────────────────────────────────────────────

def walk_container_file(repo: Path, rel_path: str) -> tuple[list[dict], list[dict]]:
    commits = get_file_commits(repo, rel_path)
    if not commits:
        return [], []

    vendor = Path(rel_path).stem  # e.g. "dockerhub", "redhat"
    all_additions, all_scans = [], []
    prev_state: Optional[dict] = None

    for commit in commits:
        cur_state = get_json_at(repo, commit["hash"], rel_path)
        if cur_state is None or not isinstance(cur_state, dict):
            continue
        adds, scans = diff_container(prev_state, cur_state, commit, vendor)
        all_additions.extend(adds)
        all_scans.extend(scans)
        prev_state = cur_state

    return all_additions, all_scans


def walk_helm_file(repo: Path, rel_path: str) -> tuple[list[dict], list[dict]]:
    commits = get_file_commits(repo, rel_path)
    if not commits:
        return [], []

    all_additions, all_scans = [], []
    prev_state: Optional[list] = None

    for commit in commits:
        cur_state = get_json_at(repo, commit["hash"], rel_path)
        if cur_state is None or not isinstance(cur_state, list):
            continue
        adds, scans = diff_helm(prev_state, cur_state, commit)
        all_additions.extend(adds)
        all_scans.extend(scans)
        prev_state = cur_state

    return all_additions, all_scans


def walk_packages_file(repo: Path, rel_path: str) -> tuple[list[dict], list[dict]]:
    commits = get_file_commits(repo, rel_path)
    if not commits:
        return [], []

    all_additions, all_scans = [], []
    prev_state: Optional[dict] = None

    for commit in commits:
        cur_state = get_json_at(repo, commit["hash"], rel_path)
        if cur_state is None:
            continue
        adds, scans = diff_packages(prev_state, cur_state, commit)
        all_additions.extend(adds)
        all_scans.extend(scans)
        prev_state = cur_state

    return all_additions, all_scans


# ── Writer ────────────────────────────────────────────────────────────────────

def write_ndjson(path: Path, records: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        for r in sorted(records, key=lambda x: x.get("timestamp") or ""):
            f.write(json.dumps(r) + "\n")
    print(f"  Wrote {len(records):>5} records → {path}")


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(
        description="Extract metrics from catalog repo git history"
    )
    ap.add_argument("--catalog-repo", required=True,
                    help="Path to local RECORE.third-party-catalog clone")
    ap.add_argument("--output-dir", default=None,
                    help="Output dir for NDJSON files "
                         "(default: <catalog-repo>/metrics/events)")
    ap.add_argument("--dry-run", action="store_true",
                    help="Print counts only, do not write files")
    args = ap.parse_args()

    catalog_repo = Path(args.catalog_repo).resolve()
    output_dir   = Path(args.output_dir).resolve() if args.output_dir \
                   else catalog_repo / "metrics" / "events"

    print(f"Catalog repo : {catalog_repo}")
    print(f"Output dir   : {output_dir}")
    print()

    all_additions: list[dict] = []
    all_scans:     list[dict] = []

    # ── Container files ───────────────────────────────────────────────────────
    containers_dir = catalog_repo / "vendor-catalog" / "containers"
    if containers_dir.exists():
        for f in sorted(containers_dir.glob("*.json")):
            rel = str(f.relative_to(catalog_repo))
            print(f"Processing {rel}…")
            adds, scans = walk_container_file(catalog_repo, rel)
            all_additions.extend(adds)
            all_scans.extend(scans)
            print(f"  → {len(adds)} additions, {len(scans)} scan updates")

    # ── Helm chart files ──────────────────────────────────────────────────────
    charts_dir = catalog_repo / "vendor-catalog" / "charts"
    if charts_dir.exists():
        for f in sorted(charts_dir.glob("*.json")):
            rel = str(f.relative_to(catalog_repo))
            print(f"Processing {rel}…")
            adds, scans = walk_helm_file(catalog_repo, rel)
            all_additions.extend(adds)
            all_scans.extend(scans)
            print(f"  → {len(adds)} additions, {len(scans)} scan updates")

    # ── Package files ─────────────────────────────────────────────────────────
    packages_dir = catalog_repo / "vendor-catalog" / "packages"
    if packages_dir.exists():
        for f in sorted(packages_dir.glob("*.json")):
            rel = str(f.relative_to(catalog_repo))
            print(f"Processing {rel}…")
            adds, scans = walk_packages_file(catalog_repo, rel)
            all_additions.extend(adds)
            all_scans.extend(scans)
            print(f"  → {len(adds)} additions, {len(scans)} scan updates")

    combined = all_additions + all_scans
    print(f"\nTotal: {len(all_additions)} additions, {len(all_scans)} scan updates, "
          f"{len(combined)} combined.")

    if args.dry_run:
        print("Dry run — nothing written.")
        return

    write_ndjson(output_dir / "additions.ndjson", all_additions)
    write_ndjson(output_dir / "scans.ndjson",     all_scans)
    write_ndjson(output_dir / "all-events.ndjson", combined)

    # Quick top-line summary
    print("\nAdditions by vendor:")
    by_vendor: dict[str, int] = {}
    for e in all_additions:
        v = e["vendor"]
        by_vendor[v] = by_vendor.get(v, 0) + 1
    for v, c in sorted(by_vendor.items(), key=lambda x: -x[1]):
        print(f"  {v:<20} {c:>4} entries added")


if __name__ == "__main__":
    main()
