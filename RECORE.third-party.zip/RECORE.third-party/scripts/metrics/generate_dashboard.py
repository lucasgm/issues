#!/usr/bin/env python3
"""
Generate a self-contained HTML dashboard from the NDJSON metrics files.

Writes:  metrics/DASHBOARD.html

Usage:
    python generate_dashboard.py --metrics-dir /path/to/metrics/events
"""

import json
import argparse
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path


# ── Data helpers ──────────────────────────────────────────────────────────────

def load_ndjson(path: Path) -> list[dict]:
    if not path.exists():
        return []
    records = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    pass
    return records


def week_label(ts: str) -> str:
    if not ts:
        return "unknown"
    try:
        dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        iso = dt.isocalendar()
        return f"{iso[0]}-W{iso[1]:02d}"
    except ValueError:
        return ts[:10]


def pct_f(num: int, total: int) -> float:
    return round(num / total * 100, 1) if total else 0.0


# ── Data aggregation ──────────────────────────────────────────────────────────

def build_weekly_chart_data(additions: list[dict], scans: list[dict],
                             weeks: int = 12) -> dict:
    adds_by_week:  dict[str, int] = defaultdict(int)
    vuln_by_week:  dict[str, int] = defaultdict(int)
    pass_by_week:  dict[str, int] = defaultdict(int)
    fail_by_week:  dict[str, int] = defaultdict(int)

    for e in additions:
        w = week_label(e.get("timestamp") or "")
        if w == "unknown":
            continue
        adds_by_week[w] += 1
        if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower():
            vuln_by_week[w] += 1

    for e in scans:
        w    = week_label(e.get("timestamp") or "")
        gate = str(e.get("security", {}).get("policy_gate", "")).lower()
        if w == "unknown":
            continue
        if "fail" in gate:
            fail_by_week[w] += 1
        elif "pass" in gate:
            pass_by_week[w] += 1

    all_weeks = sorted(
        set(adds_by_week) | set(fail_by_week) | set(pass_by_week)
    )[-weeks:]

    labels, added, vuln, fail_rate = [], [], [], []
    for w in all_weeks:
        labels.append(w)
        added.append(adds_by_week.get(w, 0))
        vuln.append(vuln_by_week.get(w, 0))
        sf = fail_by_week.get(w, 0)
        sp = pass_by_week.get(w, 0)
        fail_rate.append(pct_f(sf, sf + sp))

    return {"labels": labels, "added": added, "vuln": vuln, "fail_rate": fail_rate}


def build_kpis(additions: list[dict], scans: list[dict], now: datetime) -> dict:
    total_added = len(additions)
    total_vuln  = sum(1 for e in additions
                      if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower())
    scan_pass   = sum(1 for e in scans
                      if "pass" in str(e.get("security", {}).get("policy_gate", "")).lower())
    scan_fail   = sum(1 for e in scans
                      if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower())
    total_scans = scan_pass + scan_fail

    this_week = week_label(now.isoformat())
    wk_added  = sum(1 for e in additions if week_label(e.get("timestamp") or "") == this_week)
    wk_vuln   = sum(1 for e in additions
                    if week_label(e.get("timestamp") or "") == this_week
                    and "fail" in str(e.get("security", {}).get("policy_gate", "")).lower())

    cutoff_30 = (now - timedelta(days=30)).isoformat()
    last30     = sum(1 for e in additions if (e.get("timestamp") or "") >= cutoff_30)

    return {
        "total_added":  total_added,
        "total_vuln":   total_vuln,
        "overall_pass": pct_f(scan_pass, total_scans),
        "wk_label":     this_week,
        "wk_added":     wk_added,
        "wk_vuln":      wk_vuln,
        "last30":       last30,
        "generated":    now.strftime("%Y-%m-%d %H:%M UTC"),
    }


def build_weekly_detail(additions: list[dict], scans: list[dict],
                         weeks: int = 4) -> list[dict]:
    adds_by_week:  dict[str, list] = defaultdict(list)
    fails_by_week: dict[str, list] = defaultdict(list)

    for e in additions:
        w = week_label(e.get("timestamp") or "")
        if w != "unknown":
            adds_by_week[w].append(e)

    for e in scans:
        w = week_label(e.get("timestamp") or "")
        if w != "unknown" and "fail" in str(e.get("security", {}).get("policy_gate", "")).lower():
            fails_by_week[w].append(e)

    all_weeks = sorted(set(adds_by_week) | set(fails_by_week))[-weeks:]
    result = []
    for w in reversed(all_weeks):
        week_adds  = sorted(adds_by_week.get(w, []), key=lambda x: x.get("timestamp") or "")
        vuln_adds  = [e for e in week_adds
                      if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower()]
        rescan_fails = sorted(fails_by_week.get(w, []),
                              key=lambda x: -(x.get("security", {}).get("critical", 0)))

        def fmt_add(e):
            sec  = e.get("security", {})
            gate = str(sec.get("policy_gate", "")).lower()
            return {
                "date":     (e.get("timestamp") or "")[:10],
                "vendor":   e.get("vendor", ""),
                "software": e.get("software", ""),
                "tag":      e.get("tag", ""),
                "type":     e.get("type", ""),
                "vuln":     "fail" in gate,
                "critical": sec.get("critical", 0),
                "high":     sec.get("high", 0),
            }

        def fmt_vuln(e, source):
            sec = e.get("security", {})
            return {
                "date":     (e.get("timestamp") or "")[:10],
                "vendor":   e.get("vendor", ""),
                "software": e.get("software", ""),
                "tag":      e.get("tag", ""),
                "critical": sec.get("critical", 0),
                "high":     sec.get("high", 0),
                "medium":   sec.get("medium", 0),
                "source":   source,
            }

        all_vuln = (
            [fmt_vuln(e, "new entry") for e in vuln_adds] +
            [fmt_vuln(e, "re-scan")   for e in rescan_fails]
        )
        all_vuln.sort(key=lambda x: -x["critical"])

        result.append({
            "week":       w,
            "added":      [fmt_add(e) for e in week_adds],
            "vulnerable": all_vuln,
        })
    return result


# ── HTML template ─────────────────────────────────────────────────────────────

HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Third-Party Catalog — Weekly Dashboard</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<style>
  :root {{
    --bg:       #0f1117;
    --surface:  #1a1d27;
    --surface2: #22263a;
    --border:   #2e3350;
    --accent:   #4f8ef7;
    --green:    #22c55e;
    --red:      #ef4444;
    --yellow:   #f59e0b;
    --text:     #e2e8f0;
    --muted:    #8892a4;
    --radius:   10px;
  }}
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
          background: var(--bg); color: var(--text); min-height: 100vh; padding: 28px 24px; }}

  h1   {{ font-size: 1.6rem; font-weight: 700; letter-spacing: -.5px; }}
  h2   {{ font-size: 1.1rem; font-weight: 600; color: var(--muted); text-transform: uppercase;
          letter-spacing: .8px; margin-bottom: 14px; }}
  .subtitle {{ color: var(--muted); font-size: .9rem; margin-top: 4px; }}

  .header {{ display: flex; justify-content: space-between; align-items: flex-end;
             margin-bottom: 32px; flex-wrap: wrap; gap: 8px; }}
  .generated {{ color: var(--muted); font-size: .8rem; }}

  /* KPI cards */
  .kpi-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
               gap: 16px; margin-bottom: 32px; }}
  .kpi {{ background: var(--surface); border: 1px solid var(--border); border-radius: var(--radius);
          padding: 20px 22px; position: relative; overflow: hidden; }}
  .kpi::before {{ content: ""; position: absolute; top: 0; left: 0; width: 4px;
                  height: 100%; border-radius: var(--radius) 0 0 var(--radius); }}
  .kpi.blue::before  {{ background: var(--accent); }}
  .kpi.green::before {{ background: var(--green); }}
  .kpi.red::before   {{ background: var(--red); }}
  .kpi.yellow::before{{ background: var(--yellow); }}
  .kpi-label {{ font-size: .75rem; color: var(--muted); text-transform: uppercase;
                letter-spacing: .6px; margin-bottom: 8px; }}
  .kpi-value {{ font-size: 2rem; font-weight: 700; line-height: 1; }}
  .kpi-sub   {{ font-size: .78rem; color: var(--muted); margin-top: 6px; }}

  /* Chart panel */
  .panel {{ background: var(--surface); border: 1px solid var(--border);
            border-radius: var(--radius); padding: 24px; margin-bottom: 28px; }}
  .chart-wrap {{ position: relative; height: 320px; }}

  /* Weekly detail accordion */
  .week-block {{ background: var(--surface); border: 1px solid var(--border);
                 border-radius: var(--radius); margin-bottom: 14px; overflow: hidden; }}
  .week-header {{ display: flex; justify-content: space-between; align-items: center;
                  padding: 16px 20px; cursor: pointer; user-select: none;
                  transition: background .15s; }}
  .week-header:hover {{ background: var(--surface2); }}
  .week-title {{ font-weight: 600; font-size: 1rem; display: flex; align-items: center; gap: 10px; }}
  .week-badge {{ font-size: .75rem; padding: 3px 9px; border-radius: 999px; font-weight: 500; }}
  .badge-added {{ background: #1e3a5f; color: #93c5fd; }}
  .badge-vuln  {{ background: #3f1010; color: #fca5a5; }}
  .badge-clean {{ background: #0f2e1b; color: #86efac; }}
  .week-arrow  {{ color: var(--muted); font-size: .85rem; transition: transform .2s; }}
  .week-body   {{ display: none; border-top: 1px solid var(--border); }}
  .week-body.open {{ display: block; }}
  .week-arrow.open {{ transform: rotate(180deg); }}
  .tab-bar {{ display: flex; border-bottom: 1px solid var(--border); }}
  .tab {{ padding: 10px 18px; font-size: .85rem; font-weight: 500; cursor: pointer;
          color: var(--muted); border-bottom: 2px solid transparent; transition: all .15s;
          user-select: none; }}
  .tab.active {{ color: var(--accent); border-bottom-color: var(--accent); }}
  .tab-content {{ padding: 18px 20px; display: none; overflow-x: auto; }}
  .tab-content.active {{ display: block; }}
  .empty-note {{ color: var(--muted); font-size: .85rem; font-style: italic; }}

  /* Data tables */
  table {{ width: 100%; border-collapse: collapse; font-size: .83rem; }}
  th {{ padding: 8px 12px; text-align: left; color: var(--muted); font-weight: 500;
        font-size: .75rem; text-transform: uppercase; letter-spacing: .5px;
        border-bottom: 1px solid var(--border); white-space: nowrap; }}
  td {{ padding: 9px 12px; border-bottom: 1px solid var(--border); vertical-align: middle; }}
  tr:last-child td {{ border-bottom: none; }}
  tr:hover td {{ background: var(--surface2); }}
  .tag-pill {{ display: inline-block; background: var(--surface2); border: 1px solid var(--border);
               border-radius: 5px; padding: 1px 8px; font-family: monospace; font-size: .8rem; }}
  .vuln-yes {{ color: var(--red); font-weight: 600; }}
  .vuln-no  {{ color: var(--green); }}
  .crit-cell {{ color: var(--red); font-weight: 600; }}
  .high-cell {{ color: var(--yellow); }}
  .source-pill {{ font-size: .72rem; padding: 2px 7px; border-radius: 999px; }}
  .src-new  {{ background: #1e3a5f; color: #93c5fd; }}
  .src-scan {{ background: #2d1f4e; color: #c4b5fd; }}
  .type-pill {{ font-size: .72rem; padding: 2px 7px; border-radius: 999px;
                background: var(--surface2); color: var(--muted); border: 1px solid var(--border); }}
</style>
</head>
<body>

<div class="header">
  <div>
    <h1>Third-Party Catalog — Weekly Dashboard</h1>
    <p class="subtitle">Security &amp; activity metrics derived from catalog git history</p>
  </div>
  <span class="generated">Generated: {generated}</span>
</div>

<!-- KPI cards -->
<div class="kpi-grid">
  <div class="kpi blue">
    <div class="kpi-label">Total Images in Catalog</div>
    <div class="kpi-value">{total_added}</div>
    <div class="kpi-sub">{last30} added in last 30 days</div>
  </div>
  <div class="kpi red">
    <div class="kpi-label">Vulnerable at Ingestion</div>
    <div class="kpi-value">{total_vuln}</div>
    <div class="kpi-sub">of all-time additions</div>
  </div>
  <div class="kpi green">
    <div class="kpi-label">Overall Rescan Pass Rate</div>
    <div class="kpi-value">{overall_pass}%</div>
    <div class="kpi-sub">across all rescan events</div>
  </div>
  <div class="kpi blue">
    <div class="kpi-label">This Week — Pulled</div>
    <div class="kpi-value">{wk_added}</div>
    <div class="kpi-sub">{wk_label}</div>
  </div>
  <div class="kpi {wk_vuln_color}">
    <div class="kpi-label">This Week — Vulnerable</div>
    <div class="kpi-value">{wk_vuln}</div>
    <div class="kpi-sub">of {wk_added} pulled this week</div>
  </div>
</div>

<!-- Weekly trend chart -->
<div class="panel">
  <h2>Weekly Activity Trend</h2>
  <div class="chart-wrap">
    <canvas id="weeklyChart"></canvas>
  </div>
</div>

<!-- Weekly detail accordion -->
<div class="panel">
  <h2>Weekly Image Detail</h2>
  <div id="weeklyDetail"></div>
</div>

<script>
const CHART_DATA   = {chart_data_json};
const WEEKLY_DETAIL = {weekly_detail_json};

// ── Chart ──────────────────────────────────────────────────────────────────
const ctx = document.getElementById("weeklyChart").getContext("2d");
new Chart(ctx, {{
  data: {{
    labels: CHART_DATA.labels,
    datasets: [
      {{
        type: "bar",
        label: "Images Added",
        data: CHART_DATA.added,
        backgroundColor: "rgba(79,142,247,0.7)",
        borderColor:     "rgba(79,142,247,1)",
        borderWidth: 1,
        borderRadius: 4,
        yAxisID: "y",
      }},
      {{
        type: "bar",
        label: "Vulnerable at Add",
        data: CHART_DATA.vuln,
        backgroundColor: "rgba(239,68,68,0.75)",
        borderColor:     "rgba(239,68,68,1)",
        borderWidth: 1,
        borderRadius: 4,
        yAxisID: "y",
      }},
      {{
        type: "line",
        label: "Rescan Fail Rate (%)",
        data: CHART_DATA.fail_rate,
        borderColor:  "rgba(245,158,11,0.9)",
        backgroundColor: "rgba(245,158,11,0.1)",
        borderWidth: 2,
        pointRadius: 4,
        pointBackgroundColor: "rgba(245,158,11,1)",
        tension: 0.35,
        yAxisID: "y2",
        fill: true,
      }},
    ],
  }},
  options: {{
    responsive: true,
    maintainAspectRatio: false,
    interaction: {{ mode: "index", intersect: false }},
    plugins: {{
      legend: {{ labels: {{ color: "#8892a4", font: {{ size: 12 }} }} }},
      tooltip: {{
        backgroundColor: "#1a1d27",
        borderColor: "#2e3350",
        borderWidth: 1,
        titleColor: "#e2e8f0",
        bodyColor: "#8892a4",
      }},
    }},
    scales: {{
      x: {{
        ticks: {{ color: "#8892a4", maxRotation: 45 }},
        grid:  {{ color: "rgba(46,51,80,0.5)" }},
      }},
      y: {{
        position: "left",
        title: {{ display: true, text: "Images", color: "#8892a4", font: {{ size: 11 }} }},
        ticks: {{ color: "#8892a4", precision: 0 }},
        grid:  {{ color: "rgba(46,51,80,0.5)" }},
        beginAtZero: true,
      }},
      y2: {{
        position: "right",
        title: {{ display: true, text: "Fail Rate (%)", color: "#f59e0b", font: {{ size: 11 }} }},
        ticks: {{ color: "#f59e0b", callback: v => v + "%" }},
        grid:  {{ drawOnChartArea: false }},
        min: 0, max: 100,
      }},
    }},
  }},
}});

// ── Accordion ──────────────────────────────────────────────────────────────
const container = document.getElementById("weeklyDetail");

WEEKLY_DETAIL.forEach((week, wi) => {{
  const totalVuln = week.vulnerable.length;
  const addedCount = week.added.length;
  const vulnBadge = totalVuln > 0
    ? `<span class="week-badge badge-vuln">⚠ ${{totalVuln}} vulnerable</span>`
    : `<span class="week-badge badge-clean">✓ clean</span>`;

  const block = document.createElement("div");
  block.className = "week-block";
  block.innerHTML = `
    <div class="week-header" onclick="toggleWeek(${{wi}})">
      <div class="week-title">
        <span>${{week.week}}</span>
        <span class="week-badge badge-added">${{addedCount}} added</span>
        ${{vulnBadge}}
      </div>
      <span class="week-arrow" id="arrow-${{wi}}">▼</span>
    </div>
    <div class="week-body" id="body-${{wi}}">
      <div class="tab-bar">
        <div class="tab active" id="tab-${{wi}}-0" onclick="switchTab(${{wi}},0)">
          All Images (${{addedCount}})
        </div>
        <div class="tab" id="tab-${{wi}}-1" onclick="switchTab(${{wi}},1)">
          Vulnerable (${{totalVuln}})
        </div>
      </div>
      <div class="tab-content active" id="tc-${{wi}}-0">${{renderAddedTable(week.added)}}</div>
      <div class="tab-content" id="tc-${{wi}}-1">${{renderVulnTable(week.vulnerable)}}</div>
    </div>`;
  container.appendChild(block);
}});

function toggleWeek(i) {{
  const body  = document.getElementById(`body-${{i}}`);
  const arrow = document.getElementById(`arrow-${{i}}`);
  body.classList.toggle("open");
  arrow.classList.toggle("open");
}}

function switchTab(wi, ti) {{
  [0,1].forEach(j => {{
    document.getElementById(`tab-${{wi}}-${{j}}`).classList.toggle("active", j === ti);
    document.getElementById(`tc-${{wi}}-${{j}}`).classList.toggle("active",  j === ti);
  }});
}}

function renderAddedTable(rows) {{
  if (!rows.length) return `<p class="empty-note">No images added this week.</p>`;
  const cols = ["Date","Vendor","Software","Tag","Type","Vulnerable","Critical","High"];
  let html = `<table><thead><tr>${{cols.map(c=>`<th>${{c}}</th>`).join("")}}</tr></thead><tbody>`;
  rows.forEach(r => {{
    const vCell = r.vuln
      ? `<span class="vuln-yes">⚠ yes</span>`
      : `<span class="vuln-no">✓ no</span>`;
    html += `<tr>
      <td>${{r.date}}</td>
      <td>${{r.vendor}}</td>
      <td><strong>${{r.software}}</strong></td>
      <td><span class="tag-pill">${{r.tag}}</span></td>
      <td><span class="type-pill">${{r.type}}</span></td>
      <td>${{vCell}}</td>
      <td class="${{r.critical > 0 ? "crit-cell" : ""}}">${{r.critical || "—"}}</td>
      <td class="${{r.high > 0 ? "high-cell" : ""}}">${{r.high || "—"}}</td>
    </tr>`;
  }});
  return html + "</tbody></table>";
}}

function renderVulnTable(rows) {{
  if (!rows.length) return `<p class="empty-note">No vulnerable images this week.</p>`;
  const cols = ["Date","Vendor","Software","Tag","Critical","High","Medium","Source"];
  let html = `<table><thead><tr>${{cols.map(c=>`<th>${{c}}</th>`).join("")}}</tr></thead><tbody>`;
  rows.forEach(r => {{
    const srcClass = r.source === "re-scan" ? "src-scan" : "src-new";
    const srcLabel = r.source === "re-scan" ? "re-scan" : "new entry";
    html += `<tr>
      <td>${{r.date}}</td>
      <td>${{r.vendor}}</td>
      <td><strong>${{r.software}}</strong></td>
      <td><span class="tag-pill">${{r.tag}}</span></td>
      <td class="${{r.critical > 0 ? "crit-cell" : ""}}">${{r.critical || "—"}}</td>
      <td class="${{r.high > 0 ? "high-cell" : ""}}">${{r.high || "—"}}</td>
      <td>${{r.medium || "—"}}</td>
      <td><span class="source-pill ${{srcClass}}">${{srcLabel}}</span></td>
    </tr>`;
  }});
  return html + "</tbody></table>";
}}
</script>
</body>
</html>
"""


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    ap = argparse.ArgumentParser(description="Generate HTML dashboard from catalog metrics")
    ap.add_argument("--metrics-dir", required=True,
                    help="Directory containing additions.ndjson and scans.ndjson")
    ap.add_argument("--weeks", type=int, default=12,
                    help="Number of weeks to show in the chart (default: 12)")
    ap.add_argument("--detail-weeks", type=int, default=4,
                    help="Number of weeks to show in the image detail accordion (default: 4)")
    args = ap.parse_args()

    metrics_dir = Path(args.metrics_dir).resolve()
    output_dir  = metrics_dir.parent

    additions = load_ndjson(metrics_dir / "additions.ndjson")
    scans     = load_ndjson(metrics_dir / "scans.ndjson")
    print(f"Loaded {len(additions):,} additions and {len(scans):,} scan events.")

    now          = datetime.now(timezone.utc)
    kpis         = build_kpis(additions, scans, now)
    chart_data   = build_weekly_chart_data(additions, scans, weeks=args.weeks)
    weekly_detail = build_weekly_image_detail(additions, scans, weeks=args.detail_weeks)

    wk_vuln_color = "red" if kpis["wk_vuln"] > 0 else "green"

    html = HTML_TEMPLATE.format(
        generated       = kpis["generated"],
        total_added     = f"{kpis['total_added']:,}",
        total_vuln      = f"{kpis['total_vuln']:,}",
        overall_pass    = kpis["overall_pass"],
        wk_label        = kpis["wk_label"],
        wk_added        = kpis["wk_added"],
        wk_vuln         = kpis["wk_vuln"],
        wk_vuln_color   = wk_vuln_color,
        last30          = kpis["last30"],
        chart_data_json = json.dumps(chart_data),
        weekly_detail_json = json.dumps(weekly_detail),
    )

    output_path = output_dir / "DASHBOARD.html"
    output_dir.mkdir(parents=True, exist_ok=True)
    output_path.write_text(html, encoding="utf-8")
    print(f"Wrote dashboard → {output_path}")


def build_weekly_image_detail(additions: list[dict], scans: list[dict],
                               weeks: int = 4) -> list[dict]:
    adds_by_week:  dict[str, list] = defaultdict(list)
    fails_by_week: dict[str, list] = defaultdict(list)

    for e in additions:
        w = week_label(e.get("timestamp") or "")
        if w != "unknown":
            adds_by_week[w].append(e)

    for e in scans:
        w = week_label(e.get("timestamp") or "")
        if w != "unknown" and "fail" in str(e.get("security", {}).get("policy_gate", "")).lower():
            fails_by_week[w].append(e)

    all_weeks = sorted(set(adds_by_week) | set(fails_by_week))[-weeks:]
    result = []
    for w in reversed(all_weeks):
        week_adds   = sorted(adds_by_week.get(w, []), key=lambda x: x.get("timestamp") or "")
        vuln_adds   = [e for e in week_adds
                       if "fail" in str(e.get("security", {}).get("policy_gate", "")).lower()]
        rescan_fails = sorted(fails_by_week.get(w, []),
                              key=lambda x: -(x.get("security", {}).get("critical", 0)))

        def fmt_add(e):
            sec = e.get("security", {})
            return {
                "date":     (e.get("timestamp") or "")[:10],
                "vendor":   e.get("vendor", ""),
                "software": e.get("software", ""),
                "tag":      e.get("tag", ""),
                "type":     e.get("type", ""),
                "vuln":     "fail" in str(sec.get("policy_gate", "")).lower(),
                "critical": sec.get("critical", 0),
                "high":     sec.get("high", 0),
            }

        def fmt_vuln(e, source):
            sec = e.get("security", {})
            return {
                "date":     (e.get("timestamp") or "")[:10],
                "vendor":   e.get("vendor", ""),
                "software": e.get("software", ""),
                "tag":      e.get("tag", ""),
                "critical": sec.get("critical", 0),
                "high":     sec.get("high", 0),
                "medium":   sec.get("medium", 0),
                "source":   source,
            }

        all_vuln = (
            [fmt_vuln(e, "new entry") for e in vuln_adds] +
            [fmt_vuln(e, "re-scan")   for e in rescan_fails]
        )
        all_vuln.sort(key=lambda x: -x["critical"])

        result.append({
            "week":       w,
            "added":      [fmt_add(e) for e in week_adds],
            "vulnerable": all_vuln,
        })
    return result


if __name__ == "__main__":
    main()
