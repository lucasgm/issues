import json
import requests
import hashlib
import os
from pathlib import Path

# Dynamic JSON selection: use environment variable VENDOR_JSON_PATH if provided; else
# attempt to auto-detect a vendor JSON in current working directory (e.g. corretto-<runid>.json or amazon-<runid>.json)

def resolve_vendor_json():
    # Priority 1: Explicit environment variable
    env_path = os.environ.get("VENDOR_JSON_PATH")
    if env_path:
        p = Path(env_path)
        if p.is_file():
            return p
        else:
            print(f"Provided VENDOR_JSON_PATH does not exist: {env_path}")
    # Priority 2: Look for expected pattern in CWD
    cwd = Path.cwd()
    candidates = list(cwd.glob("amazon-*.json")) + list(cwd.glob("corretto-*.json"))
    if candidates:
        # Pick the most recently modified
        candidates.sort(key=lambda f: f.stat().st_mtime, reverse=True)
        return candidates[0]
    # Priority 3: Single *.json file fallback
    generic = list(cwd.glob("*.json"))
    if len(generic) == 1:
        return generic[0]
    print("Unable to locate vendor JSON file for checksum injection.")
    return None

# Helper to fetch RPM and calculate SHA256
def fetch_sha256(url):
    try:
        resp = requests.get(url, stream=True, timeout=60)
        resp.raise_for_status()
        sha256 = hashlib.sha256()
        for chunk in resp.iter_content(8192):
            sha256.update(chunk)
        return sha256.hexdigest()
    except Exception as e:
        print(f"ERROR fetching {url}: {e}")
        return None

def main():
    vendor_json = resolve_vendor_json()
    if not vendor_json:
        print("No JSON file to update; exiting.")
        return
    print(f"Using vendor JSON: {vendor_json}")
    with open(vendor_json, "r") as f:
        data = json.load(f)
    updated = False
    for release in data.get("releases", []):
        src = release.get("source", {})
        verification = src.get("verification", {})
        checksum = verification.get("checksum", {})
        rpm_url = release.get("rpm_download_url")
        if rpm_url:
            print(f"Processing {release.get('name')} {release.get('version')}")
            sha = fetch_sha256(rpm_url)
            if sha:
                if checksum.get("sha256") != sha:
                    verification["checksum"] = {"sha256": sha}
                    src["verification"] = verification
                    release["source"] = src
                    updated = True
                    print(f"Injected SHA256: {sha}")
                else:
                    print("Checksum already correct.")
            else:
                print("Could not fetch or compute checksum.")
    if updated:
        with open(vendor_json, "w") as f:
            json.dump(data, f, indent=2)
        print(f"Updated {vendor_json.name} with new RPM sha256 checksums.")
    else:
        print("No updates needed.")

if __name__ == "__main__":
    main()