#!/usr/bin/env python3
"""Discover tags and lifecycle metadata for Amazon ECR Public images."""

import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Tuple


EXCLUDE_PATTERN = re.compile(
    r"(beta|alpha|rc|dev|snapshot|test|nightly|preview|tech-preview)",
    re.IGNORECASE,
)

# Map common architecture tokens that appear in tag names to canonical
# architecture identifiers (similar to Docker/OCI arch names).
_ARCH_TAG_PATTERNS = {
    "amd64": [
        re.compile(r"(?:^|[-_.])amd64(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])x86_64(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])x64(?:$|[-_.])", re.IGNORECASE),
    ],
    "arm64": [
        re.compile(r"(?:^|[-_.])arm64(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])aarch64(?:$|[-_.])", re.IGNORECASE),
    ],
    "arm": [
        re.compile(r"(?:^|[-_.])armv7(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])armv6(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])armhf(?:$|[-_.])", re.IGNORECASE),
        re.compile(r"(?:^|[-_.])arm(?:$|[-_.])", re.IGNORECASE),
    ],
    "ppc64le": [
        re.compile(r"(?:^|[-_.])ppc64le(?:$|[-_.])", re.IGNORECASE),
    ],
    "s390x": [
        re.compile(r"(?:^|[-_.])s390x(?:$|[-_.])", re.IGNORECASE),
    ],
}


def _normalise_arch_name(arch: str) -> str:
    """Normalise various arch spellings to a canonical identifier."""

    a = arch.lower().strip()
    if a in {"x86_64", "x64"}:
        return "amd64"
    if a == "aarch64":
        return "arm64"
    return a


def _infer_arches_from_tag(tag: str) -> List[str]:
    """Best-effort guess of architecture(s) encoded in a tag name."""

    found = set()
    for canon, patterns in _ARCH_TAG_PATTERNS.items():
        for pat in patterns:
            if pat.search(tag):
                found.add(canon)
                break
    return list(found)


def _parse_created_iso(created_raw: Optional[str]) -> Optional[datetime]:
    """Parse an image "Created" timestamp into a UTC ``datetime``.

    Accepts standard ISO-8601 plus a trailing ``Z`` (UTC designator). Returns
    ``None`` when the value is missing or cannot be parsed.
    """

    if not created_raw:
        return None

    val = created_raw.replace("Z", "+00:00")
    try:
        dt = datetime.fromisoformat(val)
    except ValueError:
        return None

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)

    # Normalise to second precision for stable catalog output
    return dt.replace(microsecond=0)


def run_skopeo_list_tags(repo: str) -> List[str]:
    """Return tags for docker://repo using skopeo, or an empty list on error."""
    try:
        proc = subprocess.run(
            ["skopeo", "list-tags", f"docker://{repo}"],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        print(
            f"ERROR: skopeo not found on PATH; cannot discover tags for {repo}",
            file=sys.stderr,
        )
        return []

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(
            f"[WARN] skopeo list-tags failed for {repo} (rc={proc.returncode}): {msg[:200]}",
            file=sys.stderr,
        )
        return []

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        print(f"[WARN] Failed to parse skopeo output for {repo}: {exc}", file=sys.stderr)
        return []

    tags = data.get("Tags") or []
    return [t for t in tags if isinstance(t, str)]


def parse_min_date(value: Optional[str]) -> Optional[datetime]:
    """Parse a ``min_date`` string (e.g. ``"6 months"``) into a UTC cutoff."""
    if not value:
        return None

    m = re.match(r"^\s*(\d+)\s*(day|days|week|weeks|month|months)\s*$", value, re.IGNORECASE)
    if not m:
        print(f"[WARN] Unsupported min_date format '{value}'; ignoring.", file=sys.stderr)
        return None

    amount = int(m.group(1))
    unit = m.group(2).lower()
    if "day" in unit:
        delta = timedelta(days=amount)
    elif "week" in unit:
        delta = timedelta(weeks=amount)
    else:
        # months -> approximate as 30 days each
        delta = timedelta(days=30 * amount)

    return datetime.now(timezone.utc) - delta


def inspect_tag_for_arches(
    repo: str,
    tag: str,
    arches: List[str],
    oses: Optional[List[str]] = None,
) -> Tuple[bool, Optional[datetime]]:
    """Return (ok, created_at_utc) for repo:tag, enforcing required arch/OS.

    When ``arches`` and/or ``oses`` are provided, we require at least one
    successful ``skopeo inspect`` using those overrides. If neither are
    specified, we fall back to a single inspect without overrides.
    """

    created_best: Optional[datetime] = None
    arches = arches or []
    oses = oses or []

    if arches or oses:
        arch_list = arches or [None]
        os_list = oses or [None]

        for arch in arch_list:
            for os_val in os_list:
                try:
                    cmd = ["skopeo", "inspect"]
                    if arch:
                        cmd.append(f"--override-arch={arch}")
                    if os_val:
                        cmd.append(f"--override-os={os_val}")
                    cmd.append(f"docker://{repo}:{tag}")

                    proc = subprocess.run(
                        cmd,
                        check=False,
                        capture_output=True,
                        text=True,
                    )
                except FileNotFoundError:
                    print(
                        "ERROR: skopeo not found on PATH; cannot inspect images",
                        file=sys.stderr,
                    )
                    return False, None

                if proc.returncode != 0:
                    msg = proc.stderr.strip() or proc.stdout.strip()
                    details = []
                    if arch:
                        details.append(f"arch={arch}")
                    if os_val:
                        details.append(f"os={os_val}")
                    detail_str = " ".join(details) or "no-overrides"
                    print(
                        f"[WARN] skopeo inspect failed for {repo}:{tag} {detail_str} (rc={proc.returncode}): {msg[:200]}",
                        file=sys.stderr,
                    )
                    continue

                try:
                    data = json.loads(proc.stdout or "{}")
                except json.JSONDecodeError:
                    details = []
                    if arch:
                        details.append(f"arch={arch}")
                    if os_val:
                        details.append(f"os={os_val}")
                    detail_str = " ".join(details) or "no-overrides"
                    print(
                        f"[WARN] Failed to parse inspect output for {repo}:{tag} {detail_str}",
                        file=sys.stderr,
                    )
                    continue

                created = _parse_created_iso(data.get("Created") or data.get("created"))
                if created and (created_best is None or created > created_best):
                    created_best = created

        # Consider it ok only if we obtained at least one valid Created
        return (created_best is not None), created_best

    # No specific arch/OS requested; inspect once without override
    try:
        proc = subprocess.run(
            ["skopeo", "inspect", f"docker://{repo}:{tag}"],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        print("ERROR: skopeo not found on PATH; cannot inspect images", file=sys.stderr)
        return False, None

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(
            f"[WARN] skopeo inspect failed for {repo}:{tag} (rc={proc.returncode}): {msg[:200]}",
            file=sys.stderr,
        )
        return False, None

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError:
        print(f"[WARN] Failed to parse inspect output for {repo}:{tag}", file=sys.stderr)
        return False, None

    created = _parse_created_iso(data.get("Created") or data.get("created"))
    return True, created


def build_repo_from_entry(entry: Dict) -> str:
    """Return base_registry/source_path/software for a config entry."""
    base_registry = (entry.get("base_registry") or "").rstrip("/")
    source_path = (entry.get("source_path") or "").lstrip("/")
    software = entry.get("software") or ""
    repo = "/".join(part for part in [base_registry, source_path, software] if part)
    return repo


def get_architectures_from_entry(entry: Dict) -> List[str]:
    """Normalise architecture configuration from a config ``entry``.

    Handles both string and list forms, filtering out empty / non-string
    values. Returns a list that can be passed directly to ``skopeo`` helpers.
    """

    container = entry.get("container") or {}
    arch_val = container.get("architecture")

    if isinstance(arch_val, list):
        return [str(a) for a in arch_val if isinstance(a, str) and a]

    if isinstance(arch_val, str) and arch_val.strip():
        return [arch_val.strip()]

    return []


def get_oses_from_entry(entry: Dict) -> List[str]:
    """Normalise OS configuration from a config ``entry``.

    Looks for ``container.os`` (string or list). Returns a list of
    non-empty strings that can be passed to skopeo ``--override-os``.
    """

    container = entry.get("container") or {}
    os_val = container.get("os")

    if isinstance(os_val, list):
        return [str(o) for o in os_val if isinstance(o, str) and o]

    if isinstance(os_val, str) and os_val.strip():
        return [os_val.strip()]

    return []


def inspect_metadata(
    repo: str,
    tag: str,
    arches: Optional[List[str]] = None,
    oses: Optional[List[str]] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """Return (release_date_iso, sunset_date_iso) using skopeo metadata.

    Prefer the image config's Created timestamp. If the multi-arch manifest
    lacks Created (common for manifest lists), optionally fall back to an
    arch-specific inspect via :func:`inspect_tag_for_arches` when ``arches``
    are provided so that we still derive a stable release_date from the
    underlying image manifest.
    """

    try:
        proc = subprocess.run(
            ["skopeo", "inspect", f"docker://{repo}:{tag}"],
            check=False,
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        print(
            "ERROR: skopeo not found on PATH; cannot inspect images for metadata",
            file=sys.stderr,
        )
        return None, None

    if proc.returncode != 0:
        msg = proc.stderr.strip() or proc.stdout.strip()
        print(
            f"[WARN] skopeo inspect for metadata failed for {repo}:{tag} (rc={proc.returncode}): {msg[:200]}",
            file=sys.stderr,
        )
        return None, None

    try:
        data = json.loads(proc.stdout or "{}")
    except json.JSONDecodeError as exc:
        print(
            f"[WARN] Failed to parse inspect metadata output for {repo}:{tag}: {exc}",
            file=sys.stderr,
        )
        return None, None

    created_raw = data.get("Created") or data.get("created")
    created_dt = _parse_created_iso(created_raw)
    release_date: Optional[str] = None
    if created_dt is not None:
        release_date = created_dt.strftime("%Y-%m-%dT%H:%M:%SZ")

    labels = data.get("Labels") or data.get("labels") or {}
    sunset_date: Optional[str] = None
    if isinstance(labels, dict):
        for key in (
            "vendor.eol",
            "maintainer.eol",
            "org.opencontainers.image.endoflife",
        ):
            val = labels.get(key)
            if not isinstance(val, str):
                continue
            v = val.strip()
            if re.match(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$", v):
                sunset_date = f"{v}T00:00:00Z"
                break

        if sunset_date is None:
            for k, v in labels.items():
                if not isinstance(k, str) or not isinstance(v, str):
                    continue
                if not re.search(r"eol|sunset", k, re.IGNORECASE):
                    continue
                vv = v.strip()
                if re.match(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$", vv):
                    sunset_date = f"{vv}T00:00:00Z"
                    break

    # If we still do not have a Created timestamp (e.g. manifest list with
    # no top-level Created field) but architectures/OS are known, fall back
    # to a constrained inspect so we can derive a consistent release_date
    # and sunset_date instead of leaving them empty.
    if created_dt is None and (arches or oses):
        ok, created_arch = inspect_tag_for_arches(repo, tag, arches or [], oses or [])
        if ok and created_arch is not None:
            created_dt = created_arch
            created_dt = created_dt.replace(microsecond=0)
            release_date = created_dt.strftime("%Y-%m-%dT%H:%M:%SZ")

    if sunset_date is None and created_dt is not None:
        try:
            eol_dt = created_dt + timedelta(days=730)
            eol_dt = eol_dt.replace(hour=0, minute=0, second=0, microsecond=0)
            sunset_date = eol_dt.strftime("%Y-%m-%dT00:00:00Z")
        except Exception:
            sunset_date = None

    return release_date, sunset_date


def discover_for_entry(entry: Dict) -> Dict:
    """Discover the best tag for a single config entry lacking ``tag``."""

    provider = entry.get("provider", "")
    software = entry.get("software") or ""
    architectures = get_architectures_from_entry(entry)
    oses = get_oses_from_entry(entry)

    # Normalised set of allowed architectures from config; used to
    # cross-check against any explicit arch tokens in tag names.
    allowed_arches = {_normalise_arch_name(a) for a in architectures}

    repo = build_repo_from_entry(entry)
    if not repo:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": None,
            "reason": "missing repo parts (base_registry/source_path/software)",
        }

    print(
        f"[INFO] Discovering tags for {repo} (provider={provider}, software={software})",
        file=sys.stderr,
    )
    tags = run_skopeo_list_tags(repo)
    if not tags:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": None,
            "reason": "no tags returned by skopeo list-tags",
        }

    cutoff = parse_min_date(entry.get("min_date"))

    # First preference: plain major tags (e.g. "3", "25").
    # Second preference: other GA numeric tags (e.g. "3.13", "2.32.18").
    # We explicitly ignore non-numeric tags and any tag literally named
    # "latest" so that discovery never relies on mutable aliases.

    plain_major_tags: List[str] = []
    ga_numeric_tags: List[str] = []

    for t in tags:
        # If the config specifies one or more architectures *and* the tag
        # name explicitly encodes an architecture, require that any such
        # encoded arches are a subset of the configured ones. This ensures
        # we don't accidentally select tags clearly targeted at a different
        # arch (e.g. "*-arm64" when only amd64 is configured).
        tag_arches = set(_infer_arches_from_tag(t))
        if architectures and tag_arches and not tag_arches.issubset(allowed_arches):
            continue
        if EXCLUDE_PATTERN.search(t):
            continue
        if t.lower() == "latest":
            continue

        # Plain major GA tag: single numeric component only (e.g. "3", "25").
        if re.match(r"^[0-9]+$", t):
            plain_major_tags.append(t)
            ga_numeric_tags.append(t)
            continue

        # General GA numeric tag: up to three numeric components separated by
        # dots, with no additional suffix (e.g. "3.13", "2.32.18").
        if re.match(r"^[0-9]+(\.[0-9]+){0,2}$", t):
            ga_numeric_tags.append(t)

    def select_best_from_tags(candidates: List[str], scope: str) -> Tuple[Optional[str], Optional[str]]:
        if not candidates:
            return None, None

        cores: Dict[str, List[str]] = {}
        for tag in candidates:
            m = re.match(r"^([0-9]+(\.[0-9]+){0,2})", tag)
            if not m:
                continue
            core = m.group(1)
            cores.setdefault(core, []).append(tag)

        if not cores:
            return None, f"numeric {scope} tags found but could not derive core versions"

        def core_key(core: str) -> tuple:
            parts = [int(p) for p in core.split(".")]
            while len(parts) < 3:
                parts.append(0)
            return tuple(parts)

        def pick_tag(ignore_min_date: bool) -> Optional[str]:
            for core in sorted(cores.keys(), key=core_key, reverse=True):
                candidates_sorted = sorted(cores[core])
                for tag in reversed(candidates_sorted):
                    ok, created = inspect_tag_for_arches(repo, tag, architectures, oses)
                    if not ok:
                        continue
                    if not ignore_min_date and cutoff and created and created < cutoff:
                        continue
                    return tag
            return None

        best_tag = pick_tag(ignore_min_date=False)
        if best_tag is not None:
            return best_tag, f"ok ({scope})"

        if cutoff is not None:
            best_tag = pick_tag(ignore_min_date=True)
            if best_tag is not None:
                return best_tag, f"ok ({scope}; min_date ignored; no tag satisfied cutoff)"

        return None, None

    # 1) Prefer plain major GA tags (e.g. "3", "25").
    best, reason = select_best_from_tags(plain_major_tags, "plain major tag preference")
    if best is not None:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": best,
            "reason": reason or "ok (plain major tag preference)",
        }

    # 2) Fallback to other GA numeric tags (e.g. "3.13", "2.32.18").
    best, reason = select_best_from_tags(ga_numeric_tags, "GA numeric tag fallback")
    if best is not None:
        return {
            "provider": provider,
            "software": software,
            "repo": repo,
            "best_tag": best,
            "reason": reason or "ok (GA numeric tag fallback)",
        }

    # 3) No suitable numeric GA tags available.
    return {
        "provider": provider,
        "software": software,
        "repo": repo,
        "best_tag": None,
        "reason": "no plain major or GA numeric tags available that satisfy architecture/min_date constraints",
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Discover tags and metadata for Amazon ECR Public config entries"
        )
    )
    parser.add_argument(
        "--config",
        required=True,
        help="Path to amazon-catalog-container-config.json",
    )
    args = parser.parse_args()

    try:
        with open(args.config, "r", encoding="utf-8") as f:
            config = json.load(f)
    except FileNotFoundError:
        print(f"ERROR: Config file not found: {args.config}", file=sys.stderr)
        return 1
    except json.JSONDecodeError as exc:
        print(f"ERROR: Failed to parse JSON from {args.config}: {exc}", file=sys.stderr)
        return 1

    if not isinstance(config, list):
        print("ERROR: Config JSON is not a list of entries", file=sys.stderr)
        return 1

    results: List[Dict] = []
    for idx, entry in enumerate(config):
        provider = entry.get("provider", "")
        software = entry.get("software") or ""

        # Normalize architecture list once per entry so both tag discovery
        # and metadata enrichment share the same view of required arches/OS.
        architectures = get_architectures_from_entry(entry)
        oses = get_oses_from_entry(entry)

        repo = build_repo_from_entry(entry)

        if not repo:
            results.append(
                {
                    "index": idx,
                    "provider": provider,
                    "software": software,
                    "repo": repo,
                    "best_tag": None,
                    "tag": None,
                    "digest": None,
                    "release_date": None,
                    "sunset_date": None,
                    "reason": "missing repo parts (base_registry/source_path/software)",
                }
            )
            continue

        raw_tag = entry.get("tag")
        explicit_tag: Optional[str] = None
        if isinstance(raw_tag, str) and raw_tag.strip():
            explicit_tag = raw_tag.strip()

        best_tag: Optional[str] = None
        reason: str = ""
        discovered = False

        if explicit_tag is not None:
            best_tag = explicit_tag
            reason = "explicit tag from config"
        else:
            res = discover_for_entry(entry)
            best_tag = res.get("best_tag")
            reason = res.get("reason", "")
            discovered = best_tag is not None

        digest: Optional[str] = None
        release_date: Optional[str] = None
        sunset_date: Optional[str] = None
        if best_tag is not None:
            rd, sd = inspect_metadata(repo, best_tag, architectures, oses)
            release_date, sunset_date = rd, sd

        results.append(
            {
                "index": idx,
                "provider": provider,
                "software": software,
                "repo": repo,
                "best_tag": best_tag if discovered else None,
                "tag": best_tag,
                "digest": digest,
                "release_date": release_date,
                "sunset_date": sunset_date,
                "reason": reason,
            }
        )

    print(json.dumps(results, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
