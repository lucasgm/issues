#!/usr/bin/env python3
"""Discover Microsoft container images for the lifecycle workflow.

This script reads configuration from ``filtered-images.json`` and writes a
normalized list of candidate images (with OS and basic metadata) to
``all-images.json``. It is designed for use in CI and keeps dependencies
minimal (standard library + ``skopeo`` CLI).
"""

import json
import re
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Set, Tuple


FILTERED_IMAGES = Path("filtered-images.json")

# Common tag qualifiers treated as non-GA / pre-release.
_PRERELEASE_MARKERS: Tuple[str, ...] = (
    "beta",
    "alpha",
    "rc",
    "preview",
    "tech-preview",
    "snapshot",
    "nightly",
)

# Tag patterns considered "supported" for Microsoft images (semantic-style
# versions and common Windows flavors).
_SUPPORTED_TAG_PATTERN = re.compile(
    r"(^[0-9]+\.[0-9]+(\.[0-9]+)?([-.](windowsservercore-ltsc[0-9]+|nanoserver-ltsc[0-9]+))?$)"
)

# Heuristics to classify Windows images based on repo/tag.
_WINDOWS_INDICATORS: Tuple[str, ...] = (
    "nanoserver",
    "windowsservercore",
    "windows/servercore",
    "dotnet/framework",
)


def run(cmd: List[str]) -> str:
    try:
        return subprocess.check_output(cmd, stderr=subprocess.DEVNULL, text=True)
    except subprocess.CalledProcessError:
        return ""


def parse_created_ts(created: str) -> Optional[datetime]:
    if not created or created == "null":
        return None
    try:
        if "." in created and created.endswith("Z"):
            base, rest = created.split(".", 1)
            frac = rest.rstrip("Z")[:6]
            created = f"{base}.{frac}Z"
        return datetime.fromisoformat(created.replace("Z", "+00:00"))
    except Exception:
        return None


def classify_os(entry: Dict, repo: str, tag: str) -> str:
    container = entry.get("container") or {}
    os_field = container.get("os")
    if isinstance(os_field, list) and len(os_field) == 1:
        val = str(os_field[0]).lower().strip()
        if val in {"linux", "windows"}:
            return val
    elif isinstance(os_field, str):
        val = os_field.lower().strip()
        if val in {"linux", "windows"}:
            return val

    repo_lower = (repo or "").lower()
    tag_lower = (tag or "").lower()

    if any(ind in tag_lower for ind in _WINDOWS_INDICATORS) or any(
        ind in repo_lower for ind in _WINDOWS_INDICATORS
    ):
        return "windows"
    return "linux"


def get_architecture_filter(entry: Dict) -> Optional[str]:
    container = entry.get("container") or {}
    arch_field = container.get("architecture")

    def _norm(val: str) -> str:
        v = (val or "").lower().strip()
        if v in {"x86_64", "x86-64", "amd64"}:
            return "amd64"
        if v in {"arm64", "aarch64"}:
            return "arm64"
        return v

    if isinstance(arch_field, list) and len(arch_field) == 1:
        return _norm(str(arch_field[0])) or None
    if isinstance(arch_field, str):
        return _norm(arch_field) or None
    return None


def tag_matches_arch(tag: str, arch: Optional[str]) -> bool:
    if not arch:
        return True
    t = (tag or "").lower()
    if arch == "amd64":
        if any(s in t for s in ["-arm64", "arm64-", "_arm64", "arm64v8", "-armv7", "-arm32", "-arm"]):
            return False
        return True
    if arch == "arm64":
        if any(s in t for s in ["-amd64", "amd64-", "_amd64"]):
            return False
        return True
    return True


def inspect_manifest(repo: str, tag: str) -> Dict:
    out = run(["skopeo", "inspect", f"docker://{repo}:{tag}"])
    if not out:
        return {}
    try:
        return json.loads(out)
    except Exception:
        return {}


def detect_platforms_from_data(data: Dict) -> Tuple[bool, bool]:
    platforms = (
        data.get("ManifestList", {}).get("manifests")
        or data.get("manifests")
        or []
    )
    has_linux = False
    has_windows = False
    for m in platforms:
        plat = m.get("platform") or {}
        os_val = (plat.get("os") or "").lower()
        arch_val = (plat.get("architecture") or "").lower()
        if os_val == "linux" and arch_val == "amd64":
            has_linux = True
        if os_val == "windows" and arch_val == "amd64":
            has_windows = True
    if not platforms:
        os_val = (data.get("Os") or data.get("os") or "").lower()
        arch_val = (data.get("Architecture") or data.get("architecture") or "").lower()
        if os_val and arch_val:
            has_linux = os_val == "linux" and arch_val == "amd64"
            has_windows = os_val == "windows" and arch_val == "amd64"
            return has_linux, has_windows
        return True, True
    return has_linux, has_windows


def detect_platforms(repo: str, tag: str) -> Tuple[bool, bool]:
    data = inspect_manifest(repo, tag)
    if not data:
        return True, True
    return detect_platforms_from_data(data)


def compute_cutoff(min_date: Optional[str]) -> datetime:
    now = datetime.now(timezone.utc)
    if isinstance(min_date, str) and "month" in min_date:
        try:
            num = int(min_date.split()[0])
            return now - timedelta(days=30 * num)
        except Exception:
            pass
    return now - timedelta(days=180)


def append_image(
    all_images: List[Dict],
    provider_images: Dict[str, List[str]],
    provider_key: str,
    provider: str,
    software: str,
    repo: str,
    tag: str,
    os_val: str,
    manifest: Optional[Dict],
) -> None:
    full_ref = f"{repo}:{tag}"
    created_meta = manifest.get("Created") if manifest else None
    provider_images[provider_key].append(full_ref)
    all_images.append(
        {
            "image": full_ref,
            "os": os_val,
            "provider": provider,
            "software": software,
            "created": created_meta,
        }
    )


def _is_ga_tag(tag: str) -> bool:
    """Return True if ``tag`` looks like a GA (non-preview) tag."""

    lower = tag.lower()
    if lower == "latest":
        return False
    return not any(marker in lower for marker in _PRERELEASE_MARKERS)


def _filter_supported_tags(tags: Iterable[str]) -> List[str]:
    """Filter raw tags down to a stable, supported subset.

    Preference order:
    1. GA tags matching ``_SUPPORTED_TAG_PATTERN``; if none exist,
       fall back to all GA tags.
    2. Within that subset, callers can apply additional architecture
       and date-based filtering.
    """

    tags_list = list(tags)
    ga_tags = [t for t in tags_list if _is_ga_tag(t)]
    if not ga_tags:
        # Fall back to everything except "latest" to avoid an empty set.
        return [t for t in tags_list if t.lower() != "latest"]

    supported = [t for t in ga_tags if _SUPPORTED_TAG_PATTERN.search(t)]
    return supported or ga_tags


def main() -> int:
    if not FILTERED_IMAGES.exists():
        print("filtered-images.json not found!", file=sys.stderr)
        return 1

    data = json.loads(FILTERED_IMAGES.read_text())
    print(f"Processing {len(data)} Microsoft config entries")

    provider_images: Dict[str, List[str]] = {}
    all_images: List[Dict] = []

    for entry in data:
        provider = entry.get("provider", "microsoft")
        base_registry = entry.get("base_registry", "").rstrip("/")
        software = entry.get("software", "")
        source_path = (entry.get("source_path") or "").lstrip("/")
        min_date = entry.get("min_date")
        forced_tag = entry.get("tag") or ""

        repo_path = source_path or software
        repo = f"{base_registry}/{repo_path}" if repo_path else base_registry

        print(f"Evaluating repo: {repo} (forced_tag={forced_tag or '<none>'})")
        arch_filter = get_architecture_filter(entry)
        if arch_filter:
            print(f"  Architecture filter: {arch_filter}")

        provider_key = provider.replace(" ", "_") or "microsoft"
        provider_images.setdefault(provider_key, [])

        if forced_tag:
            manifest = inspect_manifest(repo, forced_tag)
            has_linux, has_windows = detect_platforms_from_data(manifest) if manifest else (True, True)
            # Respect explicit container.os config — override manifest-detected platforms.
            config_os = classify_os(entry, repo, forced_tag)
            if config_os == "linux":
                has_windows = False
            elif config_os == "windows":
                has_linux = False
            if has_linux:
                append_image(
                    all_images,
                    provider_images,
                    provider_key,
                    provider,
                    software,
                    repo,
                    forced_tag,
                    "linux",
                    manifest,
                )
            if has_windows:
                append_image(
                    all_images,
                    provider_images,
                    provider_key,
                    provider,
                    software,
                    repo,
                    forced_tag,
                    "windows",
                    manifest,
                )
            continue

        tags_raw = run(["skopeo", "list-tags", f"docker://{repo}"])
        if not tags_raw:
            print(f"  No tags returned for {repo}")
            continue
        try:
            tags = json.loads(tags_raw).get("Tags", [])
        except Exception:
            tags = []
        if not tags:
            print(f"  Empty tag list for {repo}")
            continue

        supported_tags = _filter_supported_tags(tags)
        if not supported_tags:
            # This should be rare, but avoids surprising empty behavior.
            print("  No supported tags after filtering; using raw tag list")
            supported_tags = tags

        if arch_filter:
            before = len(supported_tags)
            supported_tags = [t for t in supported_tags if tag_matches_arch(t, arch_filter)]
            after = len(supported_tags)
            print(f"  Arch filter {arch_filter}: {before} -> {after}")

        candidate_limit_raw = entry.get("MICROSOFT_TAG_CANDIDATE_LIMIT", 20)
        try:
            candidate_limit = int(candidate_limit_raw)
        except Exception:
            candidate_limit = 20
        if candidate_limit <= 0:
            candidate_limit = 20
        candidates = sorted(supported_tags)[-candidate_limit:]

        cutoff = compute_cutoff(min_date)
        print(f"  Cutoff for {repo}: {cutoff.isoformat()} (min_date={min_date})")

        tag_manifests: Dict[str, Dict] = {}
        tag_timestamps: Dict[str, Optional[datetime]] = {}
        recent_tags: List[str] = []
        for t in candidates:
            if not t:
                continue
            manifest = inspect_manifest(repo, t)
            tag_manifests[t] = manifest
            created = manifest.get("Created") if manifest else None
            ts = parse_created_ts(created) if created else None
            tag_timestamps[t] = ts
            if ts is None:
                if min_date:
                    print(f"    {t}: Created missing/unparsable, treating as outside min_date window")
                else:
                    print(f"    {t}: Created missing/unparsable, including (no min_date)")
                    recent_tags.append(t)
                continue
            if ts >= cutoff:
                print(f"    {t}: {created} within window")
                recent_tags.append(t)
            else:
                print(f"    {t}: {created} older than window, outside min_date")

        if not recent_tags:
            print("  No tags within min_date window for repo; falling back to all stable tags regardless of min_date")
            recent_tags = list(candidates)

        # Determine the default OS for this repo once, primarily from
        # the configuration's container.os field (falling back to repo
        # heuristics).
        repo_os_default = classify_os(entry, repo, "")

        if recent_tags:
            # De-dup and sort candidate tags first.
            recent_tags = sorted({t for t in recent_tags if t})

            # Prefer LTS for .NET repos when both LTS and Standard
            # support tags exist. For .NET, even-numbered major
            # versions are LTS and odd-numbered majors are STS. We
            # therefore restrict to the highest even-major line when
            # possible, while leaving other repos unchanged.
            if "mcr.microsoft.com/dotnet/" in repo:
                lts_candidates: List[str] = []
                for t in recent_tags:
                    m = re.match(r"^([0-9]+)\.", t)
                    if not m:
                        continue
                    try:
                        major = int(m.group(1))
                    except ValueError:
                        continue
                    if major % 2 == 0:
                        lts_candidates.append(t)

                if lts_candidates:
                    recent_tags = sorted({t for t in lts_candidates if t})
                    print(
                        "  .NET repo: restricting to LTS (even-major) tag(s); "
                        f"remaining candidates: {recent_tags}"
                    )

            # Now apply the single selection rule: choose the latest
            # stable tag *that actually has* the requested OS
            # (container.os from config) on amd64. This avoids picking
            # a Linux-only tag for a Windows repo (or vice versa).
            os_matched: List[str] = []
            for t in recent_tags:
                manifest = tag_manifests.get(t) or inspect_manifest(repo, t)
                tag_manifests[t] = manifest
                has_linux, has_windows = (
                    detect_platforms_from_data(manifest) if manifest else (True, True)
                )

                if repo_os_default == "windows" and has_windows:
                    os_matched.append(t)
                elif repo_os_default == "linux" and has_linux:
                    os_matched.append(t)
                elif repo_os_default not in {"linux", "windows"} and (has_linux or has_windows):
                    os_matched.append(t)

            if not os_matched:
                print(
                    "  No tags with matching OS/platform after filtering; "
                    "skipping repo"
                )
                continue

            latest_tag: Optional[str] = None
            latest_ts: Optional[datetime] = None
            for t in os_matched:
                ts = tag_timestamps.get(t)
                if ts is None:
                    continue
                if latest_ts is None or ts > latest_ts:
                    latest_ts = ts
                    latest_tag = t

            if latest_tag is None:
                # All timestamps missing/unparsable; use highest
                # lexicographic tag as a deterministic fallback.
                latest_tag = sorted(set(os_matched))[-1]

            if not latest_tag:
                print("  No suitable latest tag found after OS filtering; skipping repo")
                continue

            recent_tags = [latest_tag]
            print(
                "  Latest tag selected for OS="
                + (repo_os_default or "unknown")
                + " platform: "
                + latest_tag
            )

        selected_for_repo: List[Tuple[str, str]] = []

        for t in sorted(set(recent_tags)):
            manifest = tag_manifests.get(t) or inspect_manifest(repo, t)
            has_linux, has_windows = (
                detect_platforms_from_data(manifest) if manifest else (True, True)
            )

            if repo_os_default == "windows":
                if has_windows:
                    selected_for_repo.append((t, "windows"))
                else:
                    print(f"  {t}: no Windows platform on amd64; skipping")
                continue

            if repo_os_default == "linux":
                if has_linux:
                    selected_for_repo.append((t, "linux"))
                else:
                    print(f"  {t}: no Linux platform on amd64; skipping")
                continue

            # Fallback when OS isn't clearly specified: keep any
            # supported platforms the manifest advertises.
            if has_linux:
                selected_for_repo.append((t, "linux"))
            if has_windows:
                selected_for_repo.append((t, "windows"))

        if not selected_for_repo:
            print("  No tags selected after platform detection; skipping repo")
            continue

        for sel, os_hint in selected_for_repo:
            os_val = os_hint or repo_os_default or "linux"
            manifest = tag_manifests.get(sel) or inspect_manifest(repo, sel)
            append_image(
                all_images,
                provider_images,
                provider_key,
                provider,
                software,
                repo,
                sel,
                os_val,
                manifest,
            )

    for key, images in provider_images.items():
        unique_sorted = sorted(set(i for i in images if i))
        out = Path(f"{key}.json")
        out.write_text(json.dumps(unique_sorted, indent=2))
        print(f"{key}.json: {len(unique_sorted)} images")

    registries: Set[str] = {
        e.get("base_registry", "").rstrip("/")
        for e in data
        if e.get("base_registry")
    }
    filtered_all: List[Dict] = []
    seen: Set[str] = set()
    for item in all_images:
        img = item.get("image") or ""
        if not img:
            continue
        if registries and not any(img.startswith(f"{reg}/") for reg in registries):
            continue
        if img in seen:
            continue
        seen.add(img)
        filtered_all.append(item)

    Path("all-images.json").write_text(json.dumps(filtered_all, indent=2))
    print("All Microsoft images (with os metadata):")
    print(json.dumps(filtered_all, indent=2))
    print(f"Total images discovered: {len(filtered_all)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())