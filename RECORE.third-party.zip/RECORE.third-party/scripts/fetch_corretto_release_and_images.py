import os
import json
from pathlib import Path

# --- Ensure scrape_html_for_urls is defined ---
def scrape_html_for_urls(session, release_url):
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        import sys, subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "beautifulsoup4"])
        from bs4 import BeautifulSoup
    html_resp = session.get(release_url, timeout=30)
    soup = BeautifulSoup(html_resp.text, "html.parser")
    urls = []
    for a in soup.find_all("a", href=True):
        href = a["href"]
        if href.endswith("windows-x64-jdk.msi") or href.endswith("1-windows-x64.msi") or href.endswith("x86_64.rpm"):
            if href.startswith("/corretto/"):
                href = f"https://github.com{href}"
            urls.append(href)
    return urls

# --- Ensure get_download_urls is defined ---
def get_download_urls(assets):
    return [a.get("browser_download_url") for a in assets if a.get("browser_download_url") and (
        a.get("browser_download_url").endswith("-windows-x64-jdk.msi") or
        a.get("browser_download_url").endswith("1-windows-x64.msi") or
        a.get("browser_download_url").endswith("x86_64.rpm")
    )]

# --- Global constants ---
ORG = "corretto"

def get_corretto_repos(session):
    """
    Fetch all repo names in the 'corretto' org that start with 'corretto-'.
    Returns: list of repo names
    """
    repos = []
    page = 1
    while True:
        url = f"https://api.github.com/orgs/corretto/repos"
        resp = session.get(url, params={"per_page": 100, "page": page}, timeout=30)
        if resp.status_code != 200:
            print(f"Warning: org/corretto/repos -> HTTP {resp.status_code}: {resp.text[:200]}")
            break
        data = resp.json()
        if not data:
            break
        repos += [r['name'] for r in data if r['name'].startswith('corretto-')]
        if len(data) < 100:
            break
        page += 1
    return repos
import datetime
CUTOFF = (datetime.datetime.now(datetime.UTC) - datetime.timedelta(days=365)).replace(tzinfo=None)

# --- Ensure get_github_session is defined ---
def get_github_session():
    import requests
    import os
    session = requests.Session()
    token = os.environ.get("GITHUB_TOKEN")
    if token:
        session.headers["Authorization"] = f"Bearer {token}"
    session.headers["Accept"] = "application/vnd.github+json"
    return session

# Utility to write JSON report
def write_json_report(path, releases):
    json_str = json.dumps({
        "generated_utc": datetime.datetime.now(datetime.UTC).isoformat().replace("+00:00","Z"),
        "cutoff_utc": CUTOFF.isoformat() + "Z",
        "count": len(releases),
        "releases": releases
    }, indent=2)
    # Post-process to put tags array on a single line
    import re
    # Ensure tags array is a single line with quoted, comma-separated values
    json_str = re.sub(
        r'("tags": )\[(.*?)\]',
        lambda m: m.group(1) + '[' + ', '.join(
            [x.strip() for x in m.group(2).split(',') if x.strip()]
        ) + ']',
        json_str,
        flags=re.DOTALL
    )
    path.write_text(json_str)

def build_release_metadata(repo, rel, download_urls):
    major = repo.split("-")[-1]
    image_refs = [f"public.ecr.aws/amazoncorretto/amazoncorretto:{major}"]
    version = rel.get("tag_name")
    pub = rel.get("published_at")
    try:
        sunset_dt = datetime.datetime.fromisoformat(pub.replace("Z", "+00:00")) + datetime.timedelta(days=365)
        sunset_date = sunset_dt.strftime("%Y-%m-%d")
    except Exception:
        sunset_date = None
    now_dt = datetime.datetime.now(datetime.UTC)
    status = "active" if sunset_date and sunset_dt > now_dt else "deprecated" if sunset_date and sunset_dt <= now_dt else "unknown"
    name_val = f"Amazon Corretto {major}"
    try:
        release_date_fmt = datetime.datetime.fromisoformat(pub.replace("Z", "+00:00")).strftime("%Y-%m-%d")
    except Exception:
        release_date_fmt = pub
    # Fallback: if org is 'corretto', vendor is 'Amazon' unless otherwise detected
    org_vendor_map = {"corretto": "Amazon"}
    vendor_val = "Amazon" if any("amazon" in url.lower() for url in download_urls) or (rel.get("name") and "amazon" in rel.get("name").lower()) else org_vendor_map.get(ORG, "Unknown")
    # platforms = []
    # linux_urls = [url for url in download_urls if "linux" in url or url.endswith(".rpm")]
    # if linux_urls:
    #     distro_val = "rhel" if any("rhel" in url or "rpm" in url for url in linux_urls) else "unknown"
    #     distro_versions_val = ["8", "9"] if distro_val == "rhel" else []
    #     arch_val = [arch for arch in ["x86_64", "aarch64"] if any(arch in url for url in linux_urls)] or ["unknown"]
    #     platforms.append({"os": "linux", "distro": distro_val, "distro_versions": distro_versions_val, "arch": arch_val})
    # windows_urls = [url for url in download_urls if "windows" in url or url.endswith(".msi")]
    # if windows_urls:
    #     arch_val = ["x86_64"] if any("x86_64" in url or "x64" in url for url in windows_urls) else ["unknown"]
    #     platforms.append({"os": "windows", "distro": "windows", "distro_versions": [], "arch": arch_val})
    # if not platforms:
    #     platforms = [{"os": "unknown", "distro": "unknown", "distro_versions": [], "arch": ["unknown"]}]

    #description_val = f"Amazon Corretto {version} OpenJDK distribution for {', '.join([p['os'] for p in platforms if p['os'] != 'unknown'])}" if platforms else f"Amazon Corretto {version} OpenJDK distribution"
    description_val = f"Amazon Corretto {version} OpenJDK distribution"
    homepage_val = "https://aws.amazon.com/corretto/"
    license_val = "GPLv2 with Classpath Exception"
    license_url_val = "https://openjdk.java.net/legal/gplv2+ce.html"
    gpg_key_id_val = "A2C2A6D5"
    signature_url_val = f"https://corretto.aws/downloads/resources/{version}/amazon-corretto-signature.asc"
    verification_val = {
        "checksum": {"sha256": ""},
        "signature": {"gpg_key_id": gpg_key_id_val, "signature_url": signature_url_val}
    }
    source_val = {
        "homepage": homepage_val,
        "license": license_val,
        "license_url": license_url_val,
        "verification": verification_val
    }
    # --- Generate tags for filtering/search ---
    tags = set()
    # Add major version
    if major:
        tags.add(major)
    # Add vendor
    if vendor_val:
        tags.add(vendor_val.lower())
    # Add status
    if status:
        tags.add(status)
    # Add release year
    if release_date_fmt and len(release_date_fmt) >= 4:
        tags.add(release_date_fmt[:4])
    # Add platform/os/distro/arch
    #for p in platforms:
        #if p.get("os"):
            #tags.add(p["os"])
        #if p.get("distro"):
            #tags.add(p["distro"])
        #for v in p.get("distro_versions", []):
            #tags.add(v)
        #for a in p.get("arch", []):
            #tags.add(a)
    # Add package type
    for url in download_urls:
        if url.endswith(".rpm"):
            tags.add("rpm")
        if url.endswith(".msi"):
            tags.add("msi")
    # Add container tag if image_refs present
    if image_refs:
        tags.add("container")
    # Add generic tags
    tags.add("jdk")
    tags.add("openjdk")
    tags.add("corretto")
    return {
        "name": name_val,
        "version": version,
        "vendor": vendor_val,
        "description": description_val,
        "html_url": rel.get("html_url"),
        "status": status,
        "release_date": release_date_fmt,
        "sunset_date": sunset_date,
        "download_urls": download_urls,
        "container_images": image_refs,
        #"platform": platforms,
        "source": source_val,
        "tags": sorted(tags)
    }

def fetch_releases():
    all_releases = []
    session = get_github_session()
    REPOS = get_corretto_repos(session)
    for repo in REPOS:
        page = 1
        while True:
            url = f"https://api.github.com/repos/{ORG}/{repo}/releases"
            resp = session.get(url, params={"per_page": 100, "page": page}, timeout=30)
            if resp.status_code != 200:
                print(f"Warning: {repo} -> HTTP {resp.status_code}: {resp.text[:200]}")
                break
            releases = resp.json()
            if not releases:
                break
            for rel in releases:
                # Only process released versions (skip drafts and pre-releases)
                if rel.get("draft") or rel.get("prerelease"):
                    continue
                pub = rel.get("published_at")
                if not pub:
                    continue
                # Defensive: skip if tag_name is missing or empty
                if not rel.get("tag_name"):
                    continue
                pub_dt = datetime.datetime.fromisoformat(pub.replace("Z","+00:00")).replace(tzinfo=None)
                if pub_dt < CUTOFF:
                    break
                assets = rel.get("assets", [])
                download_urls = get_download_urls(assets)
                if not download_urls:
                    download_urls = scrape_html_for_urls(session, rel.get("html_url"))
                all_releases.append(build_release_metadata(repo, rel, download_urls))
            page += 1
    return all_releases

def filter_and_cleanup(releases, ext, platform_os=None):
    filtered = [r.copy() for r in releases if any(url.endswith(ext) for url in r['download_urls'])]
    for r in filtered:
        r['download_urls'] = [url for url in r['download_urls'] if url.endswith(ext)]
        #if platform_os:
            #r['platform'] = [p for p in r.get('platform', []) if p.get('os') == platform_os]
        if 'container_images' in r:
            del r['container_images']
        if isinstance(r['download_urls'], list) and len(r['download_urls']) == 1:
            r['download_urls'] = r['download_urls'][0]
        elif not r['download_urls']:
            r['download_urls'] = ""
    return filtered

def cleanup_container_releases(releases):
    filtered = [r.copy() for r in releases if r['container_images']]
    for r in filtered:
        if 'download_urls' in r:
            del r['download_urls']
        if 'platform' in r:
            del r['platform']        
    return filtered

def main():
    all_releases = fetch_releases()
    # Extract org name from the API URL
    import re
    api_url = f"https://api.github.com/orgs/{ORG}/repos"
    org_match = re.search(r'/orgs/([^/]+)/repos', api_url)
    org_name = org_match.group(1) if org_match else ORG
    runnerid = os.environ.get("GITHUB_RUN_ID", "local")
    out_dir = Path(f"release-report-{runnerid}")
    out_dir.mkdir(exist_ok=True)
    # Delete all files in release-report before generating new ones
    for f in out_dir.glob("*"):
        if f.is_file():
            f.unlink()
    # Combined JSON
    write_json_report(out_dir / "corretto-combined-last-6-months.json", all_releases)
    # Combine all rpm, msi, and container results into a single JSON file
    rpm_releases = filter_and_cleanup(all_releases, '.rpm', platform_os='linux')
    msi_releases = filter_and_cleanup(all_releases, '.msi', platform_os='windows')
    container_releases = cleanup_container_releases(all_releases)
    combined_all = []
    # Build a lookup for RPM and MSI by version
    rpm_by_version = {r['version']: r for r in rpm_releases}
    msi_by_version = {m['version']: m for m in msi_releases}
    # Combine entries by version
    all_versions = set(rpm_by_version.keys()) | set(msi_by_version.keys())
    for version in all_versions:
        entry = {}
        # Merge RPM and MSI metadata
        if version in rpm_by_version:
            rpm_entry = rpm_by_version[version].copy()
            rpm_entry.pop('download_urls', None)
            entry.update(rpm_entry)
            entry['rpm_download_url'] = rpm_by_version[version].get('download_urls', '')
        if version in msi_by_version:
            msi_entry = msi_by_version[version].copy()
            msi_entry.pop('download_urls', None)
            entry.update(msi_entry)
            entry['msi_download_url'] = msi_by_version[version].get('download_urls', '')
        # Attach container images for this version if available
        containers_for_version = [c for c in container_releases if c.get('version') == version]
        if containers_for_version:
            images = containers_for_version[0].get('container_images', [])
            entry['container_image'] = images[0] if isinstance(images, list) and images else images if isinstance(images, str) else ""
        # Future-proof: add new package types here
        # Example: entry['deb_download_url'] = ...
        # Example: entry['tar_download_url'] = ...
        # Set type field to reflect all present types
        types = []
        if version in rpm_by_version:
            types.append('rpm')
        if version in msi_by_version:
            types.append('msi')
        if containers_for_version:
            types.append('container')
        entry['type'] = '-'.join(types)
        combined_all.append(entry)
    # Add Container entries (not version-merged)
    for container in container_releases:
        entry = container.copy()
        entry.pop('download_urls', None)
        images = entry.get('container_images', [])
        entry['container_image'] = images[0] if isinstance(images, list) and images else images if isinstance(images, str) else ""
        entry.pop('container_images', None)
        entry['type'] = 'container'
        combined_all.append(entry)
    # Deduplicate combined_all by (name, version)
    seen = set()
    deduped_combined = []
    for entry in combined_all:
        key = (entry.get('name'), entry.get('version'))
        if key not in seen:
            deduped_combined.append(entry)
            seen.add(key)
    # Filter deduped_combined to only include approved (active) releases
    approved_combined = [entry for entry in deduped_combined if entry.get('status') == 'active']
    # Group approved_combined by vendor and write separate JSON files
    from collections import defaultdict
    vendor_groups = defaultdict(list)
    for entry in approved_combined:
        vendor = entry.get('vendor', 'Unknown').replace(' ', '_').lower()
        vendor_groups[vendor].append(entry)
    for vendor, entries in vendor_groups.items():
        # Use org name for filename
        safe_org = org_name.replace(' ', '_').lower() if org_name else "unknown"
        runnerid = os.environ.get("GITHUB_RUN_ID", "local")
        fname = f"{safe_org}-{runnerid}.json"
        target_json = out_dir / fname
        write_json_report(target_json, entries)
        # Inject checksums for RPMs if org is amazon/corretto
        if safe_org == "amazon" or safe_org == "corretto":
            from fetch_and_inject_corretto_checksums import main as inject_checksums
            # Pass absolute path of generated vendor JSON for checksum injection
            os.environ["VENDOR_JSON_PATH"] = str(target_json.resolve())
            os.chdir(out_dir)
            inject_checksums()
            os.chdir("..")
    # Set outputs (modern method)
    github_output = os.environ.get("GITHUB_OUTPUT")
    if github_output:
        with open(github_output, "a") as f:
            f.write(f"count={len(all_releases)}\n")

if __name__ == "__main__":
    main()
