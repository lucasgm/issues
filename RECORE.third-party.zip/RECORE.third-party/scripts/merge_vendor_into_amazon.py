#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import shutil
import sys
import time
from pathlib import Path
from typing import Any, List, Dict

def write_json(path, data):
    import json, re
    json_str = json.dumps(data, indent=2)
    # Final robust regex: compact tags array regardless of indentation/spacing 
    json_str = re.sub(
        r'("tags": )\[(.*?)\](,?)',
        lambda m: m.group(1) + '[' + ','.join(x.strip() for x in m.group(2).replace('\n', '').split(',')) + ']' + m.group(3),
        json_str,
        flags=re.DOTALL
    )
    path.write_text(json_str)

"""
merge_vendor_into_amazon.py

Purpose:
  Compare a vendor JSON file with an existing amazon.json (baseline) and append
  any missing release/version entries from the vendor file into amazon.json.

Assumptions / Schema Expectations:
  - Both JSON files are objects containing a top-level array named either
      "releases" (preferred) or "versions" (fallback). The script will look
    for these keys in order: releases, versions.
  - Each element of that array should contain at least a "version" field.
  - Additional fields are copied verbatim for new (missing) versions.

Behavior:
  1. Load vendor file and amazon file.
  2. Build a set of existing versions in amazon baseline.
  3. Identify vendor entries whose "version" is not in baseline.
  4. Append those entries to the baseline array (optionally normalizing sort).
  5. Write back (unless --dry-run).
  6. Optionally create a timestamped backup before modifying (--backup / --no-backup).

Features:
  --dry-run            : Show what would change without writing.
  --backup / --no-backup (default: backup on) : Control backup creation.
  --sort none|asc|desc : Sort combined entries by version string after merge (default: none).
  --normalize-five-part: For 5-part purely numeric versions a.b.c.d.e, drop the 5th segment
                         when copying (useful if downstream tools reject 5-part versions).
  --keep-duplicates    : Do not skip vendor entries whose version already exists (will append duplicates).
  --key releases|versions : Force which key name to use in output (default keeps existing array name from amazon file or 'releases').

Exit Codes:
  0 success (even if no changes)
  1 I/O or parse error
  2 Schema error (no releases array found in inputs)

"""

def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Merge missing versions from vendor JSON into amazon JSON")
    p.add_argument("vendor", type=Path, help="Vendor JSON path")
    p.add_argument("amazon", type=Path, help="Amazon JSON path (will be updated unless --dry-run)")
    p.add_argument("--dry-run", action="store_true", help="Do not modify amazon file; just report")
    p.add_argument("--backup", dest="backup", action="store_true", default=True, help="Create a timestamped backup (default)")
    p.add_argument("--no-backup", dest="backup", action="store_false", help="Disable backup creation")
    p.add_argument("--sort", choices=["none", "asc", "desc"], default="none", help="Sort versions after merge")
    p.add_argument("--normalize-five-part", action="store_true", help="Drop 5th numeric segment for a.b.c.d.e versions")
    p.add_argument("--keep-duplicates", action="store_true", help="Append even if version already exists")
    p.add_argument("--key", choices=["releases", "versions"], help="Force array key name in output")
    return p.parse_args()


def load_json(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:  # noqa: BLE001
        print(f"ERROR: Unable to read {path}: {e}", file=sys.stderr)
        sys.exit(1)


def locate_array(obj: Any) -> tuple[str, List[Dict[str, Any]]]:
    if not isinstance(obj, dict):
        print("ERROR: Top-level JSON is not an object", file=sys.stderr)
        sys.exit(2)
    for key in ("releases", "versions"):
        if key in obj and isinstance(obj[key], list):
            return key, obj[key]  # type: ignore[return-value]
    print("ERROR: Could not find 'releases' or 'versions' array in JSON", file=sys.stderr)
    sys.exit(2)


def normalize_version(v: str, drop_fifth: bool) -> str:
    if not drop_fifth:
        return v
    parts = v.split('.')
    if len(parts) == 5 and all(p.isdigit() for p in parts):
        return '.'.join(parts[:4])
    return v


def sort_entries(entries: List[Dict[str, Any]], mode: str) -> None:
    if mode == "none":
        return
    reverse = mode == "desc"
    # Simple lexical sort on version string; advanced numeric sort optional later.
    entries.sort(key=lambda e: str(e.get("version", "")), reverse=reverse)


def main() -> int:
    args = parse_args()
    vendor_data = load_json(args.vendor)
    amazon_data = load_json(args.amazon)

    vendor_key, vendor_list = locate_array(vendor_data)
    amazon_key, amazon_list = locate_array(amazon_data)

    # Determine output key
    out_key = args.key or amazon_key or vendor_key or "releases"

    existing_versions = {str(e.get("version")) for e in amazon_list if "version" in e}
    to_add: List[Dict[str, Any]] = []

    for entry in vendor_list:
        if not isinstance(entry, dict):
            continue
        v = str(entry.get("version", ""))
        if not v:
            continue
        normalized_v = normalize_version(v, args.normalize_five_part)
        if normalized_v != v:
            entry = {**entry, "version": normalized_v}
        if not args.keep_duplicates and normalized_v in existing_versions:
            continue
        if normalized_v in {e.get("version") for e in to_add} and not args.keep_duplicates:
            continue
        to_add.append(entry)

    if not to_add:
        print("No new versions to add.")
        return 0

    print(f"Found {len(to_add)} new version(s) to append:")
    for e in to_add:
        print(f"  - {e.get('version')}")

    if args.dry_run:
        print("Dry run: not modifying amazon JSON.")
        return 0

    if args.backup:
        ts = time.strftime("%Y%m%d-%H%M%S")
        backup_path = args.amazon.with_suffix(args.amazon.suffix + f".bak-{ts}")
        try:
            shutil.copy2(args.amazon, backup_path)
            print(f"Backup created: {backup_path}")
        except Exception as e:  # noqa: BLE001
            print(f"WARNING: Could not create backup: {e}", file=sys.stderr)

    # If amazon array key differs from chosen out_key, adjust structure
    if out_key != amazon_key:
        # Remove old key to avoid duplications if needed
        for k in ("releases", "versions"):
            if k in amazon_data and k != out_key:
                amazon_data.pop(k, None)
        amazon_data[out_key] = amazon_list

    amazon_list.extend(to_add)
    sort_entries(amazon_list, args.sort)

    try:
        write_json(args.amazon, amazon_data)
        print(f"Updated {args.amazon} with {len(to_add)} new version(s).")
    except Exception as e:  # noqa: BLE001
        print(f"ERROR: Failed to write updated amazon JSON: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
