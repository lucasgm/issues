#!/usr/bin/env python3
"""Minimal helper: inject a single artifact metadata object into a vendor JSON release.
Usage:
  python add_artifact_to_vendor_json.py <vendor_json> <version> <packaging> <repository> <path> <download_url> <size_bytes> <sha256>

Behavior:
  - Loads JSON file.
  - Finds release with matching version; exits 2 if not found.
  - Ensures an 'artifacts' array exists.
  - Removes any existing artifact with same packaging then appends the new one.
  - Writes file back only if changed (compares text).
Exit codes:
  0 success (change may or may not have occurred)
  1 generic error
  2 version not found
  3 invalid args
Outputs:
  Prints 'NO_CHANGE' if nothing altered; otherwise prints 'UPDATED'.
"""
from __future__ import annotations
import json, sys, hashlib, os

ARGS_MIN = 9
ARGS_MAX = 10

def get_promoted_platforms(download_urls, promoted_types):
    # platforms = []
    # linux_urls = [url for url in download_urls if "linux" in url or url.endswith(".rpm")]
    # if linux_urls:
    #     distro_val = "rhel" if any("rhel" in url or "rpm" in url for url in linux_urls) else "unknown"
    #     distro_versions_val = ["8", "9"] if distro_val == "rhel" else []
    #     arch_val = [arch for arch in ["x86_64", "aarch64"] if any(arch in url for url in linux_urls)] or ["unknown"]
    #     platforms.append({"os": "linux", "distro": distro_val, "distro_versions": distro_versions_val, "arch": arch_val})
    # windows_urls = [url for url in download_urls if "windows" in url or url.endswith(".msi")]
    # if windows_urls:
    #     arch_val = ["x86_64"] if any("x86_64" in url or "x64" in url for url in windows_urls) else ["unknown"]
    #     platforms.append({"os": "windows", "distro": "windows", "distro_versions": [], "arch": arch_val})
    # if not platforms:
    #     platforms = [{"os": "unknown", "distro": "unknown", "distro_versions": [], "arch": ["unknown"]}]
    # return platforms
    print(f"Promoted types: {promoted_types}")
    print(f"Download URLs: {download_urls}")
    platforms = []
    linux_urls = [url for url in download_urls if "linux" in url or url.endswith(".rpm")]
    if linux_urls:
        distro_val = "rhel" if any("rhel" in url or "rpm" in url for url in linux_urls) else "unknown"
        distro_versions_val = ["8", "9"] if distro_val == "rhel" else []
        arch_val = [arch for arch in ["x86_64", "aarch64"] if any(arch in url for url in linux_urls)] or ["unknown"]
        platforms.append({"os": "linux", "distro": distro_val, "distro_versions": distro_versions_val, "arch": arch_val})
    windows_urls = [url for url in download_urls if "windows" in url or url.endswith(".msi")]
    if windows_urls:
        arch_val = ["x86_64"] if any("x86_64" in url or "x64" in url for url in windows_urls) else ["unknown"]
        platforms.append({"os": "windows", "distro": "windows", "distro_versions": [], "arch": arch_val})
    if not platforms:
        platforms = [{"os": "unknown", "distro": "unknown", "distro_versions": [], "arch": ["unknown"]}]

    print(f"Determined platforms: {platforms}")    
    return platforms

def main():
    if not (ARGS_MIN <= len(sys.argv) <= ARGS_MAX):
        print(f"Expected {ARGS_MIN} or {ARGS_MAX} args, got {len(sys.argv)-1}", file=sys.stderr)
        return 3
    # Accept optional msi_download_url for choco
    if len(sys.argv) == ARGS_MAX:
        (_self, vendor_json, version, packaging, repository, path, download_url, size_bytes, sha256, msi_download_url) = sys.argv
    else:
        (_self, vendor_json, version, packaging, repository, path, download_url, size_bytes, sha256) = sys.argv
        msi_download_url = None
    try:
        size_val = int(size_bytes)
    except ValueError:
        print("size_bytes must be int", file=sys.stderr)
        return 3
    if not os.path.isfile(vendor_json):
        print(f"File not found: {vendor_json}", file=sys.stderr)
        return 1
    original = open(vendor_json, 'r', encoding='utf-8').read()
    try:
        data = json.loads(original)
    except json.JSONDecodeError as e:
        print(f"Invalid JSON: {e}", file=sys.stderr)
        return 1
    releases = data.get('releases')
    if not isinstance(releases, list):
        print("Missing 'releases' array", file=sys.stderr)
        return 1
    target = None
    for r in releases:
        if isinstance(r, dict) and r.get('version') == version:
            target = r
            break
    if target is None:
        return 2
    artifacts = target.setdefault('artifacts', [])
    if not isinstance(artifacts, list):
        print("'artifacts' is not a list", file=sys.stderr)
        return 1
    # remove existing packaging
    artifacts = [a for a in artifacts if not (isinstance(a, dict) and a.get('packaging') == packaging)]
    new_artifact = {
        'packaging': packaging,
        'repository': repository,
        'path': path,
        'download_url': download_url,
        'size_bytes': size_val,
        'checksum': {'sha256': sha256}
    }
    artifacts.append(new_artifact)
    target['artifacts'] = artifacts
    # Inject download URLs at release level for each package type
    if packaging == 'choco' and msi_download_url:
        target['msi_download_url'] = msi_download_url
    if packaging == 'rpm' and download_url:
        target['rpm_download_url'] = download_url
    if packaging == 'image' and download_url:
        target['container_image'] = download_url
    # Update platform only for promoted types
    promoted_types = [packaging]  # Only add platform for this promoted type 
    download_urls_list = []
    # Packaging type validation: pick only the correct endpoint for the packaging type
    if packaging == 'rpm':
        if 'rpm_download_url' in target:
            download_urls_list.append(target['rpm_download_url'])
        elif 'download_urls' in target and isinstance(target['download_urls'], list):
            download_urls_list = [url for url in target['download_urls'] if url.endswith('.rpm')]
    elif packaging == 'choco':
        if 'msi_download_url' in target:
            download_urls_list.append(target['msi_download_url'])
        elif 'download_urls' in target and isinstance(target['download_urls'], list):
            download_urls_list = [url for url in target['download_urls'] if url.endswith('.msi')]
    elif packaging == 'image':
        # For images, you may have a container_image or similar field
        if 'container_image' in target:
            download_urls_list.append(target['container_image'])
        elif 'download_urls' in target and isinstance(target['download_urls'], list):
            download_urls_list = [url for url in target['download_urls'] if url.startswith('docker://')]
    # Only update platform if a matching download URL is found for the promoted type
    print(f"Download URLs for packaging '{packaging}': {download_urls_list}")
    platform_info = get_promoted_platforms(download_urls_list, promoted_types)
    # Only add platform if at least one entry is not all 'unknown'
    def is_valid_platform_entry(entry):
        return not (
            entry.get('os', 'unknown') == 'unknown' and
            entry.get('distro', 'unknown') == 'unknown' and
            (not entry.get('distro_versions')) and
            entry.get('arch', ['unknown']) == ['unknown']
        )
    valid_platforms = [entry for entry in platform_info if is_valid_platform_entry(entry)]
    # Always merge with existing platforms in the file, not just in memory
    existing_platforms = target.get('platform', []) if isinstance(target.get('platform', []), list) else []
    def platform_key(entry):
        return (entry.get('os', ''), entry.get('distro', ''), tuple(entry.get('arch', [])))
    merged = {platform_key(e): e for e in existing_platforms if is_valid_platform_entry(e)}
    for e in valid_platforms:
        merged[platform_key(e)] = e
    # Only keep platforms that are valid
    merged_platforms = [e for e in merged.values() if is_valid_platform_entry(e)]
    if merged_platforms:
        target['platform'] = merged_platforms
    elif 'platform' in target:
        # Remove platform if only unknown
        del target['platform']
    updated = json.dumps(data, indent=2, sort_keys=False) + '\n'
    if updated == original:
        print('NO_CHANGE')
        return 0
    with open(vendor_json, 'w', encoding='utf-8') as f:
        f.write(updated)
    print('UPDATED')
    return 0

if __name__ == '__main__':
    sys.exit(main())
