#!/usr/bin/env python3
"""
compare_vendor_amazon.py

Purpose:
  Compare a vendor JSON file with an amazon JSON file and print the versions
  that appear in the vendor file but NOT in the amazon file.

Usage:
  python scripts/compare_vendor_amazon.py vendor.json amazon.json

Optional arguments:
  --keys version originalVersion otherKey   # Explicit keys to treat as version fields
  --json                                    # Output missing versions as compact JSON list
  --verbose                                 # Extra debug info

Version extraction strategy:
  1. If explicit --keys provided, collect values for those keys (recursively).
  2. Always auto-detect with common version keys: version, originalVersion, pkgVersion, pkg_version.
  3. Fallback: recursively scan all string values that look like a semantic version
     (>= two numeric segments: e.g. 1.2, 1.2.3, 1.2.3.4, optionally with pre-release/build metadata).

Notes:
  - Designed to be schema-agnostic since the exact JSON format was not specified.
  - Duplicate versions are de-duplicated via set logic.
  - Exits with code 0 always; presence/absence of differences is indicated in output.

"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Iterable, Set

# Accept 2 to 5 numeric segments (a.b, a.b.c, a.b.c.d, a.b.c.d.e) with optional -prerelease/+build
# Some vendor feeds (e.g., Corretto) ship five numeric components prior to normalization.
SEMVER_CANDIDATE = re.compile(
    r"^\d+(?:\.\d+){1,4}(?:[-+][A-Za-z0-9_.-]+)?$"
)

DEFAULT_VERSION_KEYS = {"version", "originalversion", "pkgversion", "pkg_version"}


def load_json(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        print(f"ERROR: File not found: {path}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"ERROR: Failed to parse JSON {path}: {e}", file=sys.stderr)
        sys.exit(1)


def collect_versions(
    node: Any,
    versions: Set[str],
    explicit_keys: Set[str] | None,
    verbose: bool = False,
) -> None:
    """Recursively traverse node collecting version strings."""
    if isinstance(node, dict):
        for k, v in node.items():
            kl = k.lower()
            if isinstance(v, str):
                # If key is explicitly specified or recognized as a default version key, add directly.
                if (explicit_keys and kl in explicit_keys) or (kl in DEFAULT_VERSION_KEYS):
                    if _looks_like_version(v):
                        versions.add(v.strip())
                        if verbose:
                            print(f"[match:key] {k} -> {v}")
                else:
                    # Fallback: look for version-like strings in other keys only if they look like semver.
                    if _looks_like_version(v):
                        versions.add(v.strip())
                        if verbose:
                            print(f"[match:auto] {k} -> {v}")
            else:
                collect_versions(v, versions, explicit_keys, verbose)
    elif isinstance(node, list):
        for item in node:
            collect_versions(item, versions, explicit_keys, verbose)
    # Primitives other than str ignored.


def _looks_like_version(text: str) -> bool:
    # Quickly discard obviously non-version strings to reduce false positives.
    if len(text) > 64:
        return False
    if not any(ch.isdigit() for ch in text):
        return False
    t = text.strip()
    if SEMVER_CANDIDATE.match(t):
        return True
    return False


def parse_args(argv: Iterable[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Compare vendor and amazon JSON version sets.")
    p.add_argument("vendor", type=Path, help="Path to vendor JSON")
    p.add_argument("amazon", type=Path, help="Path to amazon JSON")
    p.add_argument(
        "--keys",
        nargs="*",
        default=None,
        help="Explicit keys to treat as version fields (case-insensitive).",
    )
    p.add_argument("--json", action="store_true", help="Emit output as JSON list only")
    p.add_argument("--verbose", action="store_true", help="Verbose extraction logging")
    return p.parse_args(list(argv))


def main(argv: Iterable[str]) -> int:
    args = parse_args(argv)
    explicit = {k.lower() for k in args.keys} if args.keys else None

    vendor_data = load_json(args.vendor)
    amazon_data = load_json(args.amazon)

    vendor_versions: Set[str] = set()
    amazon_versions: Set[str] = set()
    collect_versions(vendor_data, vendor_versions, explicit, args.verbose)
    collect_versions(amazon_data, amazon_versions, explicit, args.verbose)

    missing = sorted(vendor_versions - amazon_versions, key=_version_sort_key)

    if args.json:
        # Output full JSON objects for missing versions
        missing_objs = [r for r in vendor_data.get('releases', []) if r.get('version') in missing]
        json.dump(missing_objs, sys.stdout, indent=2)
        print()
    else:
        print(f"Vendor versions found: {len(vendor_versions)}")
        print(f"Amazon versions found: {len(amazon_versions)}")
        print(f"Versions in vendor but not in amazon ({len(missing)}):")
        for v in missing:
            print(f"  {v}")
        if not missing:
            print("(none)")

    return 0


def _version_sort_key(v: str):
    # Produce a tuple for natural numeric ordering on core segments; fallback to original.
    parts = re.split(r"[.+-]", v)
    nums = []
    for p in parts:
        if p.isdigit():
            nums.append(int(p))
        else:
            break
    return (*nums, v)


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main(sys.argv[1:]))
