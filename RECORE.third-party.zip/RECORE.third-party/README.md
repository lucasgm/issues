# RECORE.third-party

Automation engine for ICE's **third-party software onboarding ("whitelisting")** platform, owned by
the **RE-Core** team. This repo holds the GitHub Actions workflows, composite actions, and scripts
that take a developer's request (a GitHub issue), pull the requested artifact from a public registry,
security-scan it with Aqua, mirror it into ICE's internal Artifactory, sign it, and publish it to the
self-service catalog surfaced on [ICEDevX](https://icedevx.intcx.net/catalog).

> **New here?** Read [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the full end-to-end flow.

## The three-repo model

| Repo | Role |
|------|------|
| **RECORE.third-party** (this repo) | Workflows + actions + scripts (the "code"). |
| **RECORE.third-party-configs** | Source of truth for *what to onboard*. `*-request-ops` workflows write here. |
| **RECORE.third-party-catalog** | Result DB of *what was published*. Lifecycle workflows write here; powers ICEDevX. |

Flow: **issue → configs repo → lifecycle build/scan → catalog repo → ICEDevX**.

## Supported artifact types

| Type | Request template | Entry workflow | Build/scan workflow |
|------|------------------|----------------|---------------------|
| Container image | `request-image.yml` | `image-request-ops.yml` | `<vendor>-workflow-image-lifecycle.yml` |
| Library (npm / pypi) | `request-library.yml` | `library-request-ops.yml` | `npm-library-workflow.yml` / `pypi-library-workflow.yml` |
| Helm chart | `request-helm-chart.yml` | `helm-charts-request-ops.yml` | `helm-charts-workflow.yml` |
| Windows package (RPM/choco/nuget) | `request-windows-package.yml` | `windows-package-request-ops.yml` | `windows-pkg-<vendor>-workflow-lifecycle.yml` |
| New vendor | `request-vendor.yml` | `vendor-request-ops.yml` | *(no build — opens a ServiceNow ticket)* |
| Blackout (remove) | `blackout-library.yml` | `library-blackout-request-ops.yml` | *(deletes from Artifactory, flags inactive)* |
| Delay config | `update-library-delay.yml` | `library-delay-request-ops.yml` | *(edits `.delay` in configs only)* |

Container vendors: `amazon, aquasec, dockerhub, ghcr, ibm, kubernetes, microsoft, netboxlabs, quayio, redhat`.

## Repository layout

```
.github/
  ISSUE_TEMPLATE/       # IssueOps request forms (one per artifact type)
  workflows/            # ~70 workflows: *-request-ops, *-lifecycle, reusable building blocks, scanners
  actions/              # ~16 local composite actions (setup-jfrog-cli, create-sbom, scan-sbom,
                        #   sign-artifacts, verify-artifacts, prepare-package-spec, ...)
  scripts/              # scan-library-chunk.sh, windows-package-utils.sh
  hosts/hosts.ini       # self-hosted runner inventory
scripts/
  discover_*.py         # per-vendor tag/version discovery
  *_vendor_json.py      # catalog/vendor JSON mutation (add artifact, add security, merge, compare)
  fetch_*corretto*.py   # Corretto release + checksum handling
  metrics/              # git-history → NDJSON → REPORT.md + DASHBOARD.html
```

## How a request is processed

1. Developer opens an issue from a template → a label is applied.
2. `*-request-ops.yml` (triggered on `issues: [opened, edited]`) parses & validates the issue,
   commits the request into **RECORE.third-party-configs**, comments "request received", and
   dispatches the matching lifecycle workflow.
3. The **lifecycle workflow** pulls, scans (Aqua), gates, mirrors to Artifactory, signs
   (cosign for images / GPG for RPM+choco), and writes the result into **RECORE.third-party-catalog**
   on a per-run branch that is then consolidated.
4. `*-request-ops` polls the run **and verifies the real catalog outcome**, posts a per-item result
   (published / scan-gated / past-EOL / not cataloged), and closes the issue on success.
5. `image-recurring-scan.yml` (every 3 days) and `library-recurring-scan.yml` (every 7 days) re-scan
   cataloged artifacts and update status.

## Security gate & exceptions

Aqua's policy gate blocks artifacts with critical vulnerabilities. To publish anyway, teams request an
**AppSec exception**; on approval the artifact is published with status `suppressed` and each suppressed
CVE is recorded (ticket, approver, expiry) in the catalog's `suppression_details[]`. See
[Exception to Suppress Vulnerabilities](https://confluence.ice.com/spaces/SARE/pages/1096143198/).

## External systems & secrets

**Systems:** JFrog Artifactory (`artifbuild.intcx.net`, `*.icr.intcx.net`), Aqua Security
(`aquasec.intcx.net`), Sigstore cosign, ServiceNow, npmjs.org (published from Jenkins DC4), and the
public source registries. Runs on self-hosted GHES runners.

**Key secrets:** `GHE_RE_TOKEN` (cross-repo push), `ARTIF_*`/`BASE_*` (Artifactory),
`AQUA_TOKEN`/`recore_aquasec_api_*` (scanning), `COSIGN_*_{CI,CD}` (signing), registry creds
(`DOCKER_HUB*`, `RHEL_*`, `QUAY_*`, `IBM_API_KEY`, ...), `NPM_PUBLISH_TOKEN`, `SNOW_*`.
Full list in [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md#secrets).

## Related documentation

- User guides (Confluence, SARE space): [Whitelisting Container Images](https://confluence.ice.com/spaces/SARE/pages/982697579/), [Whitelisting Helm Charts](https://confluence.ice.com/spaces/SARE/pages/982139766/), [Request New Vendor](https://confluence.ice.com/spaces/SARE/pages/982139790/), [Curated Container Artifact Hub](https://confluence.ice.com/spaces/RE/pages/1059810422/)
- Catalog schema: [RECORE.third-party-catalog/docs/SCHEMA.md](../RECORE.third-party-catalog/docs/SCHEMA.md)

## Support

RE-Core team — Rijwan Desai (US), Raviraj Singh (India). Workflow changes are reviewed by
`@intcx/recore` (see `.github/CODEOWNERS`).
